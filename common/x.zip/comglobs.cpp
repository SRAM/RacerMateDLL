
#include <vector>
#include <string>

std::vector<std::string> dirs;

