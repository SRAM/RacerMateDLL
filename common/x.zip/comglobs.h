#ifndef _COMGLOBS_H_
#define _COMGLOBS_H_

#include <vector>
#include <string>

extern std::vector<std::string> dirs;

#endif		// #ifndef _MYGLOBALS_H_


