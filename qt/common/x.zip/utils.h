#ifndef _FSQT_UTILS_
#define _FSQT_UTILS_

#include <QString>

QString rstrip(const QString& str);

#endif


