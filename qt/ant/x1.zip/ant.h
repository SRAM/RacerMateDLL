#ifndef ANT_H
#define ANT_H

#include <QObject>
#include <QFile>
#include <QTimer>
#include <QVector>


//#include <QNetworkReply>
//#include <QAuthenticator>

#include "sl_global.h"

#include "tmr.h"

#include "antdev.h"

#include "cad.h"
#include "sc.h"
#include "hr.h"


#ifdef TEST_MODE
xxxxxxxxxxxxxxxxxxx
#endif

// 1 = qml
// 2 = qt console
// 3 = windows dll

#define TEST_MODE 2

//class ANT : public QObject  {								// this also seems to work
//extern bool asi;

/********************************************************************************************

********************************************************************************************/

class SHAREDLIBSHARED_EXPORT ANT : public QObject  {
	Q_OBJECT

	public:

#define ANT_INVALID_SENSOR -1;
#define HR_DEV_TYPE	120						// heart rate
#define SC_DEV_TYPE	121						// speed cadence
#define C_DEV_TYPE	122						// cadence

#define ANT_HR 0
#define ANT_C 1
#define ANT_SC 2

		enum RMANT_ERROR {
			RMANT_SUCCESS = LIBUSB_SUCCESS,											// 0
			RMANT_ERROR_IO = LIBUSB_ERROR_IO,										// -1		Input/output error
			RMANT_ERROR_INVALID_PARAM = LIBUSB_ERROR_INVALID_PARAM,			// -2		Invalid parameter
			RMANT_ERROR_ACCESS = LIBUSB_ERROR_ACCESS,								// -3		Access denied (insufficient permissions)
			RMANT_ERROR_NO_DEVICE = LIBUSB_ERROR_NO_DEVICE,						// -4		No such device (it may have been disconnected)
			RMANT_ERROR_NOT_FOUND = LIBUSB_ERROR_NOT_FOUND,						// -5		Entity not found
			RMANT_ERROR_BUSY = LIBUSB_ERROR_BUSY,									// -6		Resource busy
			RMANT_ERROR_TIMEOUT = LIBUSB_ERROR_TIMEOUT,							// -7		Operation timed out
			RMANT_ERROR_OVERFLOW = LIBUSB_ERROR_OVERFLOW,						// -8		Overflow
			RMANT_ERROR_PIPE = LIBUSB_ERROR_PIPE,									// -9		Pipe error
			RMANT_ERROR_INTERRUPTED = LIBUSB_ERROR_INTERRUPTED,				// -10	System call interrupted (perhaps due to signal) */
			RMANT_ERROR_NO_MEM = LIBUSB_ERROR_NO_MEM,								// -11	Insufficient memory
			RMANT_ERROR_NOT_SUPPORTED = LIBUSB_ERROR_NOT_SUPPORTED,			// -12	Operation not supported or unimplemented on this platform
			RMANT_ERROR_NO_CTX = 1,
			RMANT_ERROR_NO_USB_DEVICES = 2,
			RMANT_ERROR_GET_DEVICE_DESCRIPTOR = 3,
			RMANT_ERROR_OTHER = LIBUSB_ERROR_OTHER,								// -99	Other error
		};

	private:
		#define ANT_STANDARD_DATA_PAYLOAD_SIZE		((UCHAR)8)

		#define SCPERIOD  8086							// must be 8086 or you get a lot of timeouts, although it tries to work
		#define SCDEVTYPE 121							// has to be 121
		#define HRPERIOD 8070
		#define HRDEVTYPE 120

		#define GARMIN_USB2_VID   0x0fcf
		#define GARMIN_USB2_PID   0x1008
		#define GARMIN_OEM_PID    0x1009

		bool dbg;

		//#define SPEED_CADENCE

		//enum SENSOR_TYPE {
		//	SC,										// speed cadence
		//	HR										// heartrate
		//};

		//typedef struct  {
		class STICK  {
			public:
				//quint32 key;
				quint16 vid;								// vendor id
				quint16 pid;								// product id
				//quint16 sn;
				int nconfigs;

				char mfgr[32];
				char product[32];
				char serial_number[32];
				int bp;

				STICK()  {
					reset();
				}
				~STICK()  {
					bp = 1;
				}

				void reset()  {
					bp = 0;
					vid = 0;
					pid = 0;
					//sn = 0;
					nconfigs = 0;
					memset(mfgr, 0, sizeof(mfgr));
					memset(product, 0, sizeof(product));
					memset(serial_number, 0, sizeof(serial_number));
				}

		//} STICK;
		};

		//QVector<STICK> sticks;
		QHash<int, STICK> sticks;


		typedef struct  {
			char name[24];
			UCHAR dev_type;			// 121
			USHORT baud;			// 57600
			UCHAR freq;				// 57
			USHORT period;			// 8086
			UCHAR chan_num;			// 0
			UCHAR dev_num;			// 0
			UCHAR trans_type;		// 0
			UCHAR chan_type;		// CHANNEL_TYPE_SLAVE, Channel type as chosen by user (master or slave), 0 = slave?
		} ANTDEF;

		#define NTYPES 2
		#define NSENSORS 2

		ANTDEF SENSORS[NTYPES] = {
			{
				"Speed Cadence",
				121,
				57600,
				57,
				8086,
				0,						// chan_num
				0,						// dev_num
				0,						// trans_type
				0						// chan_type
			},

			{
				"Heartrate",
				120,
				57600,
				57,
				8070,
				0,						// chan_num
				0,						// dev_num
				0,						// trans_type
				0						// chan_type
			},
		};

		ANTDEF antdef[NSENSORS];

		QVector<CAD *> cad;
		//CAD cad;
		QVector<SC *> sc;
		QVector<HR *> hr;

		#define LOGNAME "ant.log"

#if TEST_MODE==1
		QString m_statstr;
		QString m_buttit;
#elif TEST_MODE==2
		QTimer *timer;
		RACERMATE::Tmr *tmr;
		qint64 start;
#endif

		int debug_level;
		QObject *parent;
		FILE *logstream;
		char logstr[2048];
		bool critsec;
		libusb_context *ctx;										// a libusb session
		int nants;
		const struct libusb_version *verstruc;
		unsigned long version;
		QVector<ANTDEV> antdevs;
		libusb_device **usb_device_list=NULL;
		char gstr[256];
		unsigned long shutdown_delay;

		// functions

		int init(void);
		void logg(const char *format, ...);
		QString rstrip(const QString& str);
		void merge_log_files(void);

		int find_ant_sticks(void);
		int test1stick_2channels(void);
		int test2sticks(void);
		int test_discovery_one_stick_one_channel(void);
		int pairing_test(void);
		int get_channel(int _devtype, unsigned short _period, int &_ix, int &_chan);
		int pair_device_and_channel(int _devtype, int &_stick_index, int &_chan);
		int post2(void);



	protected:
//		DWORD decode_time;
//		USHORT previous_event_count;
//		USHORT rr_interval_1024;			// R-R interval (1/1024 seconds), conversion to ms is performed for data display
		int bp;
//		unsigned char ant_packet[8];
		int scan(void);

	public:
		ANT(QObject *parent = 0);
		ANT(int _debug_level, QObject *parent = 0);
		~ANT();

		int ant_init(void (*_ant_keyfunc)(void) );


#if TEST_MODE==1

		// expose some members to qml
		Q_PROPERTY (
				QString statstr								// type and name
				READ get_statstr								// getter
				WRITE set_statstr								// setter
				NOTIFY statstr_changed						// notify signal
		)
		Q_PROPERTY (
				QString buttit									// type and name
				READ get_buttit								// getter
				WRITE set_buttit								// setter
				NOTIFY buttit_changed						// notify signal
		)

		QString get_statstr() const;						// gets fileName from QML
		void set_statstr(const QString &_statstr);	// sets m_statstr

		QString get_buttit() const;						// gets fileName from QML
		void set_buttit(const QString &_buttit);		// sets m_statstr
		Q_INVOKABLE int enumerate_sticks(void);

		/*
		Q_INVOKABLE int find_ant_sticks(void);
		Q_INVOKABLE int test1stick_1channel(void);
		Q_INVOKABLE int test1stick_2channels(void);
		Q_INVOKABLE int test2sticks(void);
		Q_INVOKABLE int test_discovery_one_stick_one_channel(void);
		Q_INVOKABLE int pairing_test(void);
		Q_INVOKABLE int get_channel(int _devtype, unsigned short _period, int &_ix, int &_chan);
		Q_INVOKABLE int pair_device_and_channel(int _devtype, int &_stick_index, int &_chan);
		Q_INVOKABLE int post2(void);
		*/
#elif TEST_MODE==2
		int enumerate_sticks(void);
		int test1stick_1channel(void);

#endif

	signals:
#if TEST_MODE==1
		void statstr_changed();
		void buttit_changed();
#endif

	private slots:
		void timeout_slot();

	protected slots:

	public slots:

	private:
		//--------------------------------------
		// globals:
		//--------------------------------------

		char channel_status_string[4][32] = {
											"UA",									// "UNASSIGNED CHANNEL",
											"A",									// "ASSIGNED CHANNEL",
											"S",									// "SEARCHING CHANNEL",
											"T"									// "TRACKING CHANNEL"
		};

		DWORD start_time;							// the time the message thread starts
		bool got_caps = false;
		bool got_status = false;
		bool got_id = false;
		int devnum = 0;
		int netnum = 0;
		bool log_raw = false;

		#ifdef _DEBUG
			//int hrcalls;
			//int sccalls;
		#endif

		unsigned char ant_key[8] = {0xB9, 0xA5, 0x21, 0xFB, 0xBD, 0x72, 0xC3, 0x45};		// antplus key
		USHORT ant_baud = 57600;

		//RACERMATE::Tmr gat("gant");
		bool asi;
		bool sensors_initialized;
		bool initialized;
		unsigned long g_ant_tid;

		char ant_logname[16];

		/*
		CAD cad;
		HR hr;
		SC sc;
		*/

		DWORD ant_start_time = 0L;

		FILE *ant_logstream = NULL;
		bool do_ant_logging = false;
		bool inprocess;
		bool ant_closed;
		char ant_gstring[2048];
		char pstr[256];
		char ant_error_string[256];
		char ant_str[256];
		char gstatus[4][32];					// astrstatus
		USHORT usDevicePID;
		USHORT usDeviceVID;
		UCHAR aucDeviceDescription[256];
		UCHAR aucDeviceSerial[256];
		//UCHAR MAX_NO_EVENTS = 12;						// Maximum number of messages with no new events (3s)
		bool bursting;										//holds whether the bursting phase of the test has started
		bool ant_broadcasting;
		bool ant_done;
		bool ant_rundone;
		/*
		DSIFramerANT* framer;
		DSI_THREAD_ID uiDSIThread;
		DSI_CONDITION_VAR condTestDone;
		DSI_MUTEX mutexTestDone;
		*/

		bool ant_display;
		UCHAR ant_txbuf[ANT_STANDARD_DATA_PAYLOAD_SIZE];
		bool gant_channel_opened;
		UCHAR ant_caps[5];
		//UCHAR gstatusbyte;						// ucStatusByte;
		unsigned char ant_ack;
		unsigned char ant_msg;
		//DSISerialGeneric *pclSerialObject;

};									// class ANT



																// class CAD


#endif					// #ifndef _AUNT_H_

