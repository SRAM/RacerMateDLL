#ifndef _QTHR_H_
#define _QTHR_H_

#include "page_sensor.h"

/********************************************************************************************

********************************************************************************************/

class HR : public PAGE_SENSOR {
public:
	HR(void);
	~HR();
	//int reset(void);
	int decode(void);                   // decoder used by heart rate and cadence-only
	unsigned char val;                  // heartrate directly from sensor
	unsigned char calculated_val;
	float get_val(void);                //  { return (float)val; }

private:
	quint8 previous_event_count;
	quint16 rr_interval_1024;        // R-R interval (1/1024 seconds), conversion to ms is performed for data display
	bool initialized;
#ifdef _DEBUG
	int hrcalls;
#endif

};                                                 // class HR

#endif



