
#ifndef _WORKER_H_
#define _WORKER_H_
#include "antdev.h"

#ifdef WORKER_OWNS_DEVICES



#include <QtCore>
#include <tmr.h>


namespace RACERMATE  {


class ANT;

class Worker : public QObject  {
	Q_OBJECT

	friend class ANT;

	public:
		 Worker(int _debug_level, QObject* parent = 0);
		// don't use a destructor!!! use the stop() slot instead

	private:
		QTimer *m_timer = NULL;
		Tmr *at = NULL;
		int tick = 0;
		int debug_level = 0;
		//RACERMATE::SDIRS *sdirs=NULL;
		FILE *logstream = NULL;
		char logname[256] = {0};
#ifdef _DEBUG
		int bp = 0;
#endif

	public slots:
		void start();
		void stop();

	private slots:
		void timeout_slot();

	signals:
		void finished();
};

}				// namespace RACERMATE
#endif		// #ifdef WORKER_OWNS_DEVICES

#endif

