
#include "worker.h"


#include "ant.h"

namespace RACERMATE  {

#ifdef WORKER_OWNS_DEVICES

/**************************************************************************

**************************************************************************/

Worker::Worker(int _debug_level, QObject* _parent ) : QObject(_parent) {
	debug_level = _debug_level;

	int status;

	at = new Tmr("W");

	if (debug_level > 0) {
		RACERMATE::SDIRS *sdirs = new RACERMATE::SDIRS(debug_level, "rmant");
		status = sdirs->get_rc();
		switch(status)  {
			case 0:
				break;
			case -1:
				throw("sdirs error 1");			// ctsrv catches this
			case -2:
				throw("sdirs error 2");			// ctsrv catches this
			case -3:
				throw("sdirs error 3");			// ctsrv catches this
			default:
				throw("sdirs error 101");		// ctsrv catches this
		}

		QString s = sdirs->get_debug_dir() + "worker.log";
		DEL(sdirs);

		strncpy(logname, s.toUtf8().constData(), sizeof(logname)-1);
		logstream = fopen(logname, "wt");
		QDateTime dt = QDateTime::currentDateTime();
		s = dt.toString("yyyy-MM-dd-hh-mm-ss");
		fprintf(logstream, "%s starting at %s, debug_level = %d\n\n", logname, s.toUtf8().constData(), debug_level);
		fflush(logstream);
	}           // if (debug_level > 0)

	return;
}                    // constructor()



/**************************************************************************

**************************************************************************/

void Worker::timeout_slot() {                  // see prepareResult(), trackshun
	//at->update();								// 10.00 ms

	tick++;
	if (tick >= 500)  {							// 5000 ms
		tick = 0;
		//at->update();
	}

	return;
}                    // timeout()

/**************************************************************************

**************************************************************************/

void Worker::start() {
	if (QThread::currentThread() != thread()) {
		QMetaObject::invokeMethod(this, "start");
		return;
	}

#ifdef _DEBUG
	//qDebug() << "      Worker::start(): calling m_timer->start()";
#endif

	if (m_timer) {
		m_timer->start();
	}

}                       // start() slot

/**************************************************************************
	don't do this in a destructor!!!!!
**************************************************************************/

void Worker::stop() {
	if (QThread::currentThread() != thread()) {
		QMetaObject::invokeMethod(this, "stop");
		return;
	}

	if (m_timer) {
		m_timer->stop();
	}


#ifdef _DEBUG
	if (at)  {
		at->setdbg();			// causes Tmr to print update results
	}
#endif

	DEL(at);
	//DEL(sdirs);

	FCLOSE(logstream);

	emit finished();
}           // stop() slot
#endif			// #ifdef WORKER_OWNS_DEVICES

}           // namespace RACERMATE


