
#include "worker.h"


#include "ant.h"

namespace RACERMATE  {

#ifdef DOWORKER

/**************************************************************************

**************************************************************************/

Worker::Worker(int _debug_level, QObject* _parent ) : QObject(_parent) {
	debug_level = _debug_level;
	ant = (ANT*)_parent;

	int status;

	tmr = new Tmr("W");

	if (debug_level > 0) {
		RACERMATE::SDIRS *sdirs = new RACERMATE::SDIRS(debug_level, "rmant");
		status = sdirs->get_rc();
		switch(status)  {
			case 0:
				break;
			case -1:
				throw("sdirs error 1");			// ctsrv catches this
			case -2:
				throw("sdirs error 2");			// ctsrv catches this
			case -3:
				throw("sdirs error 3");			// ctsrv catches this
			default:
				throw("sdirs error 101");		// ctsrv catches this
		}

		QString s = sdirs->get_debug_dir() + "worker.log";
		DEL(sdirs);

		strncpy(logname, s.toUtf8().constData(), sizeof(logname)-1);
		logstream = fopen(logname, "wt");
		QDateTime dt = QDateTime::currentDateTime();
		s = dt.toString("yyyy-MM-dd-hh-mm-ss");
		fprintf(logstream, "%s starting at %s, debug_level = %d\n\n", logname, s.toUtf8().constData(), debug_level);
		fflush(logstream);
	}           // if (debug_level > 0)

	timer = new QTimer(this);
	timer->setInterval(100);
	ticks = 999;																					// so first timeout will be > 3000 ms
	connect(timer, SIGNAL(timeout()), this, SLOT(timeout_slot()));             // , Qt::DirectConnection, prepareResult()

	return;
}                    // constructor()


/**************************************************************************

**************************************************************************/

void Worker::timeout_slot() {                  // see prepareResult(), trackshun

#ifdef _DEBUG
	//tmr->update();									// 100 ms
#endif

//	bool b;

//	//b = mutex.tryLock(5);                        // wait up to 5 ms for a lock
//	b = mutex.lock();
//	if (b == false) {
//		bp = 1;
//	}

//	int timeout = 30;
//	if (ticks==999)  {
//		timeout = 30;
//	}
//	else  {
//		timeout = 30;
//	}
	ticks++;

	if (ticks < 100)  {								// every 3000 ms
		return;
	}

	ticks = 0;

//	if (ant)  {											// passed in to the constructor
//		int status;
//		Q_UNUSED(status);

//		status = ant->scan_for_devices();

//		if (ant->devices.size()==0)  {
//			return;
//		}

//		ANTDEV *device;
//		device = ant->devices.first();

//		if (!device->is_listening())  {
//			status = device->open_listening_channel();
//			bp = 3;
//		}
//	}



	return;
}                    // timeout_slot()


/**************************************************************************

**************************************************************************/

void Worker::start() {
	if (QThread::currentThread() != thread()) {
		QMetaObject::invokeMethod(this, "start");
		return;
	}


	#ifdef _DEBUG
		//qDebug() << "      Worker::start(): calling m_timer->start()";
	#endif
	if (timer) {
		timer->start();
	}

}                       // start() slot

/**************************************************************************
	don't do this in a destructor!!!!!
**************************************************************************/

void Worker::stop() {
	if (QThread::currentThread() != thread()) {
		QMetaObject::invokeMethod(this, "stop");
		return;
	}

	if (timer) {
		timer->stop();
	}

#ifdef _DEBUG
	if (tmr)  {
		tmr->setdbg();			// causes Tmr to print update results
	}
#endif

	DEL(tmr);
	//DEL(sdirs);

	FCLOSE(logstream);

	emit worker_finished();
}           // stop() slot
#endif			// #ifdef DOWORKER

}           // namespace RACERMATE


