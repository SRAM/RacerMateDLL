#ifndef _ANTDEV_H_
#define _ANTDEV_H_

#include <stdio.h>
//#include <stdlib.h>
#include <string.h>

#include <vector>

#include <QtCore>
#include <QThread>

//#pragma warning( push )
//#pragma warning( disable : 4200 )
	#include <libusb.h>
//#pragma warning( pop )

//#include <aunt.h>

#ifdef WIN32
//	#include <console.h>
#endif


#define ANTDEV_USES_QTIMER

//#include <tinythread.h>
#include "antmessages.h"
#include "antmsg.h"

#include "antchan.h"

#define NANTCHANS 8

#define UCHAR unsigned char
#define USHORT unsigned short
#define ULONG unsigned long


/****************************************************************************

****************************************************************************/

class ENDPOINT  {
	public:
		void set_type(unsigned char _type)  { type = _type; }
		void set_addr(unsigned char _addr)  { addr = _addr; }

		void clear(void)  {
			type = 0;
			addr = 0;
			return;
		}

	private:
		unsigned char type;
		unsigned char addr;
};

/****************************************************************************

****************************************************************************/

class ALTSETTING  {
	public:
		void clear(void)  {
			int i, n;
			n = eps.size();
			for(i=0; i<n; i++)  {
				eps[i].clear();
			}
			eps.clear();
			return;
		}

		void add_ep(ENDPOINT _ep)  { eps.push_back(_ep); }


	private:
		std::vector<ENDPOINT> eps;
};

/****************************************************************************

****************************************************************************/

class INTF  {
	public:
		void clear(void)  {
			int i, n;
			n = alts.size();
			for(i=0; i<n; i++)  {
				alts[i].clear();
			}
			alts.clear();
			return;
		}
		void add_alt(ALTSETTING _as)  { alts.push_back(_as); }
		void set_alt(std::vector<ALTSETTING> _asvec)  { alts = _asvec; }

	private:
		std::vector<ALTSETTING> alts;

};

/****************************************************************************

****************************************************************************/

#ifdef ANTDEV_USES_QTIMER
class ANTDEV : public QObject  {
#else
class ANTDEV  {
#endif

	Q_OBJECT

		private:
			bool msgdone;
			unsigned char channel_event_ack;
			unsigned char gevent;

			unsigned long tid;
			int id;
			int inpackets;
			int outpackets;
			int process_count;
			UCHAR ucStandardOptions;
			UCHAR ucAdvanced;
			UCHAR ucAdvanced2;
			unsigned long sernum;
			char sernum_string[16];
			char version[32];
			bool extended;
			//unsigned long event_count;
			unsigned long sequence;												// for logging
			//bool sequence_lock;
			//HANDLE sequence_mutex;
#ifdef WIN32
			CRITICAL_SECTION critsec;
#endif
			bool plogging;

			#ifdef _DEBUG
				//#define TXLOGNAME "tx.log"
				//#define RXLOGNAME "rx.log"
				FILE *txstream;
				FILE *rxstream;
				void txlog(void);
				//void rxlog(unsigned char cs, bool flush=false);
				void rxlog(bool flush=false);
			#endif

			#ifdef _DEBUG
				#define MESSAGE_TIMEOUT			(3300)
			#else
				#define MESSAGE_TIMEOUT			(3300)
			#endif

			#define HRM_PAGE0			((UCHAR) 0)
			#define HRM_PAGE1			((UCHAR) 1)
			#define HRM_PAGE2			((UCHAR) 2)
			#define HRM_PAGE3			((UCHAR) 3)
			#define HRM_PAGE4			((UCHAR) 4)

			#define HRM_INVALID_BPM		((UCHAR) 0)

			#define OFFS_SYNC				0
			#define OFFS_LEN				1
			#define OFFS_MSG				2
			#define OFFS_DATA				3					// variable

			// when it's a channel  event:

			#define OFFS_CHAN				3
			#define OFFS_EVENT_ID		4
			#define OFFS_EVENT_CODE		5


			#ifdef _DEBUG
				int hrcalls;
				int sccalls;
			#endif

			enum HRMStatePage  {
				HRM_STD0_PAGE = 0,
				HRM_STD1_PAGE = 1,
				HRM_INIT_PAGE = 2,
				HRM_EXT_PAGE = 3
			};

			#define HRM_TOGGLE_MASK		((UCHAR) 0x80)
//#ifdef WIN32
#if 0
			Console *console;
			WORD scrollable_attr;
			SMALL_RECT scroll_rect;
			int SCROLL_LEFT;
#endif
			void plogg(const char *format, ...);							// process log, only called from the reader thread
			//void logg(char *str, bool flush=false);

			char logstr[256];

			char error_string[256];
			unsigned char net;
			//static const unsigned char USER_NETWORK_KEY[8];		// = { 0xB9, 0xA5, 0x21, 0xFB, 0xBD, 0x72, 0xC3, 0x45 };
			unsigned char USER_NETWORK_KEY[8];		// = { 0xB9, 0xA5, 0x21, 0xFB, 0xBD, 0x72, 0xC3, 0x45 };

			unsigned char key[8];		// = USER_NETWORK_KEY;
//unsigned char gack = 0;
			UCHAR ucStatePage;				// Track if advanced data is supported

			//UCHAR chan_num;

			//ANTCHAN chan[NANTCHANS];
			ANTCHAN channels[NANTCHANS];

			//unsigned short period;
			//UCHAR freq;				// 57			UCHAR ucStatePage;				// Track if advanced data is supported
			UCHAR ucPreviousEventCount;					// Previous heart beat event count
			USHORT usPreviousTime1024;					// Time of previous heart beat event (1/1024 seconds)
			UCHAR ucEventCount;				// Heart beat event count
			USHORT usTime1024;					// Time of last heart beat event (1/1024 seconds)
			ULONG ulElapsedTime2;			// Cumulative operating time (elapsed time since battery insertion) in 2 second resolution

			// Background Data

			UCHAR ucMfgID;						// Manufacturing ID
			UCHAR ucHwVersion;					// Hardware version
			UCHAR ucSwVersion;					// Software version
			UCHAR ucModelNum;				   // Model number
			USHORT usSerialNum;				// Serial number
			UCHAR ucNoEventCount;				// Successive transmissions with no new HR events
			ULONG ulAcumEventCount;			// Cumulative heart beat event count
			ULONG ulAcumTime1024;			// Cumulative time (1/1024 seconds), conversion to s is performed for data display
			USHORT usR_RInterval1024;		// R-R interval (1/1024 seconds), conversion to ms is performed for data display

			#define TXBUFLEN 256
			#define RXBUFLEN 256

			enum States {
				ST_WAIT_FOR_SYNC,
				ST_GET_LENGTH,
				ST_GET_MESSAGE_ID,
				ST_GET_DATA,
				ST_VALIDATE_PACKET
			} state;

			enum BSCState {
				BSC_INIT = 0,
				BSC_ACTIVE = 1,
			};

			#define MAX_NO_EVENTS	12				// Maximum number of messages with no new events (3s)

			//libusb_device lusbdev;
			//int num;											// device number

			static int instances;		// count of instances

#ifdef _DEBUG
			static int calls;		// count of calls
#endif

			int init(void);
#ifdef _DEBUG
			int bp;
			bool oktobreak;
#endif
			unsigned short vid;
			unsigned short pid;
			char sn[32];
			int nconfigs;
			unsigned char bus_number;
			unsigned char device_address;
			int ix;										// index into devlist array
			std::vector<INTF> ifs;
			libusb_device *device;

			bool dotx;
			double total_tx_seconds;
			unsigned long tx_calls;
			//unsigned long send_calls;
			int send(ANTMsg m, bool _flush, unsigned char _chan=0xff);
			int tx(unsigned char *_buf, int _n, unsigned long _timeout);

			bool dorx;


			///static void reader(void * arg);
			//static void writer(void * arg);
//			void writer(void * arg);
//			void reader(void * arg);

//#ifdef WIN32
//			tthread::thread *txthread;
//			tthread::thread *rxthread;

#ifdef ANTDEV_USES_QTIMER
			QTimer *txthread;
			QTimer *rxthread;
#else
		QThread *txthread;
		QThread *rxthread;
#endif


			double total_rx_seconds;
			unsigned long rx_calls;
			unsigned long read_calls;
			//bool waitack(UCHAR _msg, unsigned long _ms);
			bool wait_event_ack(UCHAR _msg, qint64 _ms);
			bool wait_for_message_completion(UCHAR _msg, qint64 _ms);
			void receiveByte(unsigned char byte);
			void process(void);
			int rx(void);

			unsigned char rxMessage[ANT_MAX_MESSAGE_SIZE];
			bool initialized;

			//unsigned char gack2;						// non-channel event flag
			//unsigned char gmsg2;						// non-channel event flag

			//unsigned char gevent;
			//#define LOGNAME "y.log"
			#define ANTDEVLOGNAME ""									// turns off app-level logging for now
			//const char *LOGNAME = "";
			#define RAWNAME "raw.log"
			//const char *RAWNAME "raw.log"

			FILE *logstream;
			FILE *rawstream;
			void rawlog(unsigned char *msg, int len, bool flush=false);
			int length;
			int bytes;
			int check_sum;
			//void handleChannelEvent(void);
			int ant_decode_speed_cadence(void);

			USHORT usCadTime1024;			// Time of last bike cadence event (1/1024s)
			USHORT usCadEventCount;			// Bike cadence event count (pedal revolutions)
			USHORT usSpdTime1024;			// Time of last bike speed event (1/1024s)
			USHORT usSpdEventCount;			// Bike speed event count (wheel revolutions)
			BSCState eState;				// state
			USHORT usCadPreviousEventCount;	// Bike cadence previous event count
			USHORT usCadPreviousTime1024;	// Time of previous bike cadence event (1/1024s)
			USHORT usSpdPreviousEventCount;	// Bike speed previous event count
			USHORT usSpdPreviousTime1024;	// Time of previous bike speed event (1/1024s)
			UCHAR ucNoSpdEventCount;		// counter for successive transmissions with no new speed events
			UCHAR ucNoCadEventCount;		// counter for successive transmissions with no new cadence events
			bool ant_coasting;					// coasting flag
			bool ant_stopping;
			ULONG ulCadAcumEventCount;		// Cumulative bike cadence event count (pedal revolutions)
			ULONG ulCadAcumTime1024;		// Cumulative time (1/1024 seconds)
			ULONG ulSpdAcumEventCount;		// Cumulative bike speed event count (wheel revolutions)
			ULONG ulSpdAcumTime1024;		// Cumulative time (1/1024 seconds)
			UCHAR ant_circumference_cm;			// Wheel circumference (cm)
			int ant_decode_hr(void);
			unsigned char txq[TXBUFLEN];
			unsigned short txinptr;
			unsigned short txoutptr;

			unsigned char rxq[RXBUFLEN];
			unsigned short rxinptr;
			unsigned short rxoutptr;

			void destroy(void);
			//int devtype;
			//unsigned long start_time;
			qint64 start_time;
			int handle_channel_event();

		public:
			//int reset(void);									// does resetSystem command
			ANTCHAN *get_channels(void)  { return channels; }
			void test(void);
			void start_logs(int);
			unsigned char ant_hr;
			unsigned char ant_calculated_hr;
			float ant_cadence;
			float ant_wheel_rpm;
			float ant_speed;
			ULONG ulDistance;				// Cumulative distance (cm)
			char mfgr[64];
			char prod[64];
			char serial_number[64];

			libusb_device_handle *handle;
			int set_devtype(int _chan_num, int _devtype);
			//void set_period(int _chan_num, unsigned short _period);  //{ channels[_chan_num].number = _chan_num; channels[_chan_num].period = _period; }
			int set_period(int _chan_num, unsigned short _period);

			//ANTDEV(Console *_console);
//#ifdef WIN32
#if 0
			ANTDEV(Console *_console, FILE *_logstream, WORD _scrollable_attr, SMALL_RECT _scroll_rect, int _SCROLL_LEFT);
#else
			//ANTDEV(FILE *_logstream);
			//ANTDEV(const ANTDEV& copy, QObject *_parent);					// copy constructor
			ANTDEV(QObject* _parent = 0);
#endif
			~ANTDEV(void);
			void clear(void);
			//int start(int _chan_num);
			//int stop(int _chan_num);
			int start(void);
			int start_channel(int _chan);
			int pair_channel(int _chan);
			//int start(Console *_console);

			int stop(void);

			/*
			void set_vid(unsigned short _vid)  { vid = _vid; }
			void set_pid(unsigned short _pid)  { pid = _pid; }
			void set_mfgr(const char *_str)  { strncpy(mfgr, _str, sizeof(mfgr)-1); }
			void set_product(const char *_str)  { strncpy(prod, _str, sizeof(prod)-1); }
			void set_sn(const char *_str)  { strncpy(sn, _str, sizeof(sn)-1); }
			void set_nconfigs(int _n)  { nconfigs = _n; }
			void set_bus_number(unsigned char _x)  { bus_number = _x; }
			void set_device_address(unsigned char _x)  { device_address = _x; }
			void set_ix(int _ix)  { ix = _ix; }
			void set_device(libusb_device *_dev)  {
				device = _dev;
			}
			*/
			libusb_device_descriptor desc;

			//int set(libusb_device _device, libusb_device_descriptor _desc);
			int set_device(libusb_device *_dev);
			libusb_device *get_device(void)  { return device; }
			//void set_handle(libusb_device_handle *_handle)  { handle = _handle; }
			//void set_ix(int _ix)  { ix = _ix; }

			const char *get_mfgr(void)  { return mfgr; }
			const char *get_product(void)  { return prod; }
			const char *get_sn(void)  { return sn; }
			unsigned short get_vid(void)  { return vid; }
			unsigned short get_pid(void)  { return pid; }
			unsigned char get_bus_number(void)  { return bus_number; }
			unsigned char get_device_address(void)  { return device_address; }
			int get_ix(void)  { return ix; }
			int get_nconfigs(void)  { return nconfigs; }
			int get_nifs(void)  { return ifs.size(); }

			void add_intf(INTF _intf);			//{ ifs.push_back(_intf); }

			void dump(FILE *_stream=NULL);
			const char *get_error_string(void)  { return error_string; }

		private slots:
			void writer(void);
			void reader(void);

	};

#endif		// #ifndef _SENTRY_H_

