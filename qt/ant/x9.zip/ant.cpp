
#include <QtCore>

#ifdef _DEBUG
#include <QDebug>
#endif

#include <QDateTime>

#include "ant.h"
#include "anterrs.h"

namespace RACERMATE {

/**********************************************************************************************************
	main site:
		http://libusb.info/

	API documentation:
		http://libusb.sourceforge.net/api-1.0/

	mailing list archives:
		http://marc.info/?l=libusb-devel

	ANT:
		main site:  http://www.thisisant.com/   (log in)
		forum:      http://www.thisisant.com/forum/

 **************************************************************************************************/

ANT::ANT(QObject *_parent) : QObject(_parent) {
	parent = _parent;

	debug_level = 0;

	int status;

	status = init();
	if (status != 0) {
		throw 1;
	}

	return;
}

/**************************************************************************************************

**************************************************************************************************/

ANT::ANT(int _debug_level, QObject *_parent) : QObject(_parent) {
	parent = _parent;

	debug_level = _debug_level;

	int status;

	status = init();
	if (status != 0) {
		throw 1;
	}
}

/**************************************************************************************************

**************************************************************************************************/

ANT::~ANT() {

#ifdef _DEBUG
	int n;
	Q_UNUSED(n);
	n = devices.size();
#endif

	QString s;

	if (debug_level > 1)  {
		qDebug() << "   ~ANT()";
	}


	foreach(int key, devices.keys() ) {
		delete devices.value(key);
	}
	devices.clear();

	if (timer) {
		timer->stop();
	}
	QThread::msleep(shutdown_delay);              // wait for threads to stop
	DEL(timer);


#ifdef _DEBUG
	DEL(tmr);
#endif

	if (usb_device_list) {
		libusb_free_device_list(usb_device_list, 1);
		usb_device_list = NULL;
	}

	if (ctx) {
		libusb_exit(ctx);
		ctx = NULL;
	}

	FCLOSE(logstream);
	DEL(sdirs);
}                    // destructor

/****************************************************************************************

****************************************************************************************/

int ANT::init(void) {
	int status;

	if (debug_level > 0)  {
		QString s;
		sdirs = new RACERMATE::SDIRS(debug_level, "ant");
		s = sdirs->get_debug_dir() + "ant.log";
		logstream = fopen(s.toUtf8().constData(), "wt");
	}

//	cad.push_back(new CAD);
//	sc.push_back(new SC());
//	hr.push_back(new HR());

	shutdown_delay = 50;

#ifdef _DEBUG
	//dbg = true;
	tmr = new RACERMATE::Tmr("ant");
#else
	//	dbg = false;
#endif

	//nants = 0;
	//version = 0L;
	//memset(gstr, 0, sizeof(gstr));


	//critsec = false;

	status = libusb_init(&ctx);
	if (status != 0) {
		if (debug_level > 0)  {
			fprintf(logstream, "libusb_init error = %d\n", status);
			fflush(logstream);
		}
		return 1;
	}

#ifdef _DEBUG
#ifdef WIN32
	libusb_set_debug(ctx, LIBUSB_LOG_LEVEL_DEBUG);
#else
	libusb_set_debug(ctx, LIBUSB_LOG_LEVEL_INFO);                 // prints out more warnings!
#endif
#else
	libusb_set_debug(ctx, LIBUSB_LOG_LEVEL_INFO);                 // prints out more warnings!
#endif

	verstruc = libusb_get_version();
	version = ((verstruc->major << 24) & 0xff000000) | ((verstruc->minor << 16) & 0x00ff0000) | ((verstruc->micro << 8) & 0x0000ff00) | ((verstruc->nano) & 0x000000ff);
	char str[24] = { 0 };
	sprintf(str, "%d.%d.%d.%d", verstruc->major, verstruc->minor, verstruc->micro, verstruc->nano );
	//sprintf(str, "%d.%d.%d.%d", (verstruc->major << 24) & 0xff000000) | ((verstruc->minor << 16) & 0x00ff0000) | ((verstruc->micro << 8) & 0x0000ff00) | ((verstruc->nano) & 0x000000ff);

	//logg("version = %08lx\n", version);          // version 1.0.20.107
	//logg("version = %s\n", str);                   // version 1.0.20.107
	if (debug_level > 0)  {
		fprintf(logstream, "version = %s\n", str);                   // version 1.0.20.107
		fflush(logstream);
	}

#ifdef NEWTHREAD
	thread = new QThread(this);
	timer = new QTimer(0);
	timer->setInterval(100);
	timer->moveToThread(thread);
	bool b;
	b = (bool)connect(timer, SIGNAL(timeout()), this, SLOT(timeout_slot(void)), Qt::DirectConnection);
	Q_ASSERT(b);
	thread->start();
#else
	timer = new QTimer(this);
	timer->setInterval(100);
	start = QDateTime::currentMSecsSinceEpoch();
	connect(timer, SIGNAL(timeout()), this, SLOT(timeout_slot()));					// runs the background scanner
	ticks = 9999;			// to force an immediate first timeout to call scan_for_devices() and start_listening();
	timer->start();																				// problem here
#endif

	return 0;
}                    // init()


/********************************************************************************************************

********************************************************************************************************/
/*
void ANT::logg(const char *format, ...) {

	if (logstream == NULL) {
		return;
	}

	if (format == NULL) {
		return;
	}

	va_list ap;                                        // Argument pointer


	va_start(ap, format);
	vsprintf(logstr, format, ap);
	va_end(ap);


#ifdef _DEBUG
	//qDebug() << rstrip(QString((char*)(logstr)));
#endif

	fprintf(logstream, "%s", logstr);
	return;
}                                // logg()
*/


/**********************************************************************************************************

**********************************************************************************************************/

/*
QString ANT::rstrip(const QString& str) {
	int n = str.size() - 1;

	for (; n >= 0; --n) {
		if (!str.at(n).isSpace()) {
			//if (!str.at(n)==0x0a) {
			return str.left(n + 1);
		}
	}
	return "";
}
*/


/**********************************************************************************************************
	merges rx0.log and tx0.log
**********************************************************************************************************/

void ANT::merge_log_files(void) {


	QFile::copy("rx0.log", "x.x");

#ifdef WIN32
	int status;
	const char *cmd1 = "c:\\cygwin64\\bin\\cat tx0.log >> x.x";
	status = system(cmd1);

	const char *cmd2 = "c:\\cygwin64\\bin\\sort x.x > d.txt";
	status = system(cmd2);
#endif

	QDir dir;
	dir.remove("x.x");
	//	unlink("rx0.log");
	//	unlink("tx0.log");


	return;
}

/**********************************************************************************************************
	scans for ant sticks and ant sensors
	takes about 6 ms
**********************************************************************************************************/

int ANT::scan_for_devices(void) {

#ifdef _DEBUG
	static int calls = 0;
	calls++;
#endif

	critsec = true;

#ifdef _DEBUG
	if (calls == 1) {
		tmr->start();
	}
	else if (calls == 2)
	{
		bp = 3;
	}
#endif


	int rc = 0;
	int status = 0;
	ssize_t cnt;
	libusb_device *device;
	int k;
	bool is_ant_stick;
	int i, key;
	char sn[64];
	libusb_config_descriptor *config = NULL;
	libusb_device_handle *handle = NULL;


	if (ctx == NULL) {
		rc = RMANT_ERROR_NO_CTX;
		goto finis;
	}

	cnt = libusb_get_device_list(ctx, &usb_device_list);         // 16 with 2 ant sticks, 15 with 1 ant stick


	if (cnt <= 0) {
		rc = RMANT_ERROR_NO_USB_DEVICES;
		goto finis;
	}

	for (k = 0; k < cnt; k++) {
		libusb_device_descriptor desc;
		device = usb_device_list[k];

#ifdef _DEBUG
		if (k==6)  {
			bp = 2;
		}
#endif

		status = libusb_get_device_descriptor(device, &desc);       // desc.idVendor, desc.idProduct
		if (status != 0) {
			rc = RMANT_ERROR_GET_DEVICE_DESCRIPTOR;
			goto finis;
		}

		config = NULL;

		status = libusb_get_config_descriptor(device, 0, &config);

		if (status != 0) {
			if (config) {
				libusb_free_config_descriptor(config);
				config = NULL;
			}
			continue;
		}

		if (config->bNumInterfaces == 0) {
			libusb_free_config_descriptor(config);
			config = NULL;
			continue;
		}

#ifdef _DEBUG
		if (k==6)  {
			bp = 2;
		}
#endif

		libusb_free_config_descriptor(config);
		config = NULL;

		is_ant_stick = false;

		switch(desc.idVendor)  {
			case DYNASTREAM_VID:
				is_ant_stick = true;                                   // true for suunto and garmin
				switch(desc.idProduct)  {
					case ANT_Development_Board1:		// 0x1003
						break;
					case ANTUSB_Stick:					// 0x1004
						bp = 1;
						break;
					case ANT_Development_Board2:		// 0x1006
						bp = 1;
						break;
					case ANTUSB2_Stick:					// 0x1008, my Garmin USB2 stick AND the suunto stick
						bp = 1;
						break;
					case ANTUSB_m_Stick:					// 0x1009, my new Garmin mini stick
						bp = 1;
						break;
					default:
						bp = 2;
						break;
				}
				break;
			default:
				bp = 0;
				break;
		}


		if (!is_ant_stick) {
			continue;
		}



#ifdef _DEBUG
		if (calls == 2) {
			if (k == 4) {
				bp = 2;
			}
		}
#endif


		status = libusb_open(device, &handle); // Open a device and obtain a device handle
		switch (status) {
			case 0: {                           // on success
				break;
			}
			case LIBUSB_ERROR_NO_MEM:        // -11	on memory allocation failure
			case LIBUSB_ERROR_ACCESS:        // -3		if the user has insufficient permissions, on linux edit /etc/udev/rules.d/myusbs.rules. Had to reboot to get it to take!
			case LIBUSB_ERROR_NO_DEVICE: {   // -4		if the device has been disconnected
				rc = status;
				goto finis;
			}
			default:
				rc = status;
				goto finis;
		}

		if (libusb_kernel_driver_active(handle, 0) == 1) {          //find out if kernel driver is attached
			//qDebug() << "Kernel Driver Active";

			if (libusb_detach_kernel_driver(handle, 0) != 0) {             //detach it
				rc = RMANT_ERROR_DETACHING;
				goto finis;
			}
			else  {
				//qDebug() << "Kernel Driver Detached!";
			}
		}

		key = desc.idProduct + desc.idVendor;

		status = libusb_get_string_descriptor_ascii(handle, desc.iSerialNumber, (unsigned char*)sn, sizeof(sn));			// returns < 0 on error
		if (status < 0)  {
			if (status == LIBUSB_ERROR_NOT_FOUND) {
				//if (auto_claim(transfer, &current_interface, USB_API_WINUSBX) != LIBUSB_SUCCESS)
				//	return LIBUSB_ERROR_NOT_FOUND;
				bp = 2;
			}
			else  {
				bp = 3;
			}
			libusb_close(handle);
			handle = NULL;
			rc = status;
			goto finis;
		}

		libusb_close(handle);
		handle = NULL;


		for (i = 0; i < (int)strlen(sn); i++) {
			key += sn[i];
		}

#ifdef _DEBUG
		if (calls == 2) {
			bp = 2;
		}
		if (devices.size()==1)  {
			bp = 4;
		}
#endif

		if (!devices.contains(key)) {
#ifdef _DEBUG
			if (calls > 1) {
				bp = 2;
			}
#endif

			devices[key] = new ANTDEV(debug_level, key, this);              // grows here

			status = devices[key]->set_device(device);
			if (status != 0) {
				bp = 1;
			}
			//antdevs[key]->start();			// starts the communication timers and does ANTMsg::resetSystem(), ANTMsg::setNetworkKey(net, key)
		}                          // if (!antdevs.contains(key))  {
		else {
			bp = 1;
		}
	}                             // devices, for(k)

#ifdef _DEBUG
	dump_antdevs();
#endif


	foreach(int key, devices.keys() ) {
		devices.value(key)->start();				// uses libusb to reset the stick and set the network key
		QThread::msleep(500);
	}

	//	if (usb_device_list) {
	//		libusb_free_device_list(usb_device_list, 1);
	//		usb_device_list = NULL;
	//	}

finis:
#ifdef _DEBUG
	Q_ASSERT(config == NULL);
	Q_ASSERT(handle == NULL);
#endif

	//	if (usb_device_list) {
	//		libusb_free_device_list(usb_device_list, 1);
	//		usb_device_list = NULL;
	//	}

#ifdef _DEBUG
	if (calls == 1) {
		tmr->stop();
		double dt = tmr->get_seconds();                    // 9 ms
		Q_UNUSED(dt);
	}
#endif

#ifdef _DEBUG
	if (rc != 0) {
		bp = 7;
	}
#endif

	critsec = false;
	return rc;

}										// scan_for_devices()


/**********************************************************************************************************

**********************************************************************************************************/

void ANT::dump_antdevs(void) {
	ANTDEV *ad;

	qDebug("\nANTDEVS:");
	bp = 0;
	foreach(int key, devices.keys() ) {
		ad = devices.value(key);
		qDebug("    %s   %s", ad->mfgr, ad->prod);
		bp++;
	}

	return;
}						// dump_antdevs()


/**********************************************************************************************************
	sets up channel 7 of the first ant stick (device) to do background scan
	see pdf file, page 7
	Figure 5-2. Configuring Background Scanning Channel

	returns
		0 if OK
		1 if no devices
**********************************************************************************************************/

int ANT::start_listening()  {
	int rc = 0;
	//int chan = 7;
	ANTDEV *device;

	if (devices.size()==0)  {
		rc = RMANT_ERROR_NO_DEVICES;
		goto done;
	}

	device = devices.first();

	rc = device->start_listening();


done:
	return rc;
}                          // start_listening()

/**********************************************************************************************************

**********************************************************************************************************/
/*
int ANT::update()  {

	if (devices.size()==0)  {
		rc = RMANT_ERROR_NO_DEVICES;
		goto done;
	}

	device = devices.first();

	rc = device->start_listening();

	return 0;
}
*/

/**************************************************************************
	every 100 ms
**************************************************************************/


void ANT::timeout_slot() {
#ifdef _DEBUG
	//tmr->update();									// 100 ms
#endif
	//scan();
	// xyzzy
	ticks++;
	if (ticks < 30)  {								// every 3000 ms
		return;
	}

	ticks = 0;


	int status = scan_for_devices();



	ANTDEV *device;

	if (devices.size()==0)  {
		return;
	}

	device = devices.first();

	if (!device->is_listening())  {
		int status;
		Q_UNUSED(status);
		status = device->open_listening_channel();
	}




	/*
	if (!device->listening)  {
		int status;
		device->open_channel[3] = 0;
		device->checksum(device->open_channel, sizeof(device->open_channel));
		status = device->send(device->open_channel, sizeof(device->open_channel));
		if (status) {
			strcpy(device->error_string, "open channel failed 1");
			return;
		}
		if (!device->wfr(OPEN_CHANNEL, RESPONSE_TIMEOUT)) {
			strcpy(device->error_string, "open channel failed 2");
			return;
		}
		device->listening = true;
	}
	*/


	return;
}                    // timeout()

/**************************************************************************

**************************************************************************/


const char * ANT::get_sensors() {
	if (devices.size()==0)  {
		return NULL;
	}

	ANTDEV *device;
	const char *ccptr;

	device = devices.first();
	ccptr = device->get_sensors();

	return ccptr;
}


#ifdef NEWTHREAD


/********************************************************************************************************

********************************************************************************************************/

int ANT::stop(void) {

	thread->exit();
	timer->deleteLater();

	QThread::msleep(500);         // wait for communication to the ANT sticks to stop (just in case)

//	if (handle) {
//		libusb_close(handle);
//		handle = NULL;
//	}

	return 0;
}                                // stop()
#endif

}		// namespace RACERMATE
