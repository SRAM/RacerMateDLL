
#include <stdint.h>

#include <QMap>


#ifdef WIN32
	#include <windows.h>
	#include <winbase.h>
#endif

//#include "ANT.h"
//#include "ANTChannel.h"

//#include <utils.h>

#define ANT_MAX_MESSAGE_SIZE 12

//#define ANT_MAX_DATA_MESSAGE_SIZE    8
// ANT messages
#define ANT_UNASSIGN_CHANNEL   0x41
#define ANT_ASSIGN_CHANNEL     0x42
#define ANT_CHANNEL_ID         0x51
#define ANT_CHANNEL_PERIOD     0x43
#define ANT_SEARCH_TIMEOUT     0x44
#define ANT_CHANNEL_FREQUENCY  0x45
#define ANT_SET_NETWORK        0x46
#define ANT_TX_POWER           0x47
#define ANT_ID_LIST_ADD        0x59
#define ANT_ID_LIST_CONFIG     0x5A
#define ANT_CHANNEL_TX_POWER   0x60
#define ANT_LP_SEARCH_TIMEOUT  0x63
#define ANT_SET_SERIAL_NUMBER  0x65
#define ANT_ENABLE_EXT_MSGS    0x66
#define ANT_ENABLE_LED         0x68
#define ANT_SYSTEM_RESET       0x4A
#define ANT_OPEN_CHANNEL       0x4B
#define ANT_CLOSE_CHANNEL      0x4C
#define ANT_OPEN_RX_SCAN_CH    0x5B
#define ANT_REQ_MESSAGE        0x4D
#define ANT_BROADCAST_DATA     0x4E
#define ANT_ACK_DATA           0x4F
#define ANT_BURST_DATA         0x50
#define ANT_CHANNEL_EVENT      0x40
#define ANT_CHANNEL_STATUS     0x52
#define ANT_CHANNEL_ID         0x51
#define ANT_VERSION            0x3E
#define ANT_CAPABILITIES       0x54
#define ANT_SERIAL_NUMBER      0x61
#define ANT_CW_INIT            0x53
#define ANT_CW_TEST            0x48

#define ANT_PROXIMITY_SEARCH		0x71


// these from dynastream's ANTMsg.h:

#define MESG_STARTUP_MESG_ID                 ((UCHAR)0x6F)
#define MESG_INVALID_ID                      ((UCHAR)0x00)

// ANT message structure.
#define ANT_OFFSET_SYNC            0
#define ANT_OFFSET_LENGTH          1
#define ANT_OFFSET_ID              2
#define ANT_OFFSET_DATA            3
#define ANT_OFFSET_CHANNEL_NUMBER  3
#define ANT_OFFSET_MESSAGE_ID      4
#define ANT_OFFSET_MESSAGE_CODE    5

// other ANT stuff
#define ANT_SYNC_BYTE        0xA4
#define ANT_MAX_LENGTH       14												// was 9 but the version message is 11 bytes! data message is 14 bytes
#define ANT_KEY_LENGTH       8
#define ANT_MAX_BURST_DATA   8
#define ANT_MAX_MESSAGE_SIZE 12
#define ANT_MAX_CHANNELS     8

//---------------------
// Channel messages
//---------------------

#define RESPONSE_NO_ERROR               0
#define EVENT_RX_SEARCH_TIMEOUT         1
#define EVENT_RX_FAIL                   2
#define EVENT_TX                        3
#define EVENT_TRANSFER_RX_FAILED        4
#define EVENT_TRANSFER_TX_COMPLETED     5
#define EVENT_TRANSFER_TX_FAILED        6
#define EVENT_CHANNEL_CLOSED            7
#define EVENT_RX_BROADCAST             10
#define EVENT_RX_ACKNOWLEDGED          11
#define EVENT_RX_BURST_PACKET          12
#define CHANNEL_IN_WRONG_STATE         21
#define CHANNEL_NOT_OPENED             22
#define CHANNEL_ID_NOT_SET             24
#define TRANSFER_IN_PROGRESS           31
#define TRANSFER_SEQUENCE_NUMBER_ERROR 32
#define INVALID_MESSAGE                40
#define INVALID_NETWORK_NUMBER         41

// ANT+sport
#define ANT_SPORT_HR_PERIOD 8070
#define ANT_SPORT_POWER_PERIOD 8182
#define ANT_SPORT_SPEED_PERIOD 8118
#define ANT_SPORT_CADENCE_PERIOD 8102
#define ANT_SPORT_SandC_PERIOD 8086
#define ANT_FAST_QUARQ_PERIOD (8182/16)
#define ANT_QUARQ_PERIOD (8182*4)

#define ANT_SPORT_HR_TYPE 0x78
#define ANT_SPORT_POWER_TYPE 11
#define ANT_SPORT_SPEED_TYPE 0x7B
#define ANT_SPORT_CADENCE_TYPE 0x7A
#define ANT_SPORT_SandC_TYPE 0x79
#define ANT_FAST_QUARQ_TYPE_WAS 11 // before release 1.8
#define ANT_FAST_QUARQ_TYPE 0x60
#define ANT_QUARQ_TYPE 0x60

#define ANT_SPORT_FREQUENCY 57
#define ANT_FAST_QUARQ_FREQUENCY 61
#define ANT_QUARQ_FREQUENCY 61

#define ANT_SPORT_CALIBRATION_MESSAGE                 0x01

// Calibration messages carry a calibration id
#define ANT_SPORT_SRM_CALIBRATIONID                   0x10
#define ANT_SPORT_CALIBRATION_REQUEST_MANUALZERO      0xAA
#define ANT_SPORT_CALIBRATION_REQUEST_AUTOZERO_CONFIG 0xAB
#define ANT_SPORT_ZEROOFFSET_SUCCESS                  0xAC
#define ANT_SPORT_AUTOZERO_SUCCESS                    0xAC
#define ANT_SPORT_ZEROOFFSET_FAIL                     0xAF
#define ANT_SPORT_AUTOZERO_FAIL                       0xAF
#define ANT_SPORT_AUTOZERO_SUPPORT                    0x12

#define ANT_SPORT_AUTOZERO_OFF                        0x00
#define ANT_SPORT_AUTOZERO_ON                         0x01


// from dynastream:

#define MESG_NETWORK_KEY_ID                  ((UCHAR)0x46)

//////////////////////////////////////////////
// Standard capabilities defines
//////////////////////////////////////////////
#define CAPABILITIES_NO_RX_CHANNELS                ((UCHAR)0x01)
#define CAPABILITIES_NO_TX_CHANNELS                ((UCHAR)0x02)
#define CAPABILITIES_NO_RX_MESSAGES                ((UCHAR)0x04)
#define CAPABILITIES_NO_TX_MESSAGES                ((UCHAR)0x08)
#define CAPABILITIES_NO_ACKD_MESSAGES              ((UCHAR)0x10)
#define CAPABILITIES_NO_BURST_TRANSFER             ((UCHAR)0x20)

//////////////////////////////////////////////
// Advanced capabilities defines
//////////////////////////////////////////////
#define CAPABILITIES_OVERUN_UNDERRUN               ((UCHAR)0x01)     // Support for this functionality has been dropped
#define CAPABILITIES_NETWORK_ENABLED               ((UCHAR)0x02)
#define CAPABILITIES_AP1_VERSION_2                 ((UCHAR)0x04)     // This Version of the AP1 does not support transmit and only had a limited release
#define CAPABILITIES_SERIAL_NUMBER_ENABLED         ((UCHAR)0x08)
#define CAPABILITIES_PER_CHANNEL_TX_POWER_ENABLED  ((UCHAR)0x10)
#define CAPABILITIES_LOW_PRIORITY_SEARCH_ENABLED   ((UCHAR)0x20)
#define CAPABILITIES_SCRIPT_ENABLED                ((UCHAR)0x40)
#define CAPABILITIES_SEARCH_LIST_ENABLED           ((UCHAR)0x80)

//////////////////////////////////////////////
// Advanced capabilities 2 defines
//////////////////////////////////////////////
#define CAPABILITIES_LED_ENABLED                   ((UCHAR)0x01)
#define CAPABILITIES_EXT_MESSAGE_ENABLED           ((UCHAR)0x02)
#define CAPABILITIES_SCAN_MODE_ENABLED             ((UCHAR)0x04)
#define CAPABILITIES_RESERVED                      ((UCHAR)0x08)
#define CAPABILITIES_PROX_SEARCH_ENABLED           ((UCHAR)0x10)
#define CAPABILITIES_EXT_ASSIGN_ENABLED            ((UCHAR)0x20)
#define CAPABILITIES_FS_ANTFS_ENABLED              ((UCHAR)0x40)
#define CAPABILITIES_FIT1_ENABLED                  ((UCHAR)0x80)

//////////////////////////////////////////////
// Advanced capabilities 3 defines
//////////////////////////////////////////////
#define CAPABILITIES_SENSRCORE_ENABLED             ((UCHAR)0x01)
#define CAPABILITIES_RESERVED_1                    ((UCHAR)0x02)
#define CAPABILITIES_RESERVED_2                    ((UCHAR)0x04)
#define CAPABILITIES_RESERVED_3                    ((UCHAR)0x08)



#ifndef gc_ANTMsg_h
#define gc_ANTMsg_h

class ANTMsg {

	private:
		#ifdef _DEBUG
		int bp;
		#endif

	public:

		ANTMsg(); // null message
		//ANTMsg(ANT *parent, const unsigned char *data); // decode from parameters
		ANTMsg(const unsigned char *data); // decode from parameters
		ANTMsg(
				unsigned char b1,						// length
				unsigned char b2 = '\0',			// type
				unsigned char b3 = '\0',
				unsigned char b4 = '\0',
				unsigned char b5 = '\0',
				unsigned char b6 = '\0',
				unsigned char b7 = '\0',
				unsigned char b8 = '\0',
				unsigned char b9 = '\0',
				unsigned char b10 = '\0',
				unsigned char b11 = '\0'
				); // encode with values (at least one value must be passed though)

		//static QMap<int, QString> msg_strings;

		/*
		static QMap<int, QString> msg_strings  {
			{ ANT_UNASSIGN_CHANNEL, "ANT_UNASSIGN_CHANNEL" },
			{ ANT_ASSIGN_CHANNEL, "ANT_ASSIGN_CHANNEL" },
			{ ANT_CHANNEL_ID, "ANT_CHANNEL_ID" },
			{ ANT_CHANNEL_PERIOD, "ANT_CHANNEL_PERIOD" },
			{ ANT_SEARCH_TIMEOUT, "ANT_SEARCH_TIMEOUT" },
			{ ANT_CHANNEL_FREQUENCY, "ANT_CHANNEL_FREQUENCY" },
			{ ANT_SET_NETWORK, "ANT_SET_NETWORK" },
			{ ANT_TX_POWER, "ANT_TX_POWER" },
			{ ANT_ID_LIST_ADD, "ANT_ID_LIST_ADD" },
			{ ANT_ID_LIST_CONFIG, "ANT_ID_LIST_CONFIG" },
			{ ANT_CHANNEL_TX_POWER, "ANT_CHANNEL_TX_POWER" },
			{ ANT_LP_SEARCH_TIMEOUT, "ANT_LP_SEARCH_TIMEOUT" },
			{ ANT_SET_SERIAL_NUMBER, "ANT_SET_SERIAL_NUMBER" },
			{ ANT_ENABLE_EXT_MSGS, "ANT_ENABLE_EXT_MSGS" },
			{ ANT_ENABLE_LED, "ANT_ENABLE_LED" },
			{ ANT_SYSTEM_RESET, "ANT_SYSTEM_RESET" },
			{ ANT_OPEN_CHANNEL, "ANT_OPEN_CHANNEL" },
			{ ANT_CLOSE_CHANNEL, "ANT_CLOSE_CHANNEL" },
			{ ANT_OPEN_RX_SCAN_CH, "ANT_OPEN_RX_SCAN_CH" },
			{ ANT_REQ_MESSAGE, "ANT_REQ_MESSAGE" },
			{ ANT_BROADCAST_DATA, "ANT_BROADCAST_DATA" },
			{ ANT_ACK_DATA, "ANT_ACK_DATA" },
			{ ANT_BURST_DATA, "ANT_BURST_DATA" },
			{ ANT_CHANNEL_EVENT, "ANT_CHANNEL_EVENT" },
			{ ANT_CHANNEL_STATUS, "ANT_CHANNEL_STATUS" },
			{ ANT_CHANNEL_ID, "ANT_CHANNEL_ID" },
			{ ANT_VERSION, "ANT_VERSION" },
			{ ANT_CAPABILITIES, "ANT_CAPABILITIES" },
			{ ANT_SERIAL_NUMBER, "ANT_SERIAL_NUMBER" },
			{ ANT_CW_INIT, "ANT_CW_INIT" },
			{ ANT_CW_TEST, "ANT_CW_TEST" },
			{ ANT_PROXIMITY_SEARCH, "ANT_PROXIMITY_SEARCH" }
		};
		*/

		// convenience functions for encoding messages
		static ANTMsg resetSystem();

		static ANTMsg assignChannel(
				const unsigned char channel,
				const unsigned char type,
				const unsigned char network,
				const unsigned char _extended=0x00);

		static ANTMsg boostSignal(const unsigned char channel);
		static ANTMsg unassignChannel(const unsigned char channel);
		static ANTMsg setSearchTimeout(const unsigned char channel,const unsigned char timeout);
		static ANTMsg setLPSearchTimeout(const unsigned char channel,const unsigned char timeout);

		static ANTMsg requestMessage(const unsigned char channel,
				const unsigned char request);
		static ANTMsg setChannelID(const unsigned char channel,
				const unsigned short device,
				const unsigned char devicetype,
				const unsigned char txtype);
		static ANTMsg setChannelPeriod(const unsigned char channel,
				const unsigned short period);
		static ANTMsg setChannelFreq(const unsigned char channel,	const unsigned char frequency);
		static ANTMsg setChannelTransmitPower(const unsigned char channel,	const unsigned char _power);			// tlm
		static ANTMsg setNetworkKey(const unsigned char net, const unsigned char *key);
		static ANTMsg setAutoCalibrate(const unsigned char channel, bool autozero);
		static ANTMsg requestCalibrate(const unsigned char channel);
		static ANTMsg open(const unsigned char channel);
		static ANTMsg close(const unsigned char channel);
		static ANTMsg get_caps(const unsigned char channel);								// i don't think that channels is required, but there is a '0' in the packet
		static ANTMsg get_serial_number(const unsigned char channel);					// i don't think that channels is required, but there is a '0' in the packet
		static ANTMsg get_version(const unsigned char _chan);
		static ANTMsg get_channel_status(const unsigned char channel);
		static ANTMsg set_extended_messages(const unsigned char channel);
		static ANTMsg get_channel_id(const unsigned char channel);

		// convert a channel event message id to human readable string
		static const char * channelEventMessage(unsigned char c);

		// to avoid a myriad of tedious set/getters the data fields
		// are plain public members. This is unlikely to change in the
		// future since the whole purpose of this class is to encode
		// and decode ANT messages into the member variables below.

		// BEAR IN MIND THAT ONLY A HANDFUL OF THE VARS WILL BE SET
		// DURING DECODING, SO YOU *MUST* EXAMINE THE MESSAGE TYPE
		// TO DECIDE WHICH FIELDS TO REFERENCE

		// Standard ANT values
		int length;
		unsigned char data[ANT_MAX_MESSAGE_SIZE+1]; // include sync byte at front
		double timestamp;
		uint8_t sync, type;
		uint8_t transmitPower, searchTimeout, transmissionType, networkNumber, channelType, channel, deviceType, frequency;
		uint16_t channelPeriod, deviceNumber;
		uint8_t key[8];

		// ANT Sport values
		uint8_t data_page, calibrationID, ctfID;
		uint16_t srmOffset, srmSlope, srmSerial;
		uint8_t eventCount;
		uint8_t pedalPower;
		uint16_t measurementTime, wheelMeasurementTime, crankMeasurementTime;
		uint8_t heartrateBeats, instantHeartrate; // heartrate
		uint16_t slope, period, torque; // power
		uint16_t sumPower, instantPower; // power
		uint16_t wheelRevolutions, crankRevolutions; // speed and power and cadence
		uint8_t instantCadence; // cadence
		uint8_t autoZeroStatus, autoZeroEnable;

	private:
		void init();

		static inline double get_timestamp( void ) {
#ifdef WIN32
			//struct timeval tv;
			//gettimeofday(&tv, NULL);
			//return tv.tv_sec * 1.0 + tv.tv_usec * 1.0e-6;
			return 0.0;
#else
			return 0.0;
#endif
		}


};
#endif
