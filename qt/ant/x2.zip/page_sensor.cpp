

#include "page_sensor.h"


/**************************************************************************************

**************************************************************************************/

int PAGE_SENSOR::reset(void)  {
//	ANT::reset();

	page = PAGE0;

	//val = 0x00;
	//calculated_val = 0x00;

	ulAcumTime1024 = 0L;
	decode_time = 0L;
	previous_event_count = 0;
	previous_time_1024 = 0;
	time_1024 = 0;
	event_count = 0;
	elapsed_time2 = 0L;
	mfgr_id = 0;
	sernum = 0;
	hw_version = 0;
	sw_version = 0;
	model = 0;
	no_event_count = 0;
	acum_event_count = 0;
	rr_interval_1024 = 0;
	memset(ant_packet, 0, 8);
	//MAX_NO_EVENTS = 12;						// Maximum number of messages with no new events (3s)

	return 0;
}													// PAGE_SENSOR::reset()



/**************************************************************************************

**************************************************************************************/

//PAGE_SENSOR::PAGE_SENSOR(void) : ANT()  {
PAGE_SENSOR::PAGE_SENSOR(void)  {
#ifdef _DEBUG
	bp = 1;
#endif
	init();							// PAGE_SENSOR::init()
	return;
}										// ANT::ANT()


/**************************************************************************************

**************************************************************************************/

int PAGE_SENSOR::init(void)  {
	reset();
	return 0;
}

#if 0

/**************************************************************************************

**************************************************************************************/

float PAGE_SENSOR::get_val(void)  {
	if (!decoding_data)  {
		val = 0;
		accum = 0.0f;
		accum_count = 0L;
		return -1.0f;
	}

	if (accum_count==0)  {
		return val;
	}

	float f = accum / accum_count;

	//accum = 0.0f;
	//accum_count = 0L;

#ifdef _DEBUG
	/*
	static bool flag = false;
	if (f > 10.0f)  {
		flag = true;
		ant_bp = 2;
	}
	else  {
		if (flag)  {
			ant_bp = 4;
		}
	}
	*/
#endif

	//return accum_val;
	return f;
}															// HR::get_accum_val()
#endif						// #if 0


/**************************************************************************************

**************************************************************************************/
/*
float PAGE_SENSOR::get_val(void)  {
	if (!decoding_data)  {
		return -1.0f;
	}
	return val;
}															// HR::get_val()
*/

/**************************************************************************************

**************************************************************************************/

#if 0
int PAGE_SENSOR::reset(void)  {
	page = 0;
	previous_event_count = 0;
	event_count = 0;
	mfgr_id = 0;							// Manufacturing ID
	hw_version = 0;						// Hardware version
	sw_version = 0;						// Software version
	model = 0;							// Model number
	no_event_count = 0;				// Successive transmissions with no new cadence events

	previous_time_1024 = 0;
	time_1024 = 0;
	sernum = 0;							// Serial number
	rr_interval_1024 = 0;			// R-R interval (1/1024 seconds), conversion to ms is performed for data display

	ulAcumTime1024 = 0L;				// Cumulative time (1/1024 seconds), conversion to s is performed for data display
	decode_time = 0L;
	elapsed_time2 = 0L;					// Cumulative operating time (elapsed time since battery insertion) in 2 second resolution	
	acum_event_count = 0L;				// Cumulative heart beat event count

	does_exist = false;

	return 0;
}													// PAGE_SENSOR::init()

#endif

