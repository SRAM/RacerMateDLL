/*
//#include <QtGui>
#include <QtCore>
//#include <qwid
//#include <qApplication>


#include "sl.h"

int main(int argc, char *argv[]) {
	//QApplication a(&argc, argv);
	//Widget w;
	QApplication *a = new QApplication(argc, argv);
	Sharedlib sl;
	sl.hello();

	//w.resize(100, 100);
	//w.show();
	return a.exec();
}
*/

#include <QCoreApplication>
#include <QTimer>

#include "sl.h"

int main(int argc, char *argv[])  {
	 QCoreApplication app(argc, argv);
	 Sharedlib sl;
	 sl.hello();

	 /*
	 int debug_level = 2;

	 MainClass myMain(debug_level);

	 QObject::connect(&myMain, SIGNAL(finished()), &app, SLOT(quit()));
	 QObject::connect(&app, SIGNAL(aboutToQuit()), &myMain, SLOT(aboutToQuitApp()));
	*/


	 // This code will start the messaging engine in QT and in
	 // 10ms it will start the execution in the MainClass.run routine;

	 //QTimer::singleShot(10, &myMain, SLOT(run()));

	 return app.exec();
}


