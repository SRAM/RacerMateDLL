/*****************************************

*****************************************/

#ifdef WIN32
	#pragma warning(disable:4996)       // strncpy_s
#else
	#include <stdarg.h>
#endif

#include <assert.h>

#include <QtCore>

#include <utils.h>
#include <sdirs.h>

#include "antdev.h"
#include "anterrs.h"
//#include "antmsg.h"

int ANTDEV::instances = 0;
#ifdef _DEBUG
int ANTDEV::calls = 0;
#endif

// message format, page 34
//																			     sync  len   msg	  ???																	  cs

unsigned char ANTDEV::reset_command[5] =                    { 0xa4, 0x01, 0x4a, 0x00,                                                 0xef };

//                                                                              chan  type  net   ext
unsigned char ANTDEV::assign_channel_command[8] =           { 0xa4, 0x04, 0x42, 0x00, 0x10, 0x00, 0x01,                               0xf3 };
unsigned char ANTDEV::set_extended_messages_command[6] =    { 0xa4, 0x02, 0x66, 0x00, 0x01,                                           0xc1 };
unsigned char ANTDEV::set_channel_id_command[9] =           { 0xa4, 0x05, 0x51, 0x00, 0x00, 0x00, 0x00, 0x00,                         0xf0 };
unsigned char ANTDEV::lp_search_timeout_command[6] =        { 0xa4, 0x02, 0x63, 0x00, 0xff,                                           0x3a };
unsigned char ANTDEV::search_timeout_command[6] =           { 0xa4, 0x02, 0x44, 0x00, 0xff,                                           0x1d };
unsigned char ANTDEV::open_channel_command[5] =             { 0xa4, 0x01, 0x4b, 0x00,                                                 0xee };
unsigned char ANTDEV::get_caps_command[6] =						{ 0xa4, 0x02, 0x4d, 0x00, 0x54,                                           0xbf };
unsigned char ANTDEV::get_channel_status[6] =					{ 0xa4, 0x02, 0x4d, 0x00, 0x52,                                           0x00 };
unsigned char ANTDEV::channel_period[7] =							{ 0xa4, 0x03, 0x43, 0x00, 0x00, 0x00,                                     0x00 };
unsigned char ANTDEV::set_channel_freq[6] = 						{ 0xa4, 0x02, 0x45, 0x00, 0x00,                                           0x00 };

unsigned char ANTDEV::set_network_key_command[13] =         { 0xa4, 0x09, 0x46, 0x00, 0xb9, 0xa5, 0x21, 0xfb, 0xbd, 0x72, 0xc3, 0x45, 0x64 };
const unsigned char ANTDEV::USER_NETWORK_KEY[8] =           {                         0xB9, 0xA5, 0x21, 0xFB, 0xBD, 0x72, 0xC3, 0x45       };


QMap<int, QString> ANTDEV::msg_strings =  {
	{ CHANNEL_EVENT,		 "CHANNEL_EVENT"							},
	{ CHANNEL_ID,			 "CHANNEL_ID"								},
	{ CHANNEL_STATUS,	 "CHANNEL_STATUS"								},
	{ SET_NETWORK_KEY,		 "SET_NETWORK_KEY"					},
	{ MESG_STARTUP_MESG_ID,	 "MESG_STARTUP_MESG_ID"				},
	{ CAPABILITIES,		 "CAPABILITIES"							},
	{ SERIAL_NUMBER,		 "SERIAL_NUMBER"							},
	{ VERSION,				 "VERSION"									},
	{ BROADCAST_DATA,	 "BROADCAST_DATA"								},
	{ ACK_DATA,			 "ACK_DATA"										},
	{ BURST_DATA,			 "BURST_DATA"								},
	{ REQ_MESSAGE,		 "REQ_MESSAGE"									},
	{ SYSTEM_RESET,		 "SYSTEM_RESET"							},
	{ ASSIGN_CHANNEL,	 "ASSIGN_CHANNEL"								},
	{ ENABLE_EXT_MSGS,	 "ENABLE_EXT_MSGS"						},
	{ LP_SEARCH_TIMEOUT, "LP_SEARCH_TIMEOUT"						},
	{ OPEN_CHANNEL,		 "OPEN_CHANNEL"							},
	{ CHANNEL_FREQUENCY,			"CHANNEL_FREQUENCY"				},
	{ SEARCH_TIMEOUT,	 "SEARCH_TIMEOUT"								}
};


QMap<int, QString> ANTDEV::event_strings =  {
	{ EVENT_RX_SEARCH_TIMEOUT, "EVENT_RX_SEARCH_TIMEOUT"			},
	{ CHANNEL_TX_POWER,			"CHANNEL_TX_POWER"					},
	{ MESG_NETWORK_KEY_ID,		"MESG_NETWORK_KEY_ID"				},
	{ ASSIGN_CHANNEL,				"ASSIGN_CHANNEL"						},
	{ CHANNEL_TX_POWER,			"CHANNEL_TX_POWER"					},
	{ CHANNEL_FREQUENCY,			"CHANNEL_FREQUENCY"					},
	{ CHANNEL_ID,					"CHANNEL_ID"							},
	{ CHANNEL_PERIOD,				"CHANNEL_PERIOD"						},
	{ OPEN_CHANNEL,				"OPEN_CHANNEL"							},
	{ LP_SEARCH_TIMEOUT,			"LP_SEARCH_TIMEOUT"					},
	{ SEARCH_TIMEOUT,				"SEARCH_TIMEOUT"						},
	{ CAPABILITIES,				"CAPABILITIES"							},
	{ ENABLE_EXT_MSGS,			"ENABLE_EXT_MSGS"						}
};

QMap<int, QString> ANTDEV::startup_strings =  {
	{ RESET_POR,	  "RESET_POR"			 },
	{ RESET_SUSPEND, "RESET_SUSPEND"		 },
	{ RESET_SYNC,	  "RESET_SYNC"			 },
	{ RESET_CMD,	  "RESET_CMD"			 },
	{ RESET_WDT,	  "RESET_WDT"			 },
	{ RESET_RST,	  "RESET_RST"			 }
};





/****************************************************************************
	constructor 1
****************************************************************************/

ANTDEV::ANTDEV(int _debug_level, int _key, QObject* _parent ) : QObject(_parent) {
	debug_level = _debug_level;
	key = _key;
	parent = _parent;
	calls++;

	/*
		const unsigned char chan=0, type=0, net=0, ext=0, devnum = 0, devtype = 0, txtype = 0, freq = 0, period=0;
		ANTMsg m;
		m = ANTMsg::get_channel_id(chan);								// a4 02 4d 00 51 ba
		m = ANTMsg::get_channel_status(chan);							// a4 02 4d 00 51 b9
		m = ANTMsg::get_serial_number(chan);							// a4 02 4d 00 61 8a
		m = ANTMsg::get_version(chan);									// a4 02 4d 00 3e d5

		m = ANTMsg::setChannelPeriod(chan, period);					// a4 03 43 00 00 00 e4
		m = ANTMsg::setChannelTransmitPower(chan, 3);				// a4 02 60 00 03 c5
	 */

	init();

	initialized = true;
	instances++;
	return;
}


/******************************************************************************

******************************************************************************/

ANTDEV::~ANTDEV(void) {

	DEL(tmr);

	stop();

#ifdef _DEBUG
	double dt;

	dt = (double)maxlogwait / 1000000.0;
	logg("maxlogwait = %.5lf ms\n", dt);                        // 0.0011 ms

	dt = (double)maxdumpwait / 1000000.0;
	logg("maxdumpwait = %.5lf ms\n", dt);                       // 0.0011 ms

	dt = (double)maxwfr / 1000000.0;
	logg("maxwfrne = %.5lf ms\n", dt);                          // 502 ms

#endif



	FCLOSE(logstream);

	instances--;

}

/******************************************************************************

******************************************************************************/

int ANTDEV::init(void) {
	int i;

	RACERMATE::SDIRS *sdirs = new RACERMATE::SDIRS(debug_level, "ant");

	if (debug_level > 0) {
		QString s = sdirs->get_debug_dir() + "antdev-" + QString::number(key) + ".log";
		logstream = fopen(s.toUtf8().constData(), "wt");
	}

	DEL(sdirs);


	somethread = NULL;

	char str[32];
	tmr = NULL;
	sprintf(str, "antdev%d", key);
	tmr = new RACERMATE::Tmr(str);

	//devtype = -1;
	memset(&desc, 0, sizeof(desc));

	tid = -1;
	sequence = 0L;                                  // for logging


	id = -1;
	inpackets = 0;
	outpackets = 0;
	process_count = 0;
	ucStandardOptions = 0;
	ucAdvanced = 0;
	ucAdvanced2 = 0;
	msgdone = false;
	sernum = 0L;
	memset(sernum_string, 0, sizeof(sernum_string));
	memset(version, 0, sizeof(version));
	extended = false;                                        // if it can do extended messages

	memcpy(user_network_key, USER_NETWORK_KEY, sizeof(user_network_key));
	memset(rxMessage, 0, sizeof(rxMessage));
	memset(serial_number, 0, sizeof(serial_number));

	net = 0;
	memset(error_string, 0, sizeof(error_string));
	ucStatePage = HRM_INIT_PAGE;           // Track if advanced data is supported

	memset(txq, 0, sizeof(txq));
	memset(rxq, 0, sizeof(rxq));

	ix = 0;
	state = ST_WAIT_FOR_SYNC;
	device = NULL;
	txtimer = NULL;
	rxtimer = NULL;

#ifdef _DEBUG
	memset(rxMessage, 0, sizeof(rxMessage));
#endif

	ucStatePage = HRM_INIT_PAGE;  // Track if advanced data is supported
	ucPreviousEventCount = 0;     // Previous heart beat event count
	usPreviousTime1024 = 0;       // Time of previous heart beat event (1/1024 seconds)
	ucEventCount = 0;             // Heart beat event count
	usTime1024 = 0;               // Time of last heart beat event (1/1024 seconds)
	ant_hr = 0;
	ulElapsedTime2 = 0L;          // Cumulative operating time (elapsed time since battery insertion) in 2 second resolution
	ant_calculated_hr = 0;

	// Background Data

	ucMfgID = 0;               // Manufacturing ID
	ucHwVersion = 0;           // Hardware version
	ucSwVersion = 0;           // Software version
	ucModelNum = 0;            // Model number
	usSerialNum = 0;           // Serial number
	ucNoEventCount = 0;        // Successive transmissions with no new HR events
	ulAcumEventCount = 0L;     // Cumulative heart beat event count
	ulAcumTime1024 = 0L;       // Cumulative time (1/1024 seconds), conversion to s is performed for data display
	usR_RInterval1024 = 0;     // R-R interval (1/1024 seconds), conversion to ms is performed for data display


	usCadTime1024 = 0;
	usCadEventCount = 0;
	usSpdTime1024 = 0;
	usSpdEventCount = 0;
	eState = BSC_INIT;
	usCadPreviousEventCount = 0;
	usCadPreviousTime1024 = 0;
	usSpdPreviousEventCount = 0;
	usSpdPreviousTime1024 = 0;
	ucNoSpdEventCount = 0;
	ucNoCadEventCount = 0;
	ant_coasting = 0;
	ant_stopping = 0;
	ulCadAcumEventCount = 0;
	ulCadAcumTime1024 = 0;
	ant_cadence = 0;
	ulSpdAcumEventCount = 0;
	ulSpdAcumTime1024 = 0;
	ant_circumference_cm = 0;
	ant_wheel_rpm = 0;
	ant_speed = 0;
	ulDistance = 0;


#ifdef _DEBUG
	bp = 0;
	hrcalls = 0;
	sccalls = 0;
#endif

	length = 0;
	bytes = 0;
	check_sum = 0;

	oktobreak = false;
	initialized = false;
	handle = NULL;

	total_tx_seconds = 0.0;
	tx_calls = 0L;

	total_rx_seconds = 0.0;
	rx_calls = 0L;
	read_calls = 0L;

	clear();

	for (i = 0; i < NANTCHANS; i++) {
		#ifdef _DEBUG
		bp = i;
		#endif
	}

	#ifdef _DEBUG
	bp = 0;
	#endif

	ant_circumference_cm = 70;

	start_time = QDateTime::currentMSecsSinceEpoch();
	et.start();

	initialized = true;

	tid = (unsigned long)QThread::currentThreadId();
	lock_logging();
	///logg("ANTDEV::init(), tid = %ld", tid);
	unlock_logging();

	return 0;
}                       // init()

/******************************************************************************

******************************************************************************/

void ANTDEV::clear(void) {
	if (handle) {
		libusb_close(handle);
		handle = NULL;
	}

	txinptr = 0;
	txoutptr = 0;
	rxinptr = 0;
	rxoutptr = 0;

	vid = 0;
	pid = 0;
	memset(mfgr, 0, sizeof(mfgr));
	memset(prod, 0, sizeof(prod));
	memset(sn, 0, sizeof(sn));
	nconfigs = 0;
	bus_number = 0;
	device_address = 0;
	int i, n;
	n = ifs.size();

	for (i = 0; i < n; i++) {
		ifs[i].clear();
	}

	ifs.clear();

	return;
}

/******************************************************************************

******************************************************************************/

void ANTDEV::add_intf(INTF _intf) {
	ifs.push_back(_intf);
	return;
}

/******************************************************************************

******************************************************************************/

void ANTDEV::dump(FILE *_stream) {

	if (_stream == NULL) {
		return;
	}

	fprintf(_stream, "\n");

	fprintf(_stream, "manufacturer = %s\n", mfgr);
	fprintf(_stream, "product = %s\n", prod);
	fprintf(_stream, "vendor = %d\n", vid);
	fprintf(_stream, "product = %d\n", pid);
	fprintf(_stream, "bus number = %d\n", bus_number);
	fprintf(_stream, "device address = %d\n", device_address);
	fprintf(_stream, "sn = %s\n", sn);
	fprintf(_stream, "ix = %d\n", ix);
	fprintf(_stream, "nconfigs = %d\n", nconfigs);
	fprintf(_stream, "ifs.size() = %lu\n", ifs.size());

	return;
}


/**************************************************************************************************
	called from writer thread
**************************************************************************************************/

int ANTDEV::tx(unsigned char *_buf, int _n, unsigned long _timeout) {
	int written = 0, total = 0, wep = 0, status = 0;
	bool flag;
	int i, n, rc = -1;


	if (txinptr == txoutptr) {
		return 0;
	}

	if (handle == NULL) {
		return -1;
	}

	tx_calls++;

	wep = 1;                                  // write to address 1
	total = 0;
	i = 0;
	n = _n;
	flag = true;


	while (flag) {
		status = libusb_bulk_transfer( handle, wep, &_buf[i], n, &written, _timeout );

		switch (status) {
			case 0: {
				if (written == _n) {
					flag = false;
					rc = _n;
				}
				else  {
					total += written;
					if (total == _n) {
						flag = false;
						rc = _n;
					}
					else  {
						i += written;
						n -= written;
					}
				}
				break;
			}
			case LIBUSB_ERROR_TIMEOUT: {        // if the transfer timed out
				bp = 1;
				break;
			}
			case LIBUSB_ERROR_PIPE: {           // if the endpoint halted
				rc = -1;
				flag = false;
				break;
			}
			case LIBUSB_ERROR_OVERFLOW: {       // if the device offered more data, see Packets and overflows
				rc = -2;
				flag = false;
				break;
			}
			case LIBUSB_ERROR_NO_DEVICE: {      // if the device has been disconnected
				rc = -3;
				flag = false;
				break;
			}
			default: {                          // LIBUSB_ERROR code on other error
				rc = -4;
				flag = false;
				break;
			}
		}                 // switch()
	}                    // while(flag)

	return rc;
}                       // tx()


/**************************************************************************************************
	called from reader about 3 times per second
	simply puts stuff in the rxq
**************************************************************************************************/

int ANTDEV::rx(void) {
	int bytes_read, rep, status;
	bool flag;
	int i, rc = -1;
	unsigned char buf[64];
	unsigned short len;

	if (!handle) {
		return 0;
	}

	unsigned int timeout = 100;

	rep = 0x81;
	i = 0;
	flag = true;

	bp = 0;
	int reads = 0;
	int timeouts = 0;

	rx_calls++;


	while (flag) {
		reads++;
		#ifdef _DEBUG
		memset(buf, 0, sizeof(buf));
		#endif

		status = libusb_bulk_transfer(
			handle,                       // struct libusb_device_handle *dev_handle,
			rep,                          // unsigned char endpoint, 0x81
			buf,                          // unsigned char *data,
			(int)sizeof(buf),             // int length,
			&bytes_read,                  // int *transferred,
			timeout                       // unsigned int timeout
			);


#ifdef _DEBUG
		char *cptr;
		if (status == -1) {
			cptr = strerror(errno);       // Device or resource busy
			Q_UNUSED(cptr);
		}

#endif

		switch (status) {
			case 0: {
				if (bytes_read == 0) {
					rc = 0;
					flag = false;
					break;
				}

				int j;

				for (i = 0; i < bytes_read; i++) {
					j = (rxinptr + i) % RXBUFLEN;
					rxq[j] = buf[i];
				}

				rxinptr = (rxinptr + bytes_read) % RXBUFLEN;
				len = rxinptr - rxoutptr;

				// check for overflows here? (to do)

				len &= (RXBUFLEN - 1);
				bp = 0;

				if (bytes_read <= RXBUFLEN) {
					rc = bytes_read;
					flag = false;
				}
				else  {
					bp = 1;
				}

				break;
			}

			case LIBUSB_ERROR_TIMEOUT: {        // if the transfer timed out
				timeouts++;
				//if (timeouts >= ROUND(1000.0f/(float)timeout))  {			// allow only 1 second of timeouts before giving up
				if (timeouts > 0) {
					rc = LIBUSB_ERROR_TIMEOUT;
					flag = false;
				}
				break;
			}
			case LIBUSB_ERROR_PIPE: {           // if the endpoint halted -9
				//sprintf(str, "error2 writing TO ANT stick: %d, endpoint = %02x\n", status, wep);
				rc = LIBUSB_ERROR_PIPE;
				flag = false;
				break;
			}
			case LIBUSB_ERROR_OVERFLOW: {       // if the device offered more data, see Packets and overflows
				//sprintf(str, "error3 writing TO ANT stick: %d, endpoint = %02x\n", status, wep);
				rc = LIBUSB_ERROR_OVERFLOW;
				flag = false;
				break;
			}
			case LIBUSB_ERROR_NO_DEVICE: {      // if the device has been disconnected
				//sprintf(str, "error4 writing TO ANT stick: %d, endpoint = %02x\n", status, wep);
				rc = LIBUSB_ERROR_NO_DEVICE;
				flag = false;
				break;
			}

			case LIBUSB_ERROR_IO: {
				flag = false;
				rc = LIBUSB_ERROR_IO;
				break;
			}

			default: {                          // LIBUSB_ERROR code on other error
				//sprintf(str, "error5 writing TO ANT stick: %d, endpoint = %02x\n", status, wep);
				printf("default rx: status = %d\n", status);
				rc = -999;
				flag = false;
				break;
			}
		}                 // switch()
	}                    // while(flag)


	return rc;
}                       // rx()

/**************************************************************************************************

  #define OFFS_SYNC          0
  #define OFFS_LEN           1
  #define OFFS_MSG           2
  #define OFFS_DATA          3              // variable


			when it's a channel  event:

  #define OFFS_SYNC          0
  #define OFFS_LEN           1
  #define OFFS_MSG           2
  #define OFFS_CHAN          3
  #define OFFS_EVENT_ID      4
  #define OFFS_EVENT_CODE    5

			responses:

			sync	len     cmd    data       cs

			a4    01      6f     20		     ea					reset
			a4    03      40	   00 46 00   a1					network key

**************************************************************************************************/

void ANTDEV::process(void) {
	unsigned char msg;

	msg = rxMessage[OFFS_MSG];                               // OFFS_MSG = 2
	int len = rxMessage[1];
	len += 2;

#ifdef _DEBUG
	static int calls = 0;
	calls++;
	char msgstr[32];
	char eventstr[32];
	char startupstr[32];

	msgstr[0] = 0;
	eventstr[0] = 0;
	startupstr[0] = 0;

	process_count++;
	if (process_count == 2) {
		bp = 1;
	}

	if (msg_strings.contains(msg)) {
		strcpy(msgstr, msg_strings[msg].toUtf8().constData());
	}
	else  {
		strcpy(msgstr, "------------");
	}
	if (process_count == 2) {
		bp = 1;
	}
	if (calls == 3) {
		bp = 5;
	}
#endif            // _DEBUG

	switch (msg) {
		case 0xae:  {                       // serial error
			unsigned char reason;
			Q_UNUSED(reason);
			reason = rxMessage[3];								// 2 = the checksum of the ANT message was incorrect
			bp = 2;													// oops
			break;
		}

		case CHANNEL_EVENT: {								// 0x40
			unsigned char chan;

			chan = rxMessage[OFFS_CHAN];						// offs_chan = 3
			event = rxMessage[OFFS_EVENT_ID];            // offs_event_id = 4, pdf, pg 48, e id
			response = rxMessage[OFFS_EVENT_CODE];       // offs_event_code = 5, pdf, pg 48, e code, 0x28

			#ifdef _DEBUG
			if (event_strings.contains(event)) {
				strcpy(eventstr, event_strings[event].toUtf8().constData());
			}
			else  {
				strcpy(eventstr, "------------");
			}
			#endif


			switch (event) {
				case EVENT_RX_SEARCH_TIMEOUT:  {          // 0x01
					/*
						A receive channel has timed out on searching. The search is terminated, and the channel
						has been automatically closed.
						In order to restart the search the Open Channel message must be sent again.
					 */

					#ifdef _DEBUG
					bp = 1;
					if (response != 1 && response != 7) {
					}
					#endif
					channels[chan].open = false;
					break;
				}
				case ASSIGN_CHANNEL: {                                  // 0x42
					bp = 1;
					break;
				}
				case CHANNEL_PERIOD: {                                  // 0x43
					bp = 1;
					break;
				}
				case SEARCH_TIMEOUT:  {                                 // 0x44
					bp = 1;
					break;
				}
				case CHANNEL_FREQUENCY: {                               // 0x45
					msgdone = true;
					bp = 1;
					break;
				}
				case MESG_NETWORK_KEY_ID: {                                 // 0x46
					bp = 1;
					break;
				}
				case OPEN_CHANNEL: {                                    // 0x4b
					bp = 1;
					channels[chan].open = true;
					break;
				}
				case CHANNEL_ID: {                                      // 0x51
					bp = 1;
					break;
				}
				case CHANNEL_TX_POWER: {                                // 0x60
					bp = 1;
					break;
				}
				case LP_SEARCH_TIMEOUT:  {                              // 0x63
					bp = 1;
					break;
				}
				case ENABLE_EXT_MSGS:  {              // 0x66
						bp = 1;
					if (response == INVALID_MESSAGE) {
						extended = false;
					}
					else if (response != RESPONSE_NO_ERROR)  {
						bp = 2;
					}
					else  {
						extended = true;
					}
					break;
				}

				default:  {
					bp = 6;
					break;
				}
			}              // switch (_ev) {

			break;
		}                             // case CHANNEL_EVENT: {    // 0x40


		case MESG_STARTUP_MESG_ID: {    // 0X6F
			UCHAR ucReason = rxMessage[OFFS_DATA];

			#ifdef _DEBUG
			if (startup_strings.contains(ucReason)) {
				strcpy(startupstr, startup_strings[ucReason].toUtf8().constData());
			}
			else  {
				strcpy(startupstr, "------------");
			}
			Q_ASSERT(msgdone == false);
			#endif

			msgdone = true;
			break;
		}

		case CHANNEL_ID: {        // 0X51, set channel id
			bp = 1;
			break;
		}

		case CHANNEL_STATUS: {    // 0X52
			int chan = rxMessage[3];

			channels[chan].state = rxMessage[4] & 0x03;           // get bits 0 and 1 only

			bool AP1 = false;

			if (!AP1) {
				channels[chan].netnum = rxMessage[4] & 0x0c;                // get bits 2 and 3 only
				channels[chan].returned_type = rxMessage[4] & 0xf0;
			}

			msgdone = true;
			break;
		}


		case SET_NETWORK_KEY: {       // 0X46
			bp = 1;
			break;
		}


		case CAPABILITIES: {    // 0x54												// per channel
			char str[1024];
			unsigned char *buf = &rxMessage[3];

			ucStandardOptions = buf[2];               // 0x00
			ucAdvanced = buf[3];                      // 0xba
			ucAdvanced2 = buf[4];                     // 0x36
			// note: buf[5] is reserved (unused)

			strcpy(str, "   Standard Options:\n");

			if ( ucStandardOptions & CAPABILITIES_NO_RX_CHANNELS ) {
				strcat(str, "		CAPABILITIES_NO_RX_CHANNELS\n");
			}

			if ( ucStandardOptions & CAPABILITIES_NO_TX_CHANNELS ) {
				strcat(str, "		CAPABILITIES_NO_TX_CHANNELS\n");
			}

			if ( ucStandardOptions & CAPABILITIES_NO_RX_MESSAGES ) {
				strcat(str, "		CAPABILITIES_NO_RX_MESSAGES\n");
			}

			if ( ucStandardOptions & CAPABILITIES_NO_TX_MESSAGES ) {
				strcat(str, "		CAPABILITIES_NO_TX_MESSAGES\n");
			}

			if ( ucStandardOptions & CAPABILITIES_NO_ACKD_MESSAGES ) {
				strcat(str, "		CAPABILITIES_NO_ACKD_MESSAGES\n");
			}

			if ( ucStandardOptions & CAPABILITIES_NO_BURST_TRANSFER ) {
				strcat(str, "		CAPABILITIES_NO_BURST_TRANSFER\n");
			}

			////////////////////////////////////////////

			strcat(str, "   Advanced Options:\n");

			if ( ucAdvanced & CAPABILITIES_OVERUN_UNDERRUN ) {
				strcat(str, "		CAPABILITIES_OVERUN_UNDERRUN\n");
			}

			if ( ucAdvanced & CAPABILITIES_NETWORK_ENABLED ) {
				strcat(str, "		CAPABILITIES_NETWORK_ENABLED\n");								// this
			}

			if ( ucAdvanced & CAPABILITIES_AP1_VERSION_2 ) {
				strcat(str, "		CAPABILITIES_AP1_VERSION_2\n");
			}

			if ( ucAdvanced & CAPABILITIES_SERIAL_NUMBER_ENABLED ) {
				strcat(str, "		CAPABILITIES_SERIAL_NUMBER_ENABLED\n");						// this
			}

			if ( ucAdvanced & CAPABILITIES_PER_CHANNEL_TX_POWER_ENABLED ) {
				strcat(str, "		CAPABILITIES_PER_CHANNEL_TX_POWER_ENABLED\n");				// this
			}

			if ( ucAdvanced & CAPABILITIES_LOW_PRIORITY_SEARCH_ENABLED ) {
				strcat(str, "		CAPABILITIES_LOW_PRIORITY_SEARCH_ENABLED\n");				// this
			}

			if ( ucAdvanced & CAPABILITIES_SCRIPT_ENABLED ) {
				strcat(str, "		CAPABILITIES_SCRIPT_ENABLED\n");
			}

			if ( ucAdvanced & CAPABILITIES_SEARCH_LIST_ENABLED ) {
				strcat(str, "		CAPABILITIES_SEARCH_LIST_ENABLED\n");							// this
			}

			////////////////////////////////////////////

			strcat(str, "   Advanced 2 Options:\n");

			if ( ucAdvanced2 & CAPABILITIES_LED_ENABLED ) {
				strcat(str, "		CAPABILITIES_LED_ENABLED\n");
			}

			if ( ucAdvanced2 & CAPABILITIES_EXT_MESSAGE_ENABLED ) {
				strcat(str, "		CAPABILITIES_EXT_MESSAGE_ENABLED\n");							// this
			}

			if ( ucAdvanced2 & CAPABILITIES_SCAN_MODE_ENABLED ) {
				strcat(str, "		CAPABILITIES_SCAN_MODE_ENABLED\n");								// this
			}

			if ( ucAdvanced2 & CAPABILITIES_RESERVED ) {
				strcat(str, "		CAPABILITIES_RESERVED\n");
			}

			if ( ucAdvanced2 & CAPABILITIES_PROX_SEARCH_ENABLED ) {
				strcat(str, "		CAPABILITIES_PROX_SEARCH_ENABLED\n");							// this, proximity search
			}

			if ( ucAdvanced2 & CAPABILITIES_EXT_ASSIGN_ENABLED ) {
				strcat(str, "		CAPABILITIES_EXT_ASSIGN_ENABLED\n");							// this
			}

			if ( ucAdvanced2 & CAPABILITIES_FS_ANTFS_ENABLED) {
				strcat(str, "		CAPABILITIES_FREE_1\n");
			}

			if ( ucAdvanced2 & CAPABILITIES_FIT1_ENABLED ) {
				strcat(str, "		CAPABILITIES_FIT1_ENABLED\n");
			}


			int len = strlen(str);							// 385
			lock_logging();
			logg("len = %d\n%s", len, str);
			unlock_logging();

			msgdone = true;
			break;
		}                          //	case CAPABILITIES:

		case SERIAL_NUMBER: {  // 0x61
			sernum = (rxMessage[3] << 24) & 0xff000000;
			sernum |= (rxMessage[4] << 16) & 0x00ff0000;
			sernum |= (rxMessage[5] << 8) & 0x0000ff00;
			sernum |= (rxMessage[6] << 24) & 0x000000ff;

			memcpy(&sernum, &rxMessage[3], 4);                                   // reverses the order of the above code
			sprintf(sernum_string, "%04lx", sernum);
			msgdone = true;
			break;
		}

		case VERSION: {    // 0x3e
			int len = rxMessage[1];
			if (len > (int)sizeof(version) - 1) {
				//throw (fatalError(__FILE__, __LINE__, "version too long"));
				qFatal("version too long");
			}
			memcpy(version, &rxMessage[3], len);                        // "AJK1.04RAF"
			msgdone = true;
			break;
		}

		case BROADCAST_DATA: {
			if (initialized) {
				int k = rxMessage[OFFS_CHAN];       // k = channel number (0-7)

				switch (channels[k].devtype) {
					case 121: {
						ant_decode_speed_cadence();
						break;
					}
					case 120: {
						ant_decode_hr();
						break;
					}
				}
			}
			else  {
				bp = 1;
			}
			break;
		}

		case ACK_DATA: {
			bp = 1;
			break;
		}
		case BURST_DATA: {
			bp = 1;
			break;
		}

		default: {
			bp = 1;
			break;
		}
	}                          // switch(msg)





#ifdef _DEBUG
//	if (process_count == 2) {
//		bp = 1;
//	}

//	strcpy(leader, "p: ");

//	strcat(leader, msgstr);

//	if (eventstr[0]) {
//		strcat(leader, ", ");
//		strcat(leader, eventstr);
//	}

//	if (startupstr[0]) {
//		strcat(leader, ", ");
//		strcat(leader, startupstr);
//	}

//	strcat(leader, " ");

//	lock_dumping();
//	dump(rxMessage, len + 2, leader);
//	unlock_dumping();

#endif

	memset(rxMessage, 0, sizeof(rxMessage));

	return;
}                          // void process()

/**************************************************************************************************

**************************************************************************************************/

void ANTDEV::receiveByte(unsigned char byte) {

	switch (state) {
		case ST_WAIT_FOR_SYNC: {
			if (byte == SYNC_BYTE) {                                // 0xa4
				check_sum = SYNC_BYTE;
				rxMessage[0] = byte;
				state = ST_GET_LENGTH;
			}
			break;
		}

		case ST_GET_LENGTH: {
			if ((byte == 0) || (byte > MAX_LENGTH)) {               // MAX_LENGTH = 9
				state = ST_WAIT_FOR_SYNC;
			}
			else  {
				//rxMessage[OFFSET_LENGTH] = byte;
				rxMessage[1] = byte;
				check_sum ^= byte;
				length = byte;
				bytes = 0;
				state = ST_GET_MESSAGE_ID;
			}
			break;
		}

		case ST_GET_MESSAGE_ID: {
			//rxMessage[OFFSET_ID] = byte;
			rxMessage[2] = byte;
			check_sum ^= byte;
			state = ST_GET_DATA;
			break;
		}

		case ST_GET_DATA: {
			//rxMessage[OFFSET_DATA + bytes] = byte;
			rxMessage[3 + bytes] = byte;                                   // 0x6f 0x20 = "command reset" response
			check_sum ^= byte;
			if (++bytes == length) {
				state = ST_VALIDATE_PACKET;
			}
			break;
		}

		case ST_VALIDATE_PACKET: {
			if (byte == check_sum) {
				//rxMessage[OFFSET_DATA + bytes] = byte;
				inpackets++;
				rxMessage[3 + bytes] = byte;

				if (debug_level > 1) {
					//sprintf(leader, "rx: valid packet");

					lock_dumping();
					dump(rxMessage, bytes + 4, "rx: ", "     OK");
					unlock_dumping();

				}
				else  {
				}

				process();
			}
			else  {
				logg("rx: %-30s %02x %02x %02x ", "bad checksum:", rxMessage[0], rxMessage[1], rxMessage[2]);
			}

			state = ST_WAIT_FOR_SYNC;
			break;
		}
	}
	return;
}                             // receiveByte()

/********************************************************************************************************

********************************************************************************************************/

// xxx

bool ANTDEV::wfr(UCHAR _event, qint64 _ms) {

	qint64 curdiff = 0;
	qint64 nsecs = MSTONS * _ms;				// 3,300,000,000

#ifdef _DEBUG

	Q_ASSERT(event == 0);
	Q_ASSERT(response == 0xff);

	if(_event==CHANNEL_STATUS)  {
			bp = 1;
	}

	if (oktobreak)  {
		bp = 2;
	}

	qint64 startns=0;
	qint64 dns=0;

	bool have_string = false;
	bool good_response = false;

	switch (_event)  {
		case EVENT_RX_SEARCH_TIMEOUT:          // 0x01
		case ASSIGN_CHANNEL:               // 0x42
		case CHANNEL_PERIOD:               // 0x43
		case SEARCH_TIMEOUT:               // 0x44
		case CHANNEL_FREQUENCY:            // 0x45
		case MESG_NETWORK_KEY_ID:              // 0x46			294 ms
		case OPEN_CHANNEL:                 // 0x4b
		case CHANNEL_ID:                   // 0x51
		case CAPABILITIES:						// 0x54
		case CHANNEL_TX_POWER:             // 0x60
		case CHANNEL_STATUS:						// 0x52
		case LP_SEARCH_TIMEOUT:            // 0x63
		case ENABLE_EXT_MSGS:	           // 0x66
			have_string = true;
			break;
		default:											// 0x
			bp = 1;										// oops
			break;
	}
#endif

	startns = et.nsecsElapsed();

	while (1) {

		if (_event == event) {
			if(_event==CHANNEL_STATUS)  {
					bp = 1;
			}
			if (response == RESPONSE_NO_ERROR) {
				dns = et.nsecsElapsed() - startns;
				maxwfr = qMax(maxwfr, dns);
#ifdef _DEBUG
				double dt = (double)dns / 1000000.0;        // so I can check the timings and comment them in the following switch statement
				Q_UNUSED(dt);

				switch (_event) {
					case MESG_NETWORK_KEY_ID:           // 0x46			194 ms
					case ASSIGN_CHANNEL:						// 0x42			344 ms
					case CHANNEL_ID:							// 0x51			144 ms
					case ENABLE_EXT_MSGS:					// 0x66			144 ms
					case OPEN_CHANNEL:						// 0x4b			149 ms
					case LP_SEARCH_TIMEOUT:					// 0x63			150 ms
					case SEARCH_TIMEOUT:						// 0x44			150 ms
						break;

					case EVENT_RX_SEARCH_TIMEOUT:			// 0x01
						bp = 2;
						break;
					case CHANNEL_TX_POWER:					// 0x60
						bp = 2;
						break;
					case CHANNEL_FREQUENCY:					// 0x45
						bp = 2;
						break;
					case CHANNEL_PERIOD:						// 0x43
						bp = 2;
						break;

					default: {                          // 0x??
						bp = 5;									// oops
						break;
					}
				}                          // switch
#endif
				good_response = true;
			}                 // if (response == RESPONSE_NO_ERROR)
			else {
				// correct event, but response was not RESPONSE_NO_ERROR. Keep waiting????? or abort now?
				bp = 4;
				//break;			// ???
			}                 // if (response == RESPONSE_NO_ERROR)
		}

		if (good_response) {
			break;
		}


		curdiff = et.nsecsElapsed() - startns;

		if (curdiff >= nsecs)  {
			dns = et.nsecsElapsed() - startns;
			bp = 1;																	// oops
			break;                                                   // timed out
		}
		QThread::msleep(5);
	}                          // while(1)


	lock_logging();
	if (!good_response) {
		if (have_string) {
			logg("WFR, evnt = %s... TIMED OUT after %.2lf ms\n", event_strings[_event].toUtf8().constData(), NSTOMS*dns);

		}
		else  {
			logg("WFR, unknown evnt = %d... TIMED OUT after %.2lf ms\n", _event, NSTOMS*dns);
		}
	}
	else  {
		if (have_string) {
			logg("WFR %s %6.2lf OK\n", event_strings[_event].toUtf8().constData(), NSTOMS*dns);

		}
		else  {
			logg("WFR(%d?), OK, dt = %.2lf ms\n", _event, NSTOMS*dns);
		}
	}
	unlock_logging();

	response = 0xff;
	event = 0;

	return good_response;
}                 // wait_for_response()



/********************************************************************************************************
	waits up to _ms milliseconds for msgdone to become true
********************************************************************************************************/

//xxx

bool ANTDEV::wfm(UCHAR _msg, qint64 _ms) {
	Q_UNUSED(_msg);

	msgdone = false;


#ifdef _DEBUG
	if(_msg==ENABLE_EXT_MSGS)  {
			bp = 1;
	}

	if (_ms != 3300) {
		bp = 1;
	}

	if (key == 8311) {                       // garmin stick
		bp = 3;
	}
	else if (key == 8653)                  // suunto stick
	{
		bp = 3;
	}
	else  {
		bp = 4;
	}

	bool ok;

if (oktobreak)  {
	bp = 2;
}

	switch (_msg) {
		case CHANNEL_EVENT:             // 0x40			 64
		case CHANNEL_ID:                // 0x51
		case CHANNEL_STATUS:            // 0x52
		case SET_NETWORK_KEY:               // 0x46			 70
		case MESG_STARTUP_MESG_ID:          // 0x6f			111			364 ms
		case CAPABILITIES:              // 0x54
		case SERIAL_NUMBER:             // 0x61
		case VERSION:                   // 0x3e			 62
		case BROADCAST_DATA:            // 0x4e
		case ACK_DATA:                  // 0x4f
		case BURST_DATA: {              // 0x50			 80
			ok = true;
			break;
		}
		default: {                          // 0x
			ok = false;
			break;
		}
	}


#endif

	qint64 startms = QDateTime::currentMSecsSinceEpoch();
	qint64 nowms, dtms;
	bool timed_out = false;

	while (!msgdone) {
		nowms = QDateTime::currentMSecsSinceEpoch();
		dtms = nowms - startms;

		if (dtms >= _ms) {
			timed_out = true;
			break;
		}
		QThread::msleep(1);
	}

	lock_logging();

	if (timed_out) {
		if (ok) {
			logg("WFM: %s TIMED OUT!\n", msg_strings[_msg].toUtf8().constData() );
		}
		else  {
			logg("WFM %d TIMED OUT!\n", _msg);
		}
	}
	else  {
		if (ok) {
			logg("WFM: %s %d OK\n", msg_strings[_msg].toUtf8().constData(), dtms );
		}
		else  {
			logg("WFM: %d %d OK\n", _msg, dtms);
		}
	}

	unlock_logging();

	return msgdone;

}                 // wait_for_message_completion()

/**************************************************************************************

	this decoder based on


	entry:
		ucWheelCircumference set to calculate speed
		ant_packet contains the payload

	exit:
		cadence calculated
		speed (meters / hour) calculated
		wheel_rpm calculated
		(all floats)

**************************************************************************************/

int ANTDEV::ant_decode_speed_cadence(void) {

	USHORT usEventDiff = 0;
	USHORT usTimeDiff1024 = 0;
	unsigned char *buf = &rxMessage[4];

	//--------------------------------------
	// cadence:
	//--------------------------------------

	usCadTime1024 = buf[0];
	usCadTime1024 += buf[1] << 8;              // crankMeasurmentTime

	usCadEventCount = buf[2];
	usCadEventCount += buf[3] << 8;            // crankRevolutions

	//--------------------------------------
	// speed:
	//--------------------------------------

	usSpdTime1024 = buf[4];
	usSpdTime1024 += buf[5] << 8;              // wheelMeasurementTime

	usSpdEventCount = buf[6];
	usSpdEventCount += buf[7] << 8;            // wheelRevolutions


	if (eState == BSC_INIT) {
		usCadPreviousTime1024 = usCadTime1024;
		usCadPreviousEventCount = usCadEventCount;

		usSpdPreviousTime1024 = usSpdTime1024;
		usSpdPreviousEventCount = usSpdEventCount;

		eState = BSC_ACTIVE;
	}

	//-----------------------------------------------------
	// update cadence calculations on new cadence event
	// this is the large bump on the sensor body
	//-----------------------------------------------------

	if (usCadEventCount != usCadPreviousEventCount) {
		ucNoCadEventCount = 0;
		ant_coasting = false;

		// update cumulative event count

		if (usCadEventCount > usCadPreviousEventCount) {
			usEventDiff = usCadEventCount - usCadPreviousEventCount;
		}
		else  {
			usEventDiff = (USHORT)(0xFFFF - usCadPreviousEventCount + usCadEventCount + 1);
		}
		ulCadAcumEventCount += usEventDiff;

		// update cumulative time (1/1024s)

		if (usCadTime1024 > usCadPreviousTime1024) {
			usTimeDiff1024 = usCadTime1024 - usCadPreviousTime1024;
		}
		else  {
			usTimeDiff1024 = (USHORT)(0xFFFF - usCadPreviousTime1024 + usCadTime1024 + 1);
		}
		ulCadAcumTime1024 += usTimeDiff1024;

		// calculate cadence (rpm)

		if (usTimeDiff1024 > 0) {
			ant_cadence = (float)( ((ULONG)usEventDiff * 0xF000) / (ULONG)usTimeDiff1024 );     // 1 min = 0xF000 = 60 * 1024
		}
	}
	else  {
		ucNoCadEventCount++;

		if (ucNoCadEventCount >= MAX_NO_EVENTS) {
			ant_coasting = true;                         // coasting
			ant_cadence = 0.0f;
		}
	}


	//-----------------------------------------------------
	// Update speed calculations on new speed event
	// this is the head of the giraffe
	//-----------------------------------------------------

	if (usSpdEventCount != usSpdPreviousEventCount) {
		ucNoSpdEventCount = 0;
		ant_stopping = false;
		// Update cumulative event count
		if (usSpdEventCount > usSpdPreviousEventCount) {
			usEventDiff = usSpdEventCount - usSpdPreviousEventCount;
		}
		else  {
			usEventDiff = (USHORT)(0xFFFF - usSpdPreviousEventCount + usSpdEventCount + 1);
		}
		ulSpdAcumEventCount += usEventDiff;

		// Update cumulative time (1/1024s)

		if (usSpdTime1024 > usSpdPreviousTime1024) {
			usTimeDiff1024 = usSpdTime1024 - usSpdPreviousTime1024;
		}
		else  {
			usTimeDiff1024 = (USHORT)(0xFFFF - usSpdPreviousTime1024 + usSpdTime1024 + 1);
		}

		ulSpdAcumTime1024 += usTimeDiff1024;


		ant_wheel_rpm = ((float)usEventDiff / (float)usTimeDiff1024) * 60.0f * 1024.0f;

		if (ant_circumference_cm) {
#ifdef _DEBUG
			//float diameter = (float) (circumference_cm / PI);
#endif
			// Calculate speed (meters/h)
			ant_speed = (float)(ant_circumference_cm * 0x9000 * (ULONG)usEventDiff) / (ULONG)usTimeDiff1024;      // 1024 * 36 = 0x9000
		}

		// Calculate distance (cm)

		ulDistance = (ULONG)ant_circumference_cm * ulSpdAcumEventCount;
	}
	else  {
		ucNoSpdEventCount++;
		if (ucNoSpdEventCount >= MAX_NO_EVENTS) {
			ant_stopping = true;
			ant_wheel_rpm = 0.0f;
			ant_speed = 0.0f;
		}
	}

	// Update previous values

	usCadPreviousTime1024 = usCadTime1024;
	usCadPreviousEventCount = usCadEventCount;

	usSpdPreviousTime1024 = usSpdTime1024;
	usSpdPreviousEventCount = usSpdEventCount;

	return 0;
}              // decode_speed_cadence()

/**************************************************************************************

**************************************************************************************/

int ANTDEV::ant_decode_hr(void) {
	UCHAR ucPageNum = 0;
	UCHAR ucEventDiff = 0;
	USHORT usTimeDiff1024 = 0;

	unsigned char *buf = &rxMessage[4];

#ifdef _DEBUG
	hrcalls++;
#endif


	// monitor page toggle bit

	if (ucStatePage != HRM_EXT_PAGE) {
		if (ucStatePage == HRM_INIT_PAGE) {
			ucStatePage = (buf[0] & HRM_TOGGLE_MASK) >> 7;
			// initialize previous values to correctly get the cumulative values
			ucPreviousEventCount = buf[6];
			usPreviousTime1024 = buf[4];
			usPreviousTime1024 += buf[5] << 8;
		}
		else if (ucStatePage != ((buf[0] & HRM_TOGGLE_MASK) >> 7))
		{
			// first page toggle was seen, enable advanced data
			ucStatePage = HRM_EXT_PAGE;
		}
	}

	// remove page toggle bit

	ucPageNum = buf[0] & ~HRM_TOGGLE_MASK;       // page 0 and 4 are the main data pages

	// Handle basic data

	ucEventCount = buf[6];
	usTime1024 = buf[4];
	usTime1024 += buf[5] << 8;
	//if (hrcalls>15)  {
	//if (buf[6] != 0xcc && buf[7] != 0xcc)  {				// wait for valid buf
#ifdef _DEBUG
	//if (have_ant_packet)  {
	ant_hr = buf[7];
	//}
#else
	ant_hr = buf[7];
#endif


	// handle background data, if supported

	if (ucStatePage == HRM_EXT_PAGE) {
		switch (ucPageNum) {
			case HRM_PAGE1: {
				ulElapsedTime2 = buf[1];
				ulElapsedTime2 += buf[2] << 8;
				ulElapsedTime2 += buf[3] << 16;
				break;
			}
			case HRM_PAGE2: {
				ucMfgID = buf[1];
				usSerialNum = buf[2];
				usSerialNum += buf[3] << 8;      // serial number = 3?
				break;
			}
			case HRM_PAGE3: {
				ucHwVersion = buf[1];         // 4
				ucSwVersion = buf[2];         // 4
				ucModelNum = buf[3];          // 5
				break;
			}
			case HRM_PAGE4: {
				usPreviousTime1024 = buf[2];
				usPreviousTime1024 += buf[3] << 8;
				break;
			}
			default: {
#ifdef _DEBUG
				bp = 0;
#endif
				break;
			}
		}
	}


	// only need to do calculations if dealing with a new event

	if (ucEventCount != ucPreviousEventCount) {
		ucNoEventCount = 0;

		// update cumulative event count

		if (ucEventCount > ucPreviousEventCount) {
			ucEventDiff = ucEventCount - ucPreviousEventCount;
		}
		else  {
			ucEventDiff = (UCHAR)0xFF - ucPreviousEventCount + ucEventCount + 1;
		}

		ulAcumEventCount += ucEventDiff;

		// update cumulative time

		if (usTime1024 > usPreviousTime1024) {
			usTimeDiff1024 = usTime1024 - usPreviousTime1024;
		}
		else  {
			usTimeDiff1024 = (USHORT)(0xFFFF - usPreviousTime1024 + usTime1024 + 1);
		}

		ulAcumTime1024 += usTimeDiff1024;


		// calculate R-R Interval

		if (ucEventDiff == 1) {
			usR_RInterval1024 = usTimeDiff1024;
		}

		// calculate heart rate (from timing data), in ant_bpm

		if (usTimeDiff1024 > 0) {
			ant_calculated_hr = (UCHAR)( ((USHORT)ucEventDiff * 0xF000) / usTimeDiff1024 );     // 1 min = 0xF000 = 60 * 1024
		}
	}
	else  {
		ucNoEventCount++;
		if (ucNoEventCount >= MAX_NO_EVENTS) {
			ant_hr = ant_calculated_hr = HRM_INVALID_BPM;   // No new valid HR data has been received
		}
	}

	if (ant_calculated_hr != HRM_INVALID_BPM) {
		int diff = abs(ant_calculated_hr - ant_hr);
		if (diff > 5) {
			// maybe average ant_hr with the calculated hr? What to do?
			// observed calculated_hr's after things were up and running:
			// 26, 27, 28
			// so you'd need a median filter if you use that.
			bp = 7;
		}
	}

	// update previous time and event count

	if (ucPageNum != HRM_PAGE4) {
		usPreviousTime1024 = usTime1024;  // only if not previously obtained from HRM message
	}

	ucPreviousEventCount = ucEventCount;

	return 0;
}                 // int decode_hr()




/********************************************************************************************************

********************************************************************************************************/

int ANTDEV::stop(void) {


	somethread->exit();
	txtimer->deleteLater();
	rxtimer->deleteLater();

	QThread::msleep(500);			// wait for communication to the ANT sticks to stop (just in case)

	if (handle) {
		libusb_close(handle);
		handle = NULL;
	}

	return 0;
}                                // stop()

/********************************************************************************************************

********************************************************************************************************/

int ANTDEV::set_devtype(int _chan_num, int _devtype) {
	int rc;

	if (_chan_num < 0 || _chan_num > 7) {
		return 2;
	}

	channels[_chan_num].devtype = _devtype;

	switch (channels[_chan_num].devtype) {
		case 121: {                   // speed/cadence
			rc = 0;
			channels[_chan_num].freq = 57;
			channels[_chan_num].period = 8086;
			channels[_chan_num].number = _chan_num;
			strcpy(channels[_chan_num].typestr, "Speed Cadence");
			break;
		}

		case 120: {                   // heartrate
			rc = 0;
			channels[_chan_num].freq = 57;
			channels[_chan_num].period = 8070;
			channels[_chan_num].number = _chan_num;
			strcpy(channels[_chan_num].typestr, "Heart Rate");
			break;
		}

		default: {
			rc = 1;
			break;
		}
	}

	return rc;
}                             // set_devtype()


/********************************************************************************************************

********************************************************************************************************/

int ANTDEV::set_period(int _chan_num, unsigned short _period) {

	if (_chan_num < 0 || _chan_num > 7) {
		return 2;
	}

	channels[_chan_num].period = _period;

	return 0;
}                                   // set_period()


/******************************************************************************

******************************************************************************/

void ANTDEV::test(void) {

	return;
}


/********************************************************************************************************

********************************************************************************************************/

int ANTDEV::set_device(libusb_device *_device) {
	int status;
	int rc = 0;
	char str[256];

	device = _device;

	status = libusb_get_device_descriptor(device, &desc);       // desc.idVendor, desc.idProduct
	if (status != 0) {
		rc = status;
		goto finis;
	}

	status = libusb_open(device, &handle);    // Open a device and obtain a device handle

	switch (status) {
		case 0: {                  // on success
			break;
		}
		case LIBUSB_ERROR_NO_MEM:           // -11	on memory allocation failure
		case LIBUSB_ERROR_ACCESS:           // -3		if the user has insufficient permissions
		case LIBUSB_ERROR_NO_DEVICE: {      // -4		if the device has been disconnected
			rc = status;
			goto finis;
		}
		default:
			rc = status;
			goto finis;
	}

	pid = desc.idProduct;
	vid = desc.idVendor;
	nconfigs = desc.bNumConfigurations;

	status = libusb_get_string_descriptor_ascii(handle, desc.iManufacturer, (unsigned char*)str, sizeof(str) - 1);
	Q_ASSERT(status >= 0);

	strncpy(mfgr, str, sizeof(mfgr) - 1);

	status = libusb_get_string_descriptor_ascii(handle, desc.iProduct, (unsigned char*)str, sizeof(str) - 1);
	strncpy(prod, str, sizeof(prod) - 1);

	status = libusb_get_string_descriptor_ascii(handle, desc.iSerialNumber, (unsigned char*)sn, sizeof(sn));
	strncpy(serial_number, str, sizeof(serial_number) - 1);


finis:
	return rc;
}                             // set_device()

/********************************************************************************************************

********************************************************************************************************/

int ANTDEV::start(void) {
	int status;


	response = 0xff;

	bool b;

	if (somethread == NULL) {

		somethread = new QThread(this);
		if (txtimer == NULL) {
			txtimer = new QTimer(0);
			txtimer->setInterval(333);
			txtimer->moveToThread(somethread);
			b = (bool)connect(txtimer, SIGNAL(timeout()), this, SLOT(writer(void)), Qt::DirectConnection);
			Q_ASSERT(b);
			b = (bool)QObject::connect(somethread, SIGNAL(started()), txtimer, SLOT(start()));
			Q_ASSERT(b);
		}

		if (rxtimer == NULL) {
			rxtimer = new QTimer(0);
			rxtimer->setInterval(350);
			rxtimer->moveToThread(somethread);
			b = (bool)connect(rxtimer, SIGNAL(timeout()), this, SLOT(reader(void)), Qt::DirectConnection);
			Q_ASSERT(b);
			b = (bool)QObject::connect(somethread, SIGNAL(started()), rxtimer, SLOT(start()));
			Q_ASSERT(b);
		}
		somethread->start();
	}

	status = send(reset_command, 5);
	if (status) {
		strcpy(error_string, "ANT reset failed 1");
		return 1;
	}
	QThread::msleep(100);

	if (!wfm(MESG_STARTUP_MESG_ID, MESSAGE_TIMEOUT)) {             // waits up to 3.3 seconds for msgdone to become true
		strcpy(error_string, "ANT reset failed 2");
		return 1;
	}

	QThread::msleep(750);               // specs say wait 500ms after reset before sending any more host commands


	status = send(set_network_key_command, 13);
	QThread::msleep(100);
	if (status) {
		strcpy(error_string, "SetNetworkKey failed 1");
		return 1;
	}
	if (!wfr(MESG_NETWORK_KEY_ID, RESPONSE_TIMEOUT)) {
		strcpy(error_string, "SetNetworkKey failed 2");
		return 1;
	}


	return 0;

}                          // start(void)  {			starts the device only

/**************************************************************************************************

**************************************************************************************************/

void ANTDEV::writer(void) {
	unsigned char wep;                        // read endpoint
	unsigned short len;
	int status;

	//tmr->update();

	// use mutex here
	if (err != 0) {
		//emit()
		err = 0;
	}

	bp = 0;
	wep = 0x01;                            // read from address 1
	Q_UNUSED(wep);

	if (txinptr != txoutptr) {
		len = txinptr - txoutptr;
		len &= (TXBUFLEN - 1);
		status = tx(&txq[txoutptr], len, 500L);
		if (status != len) {
			bp = 2;
		}
		txoutptr = (txoutptr + len) % TXBUFLEN;
	}
	return;
}                                               // writer()

/**************************************************************************************************
	Thread function: Thread ID
	loads stuff into rxq and advances the rxinptr
**************************************************************************************************/

void ANTDEV::reader(void) {
	int status;

	// use mutex here
	if (err != 0) {
		//emit()

		err = 0;
	}

//	tmr->update();
//qDebug() << "reader";

	status = rx();
	switch (status) {
		case 0: {
			bp = 1;
			break;
		}

		case LIBUSB_ERROR_TIMEOUT: {                             // timeout
			bp = 2;
			break;
		}

		case LIBUSB_ERROR_PIPE: {              // if the endpoint halted -9
			bp = 2;
			break;
		}

		case LIBUSB_ERROR_OVERFLOW: {          // if the device offered more data, see Packets and overflows, -8
			bp = 2;
			break;
		}

		case LIBUSB_ERROR_NO_DEVICE: {         // if the device has been disconnected, -4
			bp = 2;
			break;
		}

		case LIBUSB_ERROR_IO: {                // Device or resource busy
			bp = 2;
			break;
		}

		default:  {
			// normally returns the number of bytes received
			if (status < 0) {
				lock_logging();
				logg("ANTDEV::reader() status = %d\n", status);
				unlock_logging();
			}
			// new data in queue
			//process();

			int i, j, len;

			i = rxinptr - rxoutptr;
			len = i & (RXBUFLEN - 1);

			#ifdef _DEBUG
			if (status != len) {
				bp = 2;
			}
			#endif
			bp = 1;

			for (i = 0; i < len; i++) {
				j = (rxoutptr + i) % RXBUFLEN;
				receiveByte(rxq[j]);
			}
			rxoutptr = (rxoutptr + len) % RXBUFLEN;

			bp = 99;
			break;
		}
	}

	return;
}                                               // reader()


/********************************************************************************************************
	see pdf file, page 7
	Figure 5-2. Configuring Background Scanning Channel

  #define OFFS_SYNC          0
  #define OFFS_LEN           1
  #define OFFS_MSG           2
  #define OFFS_CHAN          3
  #define OFFS_EVENT_ID      4
  #define OFFS_EVENT_CODE    5

https://e2e.ti.com/support/wireless_connectivity/bluetooth_cc256x/f/660/t/117732
I'm trying to open an ANT+ background scanning channel using the method that has worked for me with the nRF24AP2:

AssignChannel(0, 0x40, 1, 1);
SetChannelId(0, 0, 0, 0) ;

SetChannelPeriod(0, 6554);
SetChannelRFFreq(0, 0x39);
RxExtMesgsEnable(1);
SetProximitySearch(0, 6);

SetLowPriorityChannelSearchTimeout(0, 0xFF);
SetChannelSearchTimeout(0, 72);
OpenChannel(0);

********************************************************************************************************/

int ANTDEV::start_listening() {
	int status;

	Q_UNUSED(status);

	unsigned char chan = 0;
	unsigned char type;
	net = 0;

	//---------------------------------------------------------------------

	QThread::msleep(100);
	get_caps_command[3] = chan;								// 0xa4, 0x02, 0x4d, 0x00, 0x54, 0xbf
	checksum(get_caps_command, sizeof(get_caps_command));
	status = send(get_caps_command, sizeof(get_caps_command));
	QThread::msleep(100);
	if (status) {
		strcpy(error_string, "getcaps failed 1");
		return 1;
	}

	if (!wfm(CAPABILITIES, MESSAGE_TIMEOUT)) {             // waits up to 3.3 seconds for msgdone to become true
		strcpy(error_string, "getcaps failed 2");
		return 1;
	}


	//---------------------------------------------------------------------

	QThread::msleep(100);
	//                                                                                chan  type  net   ext
	//unsigned char ANTDEV::assign_channel_command[8] =           { 0xa4, 0x04, 0x42, 0x00, 0x10, 0x00, 0x01,                               0xf3 };
	chan = 0;
	type = 0x40;											// 0x00 = receive channel, 0x40 = receive only channel
	net = 0;
	assign_channel_command[3] = chan;
	assign_channel_command[4] = type;
	assign_channel_command[5] = net;
	assign_channel_command[6] = 0x01;
	checksum(assign_channel_command, sizeof(assign_channel_command));
	status = send(assign_channel_command, sizeof(assign_channel_command));        // 0x42
	QThread::msleep(100);
	if (status) {
		strcpy(error_string, "assign channel failed 1");
		return 1;
	}
	if (!wfr(ASSIGN_CHANNEL, RESPONSE_TIMEOUT)) {         // MESSAGE_TIMEOUT
		strcpy(error_string, "assign channel failed 2");
		return 1;
	}


	//---------------------------------------------------------------------

	QThread::msleep(100);
	// 								chan   devnum  devnum   devtype   ttype
	// 0xa4, 0x05, 0x51, 0x00, 0x00,  0x00,   0x00,    0x00,     0xf0

	set_channel_id_command[3] = chan;						   // channel
	set_channel_id_command[4] = 0;                        // devicd number
	set_channel_id_command[5] = 0;                        // device number
	set_channel_id_command[6] = 0;                        // devtype
	set_channel_id_command[7] = 0;                        // transmission type
	checksum(set_channel_id_command, sizeof(set_channel_id_command));
	status = send(set_channel_id_command, sizeof(set_channel_id_command));
	QThread::msleep(100);
	if (status) {
		strcpy(error_string, "set channel ID failed 1");
		return 1;
	}
	if (!wfr(CHANNEL_ID, RESPONSE_TIMEOUT)) {
		strcpy(error_string, "set channel ID failed 2");
		return 1;
	}

	//---------------------------------------------------------------------

//	QThread::msleep(100);

//	//	0xa4, 0x03, 0x43, 0x00, 0x00, 0x00, 0x00
//	unsigned short hz = 4;
//	unsigned short period = qRound((float)32768/hz);
//	channel_period[3] = chan;									// channel
//	channel_period[4] = period&0x00ff;						// period, little endian
//	channel_period[5] = (period>>8)&0x00ff;				// period, little endian
//	checksum(channel_period, sizeof(channel_period));
//	status = send(channel_period, sizeof(channel_period));
//	QThread::msleep(100);
//	if (status) {
//		strcpy(error_string, "channel period failed 1");
//		return 1;
//	}
//	if (!wait_for_channel_event_response(CHANNEL_ID, RESPONSE_TIMEOUT)) {
//		strcpy(error_string, "channel period failed 2");
//		return 1;
//	}

	//---------------------------------------------------------------------

	QThread::msleep(100);

	status = send(set_extended_messages_command, sizeof(set_extended_messages_command));
	QThread::msleep(100);
	if (status) {
		strcpy(error_string, "setting extended messages failed 1");
		return 1;
	}

	if (!wfr(ENABLE_EXT_MSGS, RESPONSE_TIMEOUT)) {
		strcpy(error_string, "setting extended messages failed 2");
		return 1;
	}


	//---------------------------------------------------------------------

	QThread::msleep(100);

	memset(rxMessage, 0, sizeof(rxMessage));

	lp_search_timeout_command[3] = chan;
	lp_search_timeout_command[4] = qRound(2*2.5);            // timeout of 5 seconds
	checksum(lp_search_timeout_command, sizeof(lp_search_timeout_command));
	status = send(lp_search_timeout_command, sizeof(lp_search_timeout_command));
	QThread::msleep(100);
	if (status) {
		strcpy(error_string, "setting LP search timout 1");
		return 1;
	}
	if (!wfr(LP_SEARCH_TIMEOUT, RESPONSE_TIMEOUT)) {                     // 0x63, took 499 ms!!!
		strcpy(error_string, "setting LP search timout 2");
		return 1;
	}


	//---------------------------------------------------------------------

	QThread::msleep(100);

	search_timeout_command[3] = chan;
	search_timeout_command[4] = qRound(12*2.5);            // timeout = 30 seconds
	checksum(search_timeout_command, sizeof(search_timeout_command));
	status = send(search_timeout_command, sizeof(search_timeout_command));
	QThread::msleep(100);
	if (status) {
		strcpy(error_string, "setting search timout 1");
		return 1;
	}
	if (!wfr(SEARCH_TIMEOUT, RESPONSE_TIMEOUT)) {                     // 0x44
		strcpy(error_string, "setting search timout 2");
		return 1;
	}

	//---------------------------------------------------------------------
	// 0xa4, 0x02, 0x45, 0x00, 0x00, 0x00

	QThread::msleep(100);
	set_channel_freq[3] = chan;						   // channel
	set_channel_freq[4] = 57;                        // frequency
	checksum(set_channel_freq, sizeof(set_channel_freq));
	status = send(set_channel_freq, sizeof(set_channel_freq));
	QThread::msleep(100);
	if (status) {
		strcpy(error_string, "set channel frequency failed 1");
		return 1;
	}
	if (!wfr(CHANNEL_FREQUENCY, RESPONSE_TIMEOUT)) {
		strcpy(error_string, "set channel frequency failed 2");
		return 1;
	}

	//---------------------------------------------------------------------

	QThread::msleep(100);
	// 0xa4, 0x02, 0x4d, 0x00, 0x52, 0x00

	get_channel_status[3] = chan;
	checksum(get_channel_status, sizeof(get_channel_status));
	status = send(get_channel_status, sizeof(get_channel_status));
	checksum(get_channel_status, sizeof(get_channel_status));
	QThread::msleep(100);
	if (status) {
		strcpy(error_string, "get channel status failed 1");
		return 1;
	}
//	if (!wfr(CHANNEL_STATUS, RESPONSE_TIMEOUT)) {
//		strcpy(error_string, "get channel status failed 2");
//		return 1;
//	}
	if (!wfm(CHANNEL_STATUS, MESSAGE_TIMEOUT)) {             // waits up to 3.3 seconds for msgdone to become true
		strcpy(error_string, "get channel status failed 2");
		return 1;
	}

	//---------------------------------------------------------------------

	QThread::msleep(100);

	open_channel_command[3] = chan;
	checksum(open_channel_command, sizeof(open_channel_command));
	status = send(open_channel_command, sizeof(open_channel_command));
	QThread::msleep(100);
	if (status) {
		strcpy(error_string, "open channel failed 1");
		return 1;
	}
	if (!wfr(OPEN_CHANNEL, RESPONSE_TIMEOUT)) {
		strcpy(error_string, "open channel failed 2");
		return 1;
	}


	return 0;
}                                // start_listening()


/********************************************************************************************************

********************************************************************************************************/

void ANTDEV::logg(const char *format, ...) {

#ifndef _DEBUG
	return;
#endif

	if (logstream == NULL) {
		return;
	}

	if (format == NULL) {
		return;
	}

	va_list ap;                                        // Argument pointer
	QString s;

	va_start(ap, format);
	vsprintf(logstr, format, ap);
	va_end(ap);

	qint64 now = QDateTime::currentMSecsSinceEpoch() - start_time;
	//unsigned long * _tid = (unsigned long *)QThread::currentThreadId();

	#ifdef _DEBUG
	if (qdbg) {
		//qDebug() << rstrip(QString((char*)(logstr)));
		//s.remove(QRegExp("\\s+$"));
		//s = rstrip(QString::asprintf("%5lld %s, tid = %p", now, logstr, _tid));
		s = rstrip(QString::asprintf("%5lld %s", now, logstr));
		qDebug("%s", qPrintable(s));
	}
	else  {
		//printf("%5lld, %s, tid = %p", now, logstr, _tid);
		printf("%5lld, %s", now, logstr);
	}
	#endif

	//fprintf(logstream, "%5lld %s, tid = %p", now, logstr, _tid);
	fprintf(logstream, "%5lld %s", now, logstr);

	return;
}                                      // logg

/********************************************************************************************************

********************************************************************************************************/

void ANTDEV::dump(const unsigned char *_buf, int _len, const char *_leader, const char *_trailer) {
	if (!logstream) {
		return;
	}

	QString s;
	int i;

#ifdef _DEBUG
	if (_trailer)  {
		bp = 1;
	}
#endif

	qint64 now = QDateTime::currentMSecsSinceEpoch() - start_time;


	if (_leader) {
		if (_leader[0]=='\n')  {
			s = QString::asprintf("\n%5lld %-10s", now, &_leader[1]);
		}
		else  {
			s = QString::asprintf("%5lld %-10s", now, _leader);
		}
	}
	else  {
		s = QString::asprintf("%5lld: ", now);
	}

	for (i = 0; i < _len - 1; i++) {
		s += QString::asprintf("%02x ", _buf[i] & 0xff);
	}


	s += QString::asprintf("%02x", _buf[i] & 0xff);

	if (_trailer) {
		s += QString::asprintf("%s", _trailer);
	}
	else  {
		s += "\n";
	}

	qDebug("%s", qPrintable(s));

//	if (logstream)  {
//		fprintf(logstream, "%s", qPrintable(s));
//		fflush(logstream);
//	}



	return;
}                          // dump()

/*******************************************************************************************************

*******************************************************************************************************/

//int ANTDEV::send(QByteArray a)  {
int ANTDEV::send(const unsigned char *a, int len) {
	int i, j;
	int rc = 0;

	outpackets++;



#ifdef _DEBUG

	unsigned char msg;

	msg = a[2];

	bool have_string;

	switch (msg) {
		case REQ_MESSAGE:  {                      // 0x4d
			int len = a[1];
			int req = a[4];

			if (len != 2) {
				rc = 1;
			}

			switch (req) {
				case CAPABILITIES: {                           // 0x54
					bp = 1;
					break;
				}
				case SERIAL_NUMBER: {                          // 0x61
					bp = 2;
					break;
				}
				case VERSION: {                                // 0x3d
					bp = 3;
					break;
				}
				case CHANNEL_STATUS: {                         // 0x52
					bp = 4;
					break;
				}
				case CHANNEL_ID: {                             // 0x51
					bp = 5;
					break;
				}
				default: {
					bp = 2;
					break;
				}
			}
		}                          // REQ_MSG
		case ASSIGN_CHANNEL:   // 0x42
		case SET_NETWORK_KEY:      // 0x46
		case SYSTEM_RESET:     // 0x4a
		case CHANNEL_ID: {     // 0x51
			have_string = true;
			break;
		}
		case OPEN_CHANNEL: {               // 0x4b
			have_string = true;
			break;
		}
		case LP_SEARCH_TIMEOUT: {          // 0x63
			have_string = true;
			bp = 1;
			break;
		}
		case ENABLE_EXT_MSGS: {            // 0x66
			have_string = true;
			break;
		}

		case SEARCH_TIMEOUT: {             // 0x44
			have_string = true;
			break;
		}
		case CHANNEL_FREQUENCY:				// 0x45
			have_string = true;
			break;

		default: {
			have_string = false;
			break;
		}
	}                             // switch(_msg)
#endif

	//memcpy(&m.data[m.length], padding, 2);       // tlm

	//n = m.length + 2;
	//n = a.size();

	//buf = (char*)m.data;

	bp = 0;

	if (debug_level > 1) {
		fprintf(logstream, "\n");
		if (qdbg) {
			//qDebug() << "---";
		}
		else  {
			printf("\n");
		}

		sprintf(leader, "\ntx: ");

		if (have_string) {
			sprintf(trailer, "     %s", msg_strings[msg].toUtf8().constData());
		}
		else  {
			sprintf(trailer, "     unknown _msg: %02x", msg );
		}


		lock_dumping();
		dump(a, len, leader, trailer);
		unlock_dumping();
		lock_logging();
		//logg("%s\n", msg_strings[msg].toUtf8().constData());
		unlock_logging();
	}

	for (i = 0; i < len; i++) {
		j = (txinptr + i) % TXBUFLEN;
		txq[j] = a[i];
	}
	txinptr = (txinptr + i) % TXBUFLEN;

	return rc;
}                             // send()

/*******************************************************************************************************

*******************************************************************************************************/

void ANTDEV::checksum(unsigned char *_buf, int _len) {
	int i;
	unsigned char cs = 0;

	for (i = 0; i < _len - 1; i++) {
		cs ^= _buf[i];
	}
	//cs ^= 0xff;
	_buf[i] = cs;

	return;
}

/*******************************************************************************************************
	QElapsedTimer et;
	bool b;

	qint64 nanoseconds;
	b = logmutex.tryLock(5);								// wait up to 5 ms for a lock
	if (b==false)  {
		bp = 1;
	}
	nanoseconds = et.nsecsElapsed();						// max was 5100 nanoseconds in my testing

  #ifdef _DEBUG
	maxlogwait = qMax(maxlogwait, nanoseconds);
  #endif

	logmutex.unlock();


*******************************************************************************************************/

void ANTDEV::lock_logging(void) {

#if 1
	bool b;
	qint64 start;
	qint64 nanoseconds;

	start = et.nsecsElapsed();
	b = logmutex.tryLock(5);                        // wait up to 5 ms for a lock
	if (b == false) {
		bp = 1;
	}
	nanoseconds = et.nsecsElapsed() - start;
	#ifdef _DEBUG
	maxlogwait = qMax(maxlogwait, nanoseconds);
	#endif
#else
	while (logging) {
	}
	logging = true;
#endif
	return;
}

/*******************************************************************************************************

*******************************************************************************************************/

void ANTDEV::unlock_logging(void) {
#if 1
	logmutex.unlock();
#else
	logging = false;
#endif

	return;
}

/*******************************************************************************************************

*******************************************************************************************************/

void ANTDEV::lock_dumping(void) {
#if 1
	bool b;
	qint64 start;
	qint64 nanoseconds;
	start = et.nsecsElapsed();

	b = dumpmutex.tryLock(5);                       // wait up to 5 ms for a lock
	if (b == false) {
		bp = 1;
	}
	nanoseconds = et.nsecsElapsed() - start;
	#ifdef _DEBUG
	maxdumpwait = qMax(maxdumpwait, nanoseconds);
	#endif
#else
	while (dumping) {
	}
	dumping = true;
#endif
	return;
}

/*******************************************************************************************************

*******************************************************************************************************/

void ANTDEV::unlock_dumping(void) {
#if 1
	dumpmutex.unlock();
#else
	dumping = false;
#endif
	return;
}
