
#ifndef _SENSOR_H_
#define _SENSOR_H_

#include <QtCore>

/****************************************************************************

****************************************************************************/

class SENSOR  {
	friend class ANT;
	friend class ANTDEV;

	public:
			SENSOR(void);
			~SENSOR();
			int sn = -1;							// copy of the key for easier iteration
			int channel = -1;

	private:
		unsigned char type = 0x00;
		unsigned char transtype = 0x00;
		qint64 lastcommtime=-1;
};

#endif


