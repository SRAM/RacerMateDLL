#ifndef _ANT_H
#define _ANT_H

#include <QObject>
#include <QFile>

//#define DOTIMER

#ifdef DOTIMER
#include <QTimer>
#endif

#include <QVector>



#include "sl_global.h"

#include <tmr.h>
//#include <sdirs.h>

#include "antdev.h"

#ifdef DOWORKER
	#include "antworker.h"
#endif


#include "cad.h"
#include "sc.h"
#include "hr.h"


// 1 = qml
// 2 = qt console
// 3 = windows dll

namespace RACERMATE {

/********************************************************************************************

********************************************************************************************/

//class SHAREDLIBSHARED_EXPORT ANT : public QObject  {
class Q_DECL_EXPORT ANT : public QObject  {
//class ANT : public QObject  {
	Q_OBJECT

#ifdef DOWORKER
	friend class antWorker;
#endif


	public:

#define ANT_INVALID_SENSOR -1;
#define HR_DEV_TYPE	120						// heart rate
#define SC_DEV_TYPE	121						// speed cadence
#define C_DEV_TYPE	122						// cadence

#define ANT_HR 0
#define ANT_C 1
#define ANT_SC 2

#ifdef DOWORKER
		int stop(void);
#endif
	//int associate(38760, "UDP-5555")
	int assign_sensor(int _sn, int _type);
	int unassign_sensor(int _sn);
	const char* get_sticks(void);

	private:
		//QString sticks;
		char sticks[512];									// ascii list of sticks
		Qt::HANDLE tid=0;
		int nsticks = 0;
		QMutex devices_mutex;
		QMutex sensors_mutex;
		bool scanning_for_devices = false;

		//int ticks = 0;
#ifdef DOWORKER
		//QThread* thread = NULL;
		static ANT* m_instance;
		QCoreApplication* m_application = NULL;
		antWorker* worker = NULL;
		QThread* workerThread = NULL;
#else
#ifdef DOTIMER
		int ticks = 0;
#endif
#endif

		#define ANT_STANDARD_DATA_PAYLOAD_SIZE		((UCHAR)8)

		#define SCPERIOD  8086							// must be 8086 or you get a lot of timeouts, although it tries to work
		#define SCDEVTYPE 121							// has to be 121
		#define HRPERIOD 8070
		#define HRDEVTYPE 120

		// http://www.linux-usb.org/usb.ids:

		#define DYNASTREAM_VID		0x0fcf			// 4047

		#define ANT_Development_Board1	0x1003
		#define ANTUSB_Stick					0x1004
		#define ANT_Development_Board2	0x1006
		#define ANTUSB2_Stick				0x1008
		#define ANTUSB_m_Stick				0x1009




		//#define ANTUSB_STICK			0X1004			// 4100
		//#define GARMIN_USB2_PID		0x1008			// 4104
		//#define GARMIN_OEM_PID		0x1009			// 4105

		//bool dbg = false;
		//RACERMATE::SDIRS *sdirs = NULL;


		typedef struct  {
			char name[24];
			UCHAR dev_type;			// 121
			USHORT baud;			// 57600
			UCHAR freq;				// 57
			USHORT period;			// 8086
			UCHAR chan_num;			// 0
			UCHAR dev_num;			// 0
			UCHAR trans_type;		// 0
			UCHAR chan_type;		// CHANNEL_TYPE_SLAVE, Channel type as chosen by user (master or slave), 0 = slave?
		} ANTDEF;

		#define NTYPES 2
		#define NSENSORS 2

		ANTDEF SENSORS[NTYPES] = {
			{
				"Speed Cadence",
				121,
				57600,
				57,
				8086,
				0,						// chan_num
				0,						// dev_num
				0,						// trans_type
				0						// chan_type
			},

			{
				"Heartrate",
				120,
				57600,
				57,
				8070,
				0,						// chan_num
				0,						// dev_num
				0,						// trans_type
				0						// chan_type
			},
		};

		ANTDEF antdef[NSENSORS];

		//QVector<CAD *> cad;
		//QVector<SC *> sc;
		//QVector<HR *> hr;

		void dump_antdevs(void);

#ifndef DOWORKER
#ifdef DOTIMER
		QTimer *timer=NULL;
#endif
#endif

		RACERMATE::Tmr *tmr=NULL;
		qint64 start_time;
		int debug_level;
		QObject *parent;
		FILE *logstream = NULL;
		char logstr[2048] = {0};

		//bool critsec=false;
		libusb_context *ctx = NULL;										// a libusb session
		int nants=0;
		const struct libusb_version *verstruc = NULL;
		unsigned long version=0;

		//QHash<int, ANTDEV *> devices;
		QMap<quint32, ANTDEV *> devices;

		libusb_device **usb_device_list=NULL;
		char gstr[256]={0};
		unsigned long shutdown_delay=0;

		// functions

		int init(void);
		void logg(const char *format, ...);
		//QString rstrip(const QString& str);
		void merge_log_files(void);

	//protected:
		int bp=0;
		bool listening = false;

	public:
		explicit ANT(QObject *parent = 0);
		explicit ANT(int _debug_level, QObject *parent = 0);
		~ANT();

		float get_ant_cadence(quint32 _devnum);
		float get_ant_wheel_rpm(quint32 _devnum);
		float get_ant_meters_per_hour(quint32 _devnum);
		unsigned long get_ant_cm(quint32 _devnum);

		int scan_for_devices(void);
		int start_listening(void);
		//int update(void);
		const char *get_sensors(void);
		bool get_scanning_for_devices(void)  { return scanning_for_devices; }
		int get_n_devices(void)  { return devices.size(); }
		bool is_listening(void)  { return listening; }

	signals:
	private slots:
#ifndef DOWORKER
#ifdef DOTIMER
void timeout_slot();
#endif
#endif

	protected slots:

	public slots:

	private:
		char channel_status_string[4][32] = {
											"UA",									// "UNASSIGNED CHANNEL",
											"A",									// "ASSIGNED CHANNEL",
											"S",									// "SEARCHING CHANNEL",
											"T"									// "TRACKING CHANNEL"
		};

		//DWORD start_time;							// the time the message thread starts
		bool got_caps = false;
		bool got_status = false;
		bool got_id = false;
		int devnum = 0;
		int netnum = 0;
		bool log_raw = false;

		unsigned char ant_key[8] = {0xB9, 0xA5, 0x21, 0xFB, 0xBD, 0x72, 0xC3, 0x45};		// antplus key
		USHORT ant_baud = 57600;

		bool asi;
		bool sensors_initialized;
		bool initialized = false;
		unsigned long g_ant_tid;

		char ant_logname[16];

		DWORD ant_start_time = 0L;

		FILE *ant_logstream = NULL;
		bool do_ant_logging = false;
		bool inprocess;
		bool ant_closed;
		char ant_gstring[2048];
		char pstr[256];
		char ant_error_string[256];
		char ant_str[256];
		char gstatus[4][32];					// astrstatus
		USHORT usDevicePID;
		USHORT usDeviceVID;
		UCHAR aucDeviceDescription[256];
		UCHAR aucDeviceSerial[256];
		bool bursting;										//holds whether the bursting phase of the test has started
		bool ant_broadcasting;
		bool ant_done;
		bool ant_rundone;

		bool ant_display;
		UCHAR ant_txbuf[ANT_STANDARD_DATA_PAYLOAD_SIZE];
		bool gant_channel_opened;
		UCHAR ant_caps[5];
		unsigned char ant_ack;
		unsigned char ant_msg;
};									// class ANT

}			// namespace RACERMATE

#endif					// #ifndef _ANT_H_

