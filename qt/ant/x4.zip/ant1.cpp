
#include <QtCore>

#ifdef _DEBUG
	#include <QDebug>
#endif

#include <QDateTime>

#include "ant.h"

/*
	bool asi;
	bool sensors_initialized;
	bool ant_closed;
	bool do_ant_logging;
	bool log_raw;
 */

/**********************************************************************************************************
	main site:
		http://www.libusb.org/
		http://libusb.sourceforge.net

	mailing list archives:
		http://marc.info/?l=libusb-devel

	API:
		http://libusb.sourceforge.net/api-1.0/index.html

	ANT:
		main site:  http://www.thisisant.com/   (log in)
		forum:      http://www.thisisant.com/forum/



	examples:

	to test dynastream's version:
		1. set one or both, eg, the 2nd ant stick to the dynastream driver (libusb-win32 v1.2.6.0) using zadig
		2. run .../test_programs/dynastream_ant_tester/demo_lib_2008.sln


	errno 22 = Invalid argument

	output of sudo lsusb -v:

	Bus 003 Device 005: ID 0fcf:1008 Dynastream Innovations, Inc. Mini stick Suunto
	Device Descriptor:
	bLength                18
	bDescriptorType         1
	bcdUSB               2.00
	bDeviceClass            0 (Defined at Interface level)
	bDeviceSubClass         0
	bDeviceProtocol         0
	bMaxPacketSize0        32
	idVendor           0x0fcf Dynastream Innovations, Inc.
	idProduct          0x1008 Mini stick Suunto
	bcdDevice            1.00
	iManufacturer           1 Dynastream Innovations
	iProduct                2 ANT USBStick2
	iSerial                 3 097
	bNumConfigurations      1
	Configuration Descriptor:
	 bLength                 9
	 bDescriptorType         2
	 wTotalLength           32
	 bNumInterfaces          1
	 bConfigurationValue     1
	 iConfiguration          2 ANT USBStick2
	 bmAttributes         0x80
		(Bus Powered)
	 MaxPower              100mA
	 Interface Descriptor:
		bLength                 9
		bDescriptorType         4
		bInterfaceNumber        0
		bAlternateSetting       0
		bNumEndpoints           2
		bInterfaceClass       255 Vendor Specific Class
		bInterfaceSubClass      0
		bInterfaceProtocol      0
		iInterface              2 ANT USBStick2
		Endpoint Descriptor:
		  bLength                 7
		  bDescriptorType         5
		  bEndpointAddress     0x81  EP 1 IN
		  bmAttributes            2
			 Transfer Type            Bulk
			 Synch Type               None
			 Usage Type               Data
		  wMaxPacketSize     0x0040  1x 64 bytes
		  bInterval               1
		Endpoint Descriptor:
		  bLength                 7
		  bDescriptorType         5
		  bEndpointAddress     0x01  EP 1 OUT
		  bmAttributes            2
			 Transfer Type            Bulk
			 Synch Type               None
			 Usage Type               Data
		  wMaxPacketSize     0x0040  1x 64 bytes
		  bInterval               1
	Device Status:     0x0000
	(Bus Powered)


	debug_level
		0 = no logging, no log file created
		1 = minimal debugging, logs things that shouldn't happen
		2 = more verbose

	dll interface:
	see do_ant define
	constructor (single instance)


	function						location			called from						replace with

	ant_init();										start_server()					constructor
	ant_close()										stop_trainer()					destructor

	debug only:
	get_state(int _chan)																ant->get_state(_chan)


	EV:: members
	CAD cad						dll globals											ant->cad[i]	vector
	HR hr							dll globals											ant->hr[i]	vector
	SC sc							dll globals											ant->sc[i]	vector


 **************************************************************************************************/


ANT::ANT(QObject *parent) {
	Q_UNUSED(parent);

	return;
}                                   // post2()

/**************************************************************************************************

**************************************************************************************************/

ANT::ANT(int _debug_level, QObject *_parent) : QObject(_parent) {
	parent = _parent;
	debug_level = _debug_level;

	int status;

	status = init();
	if (status != 0) {
		throw 1;
	}
}

/**************************************************************************************************

**************************************************************************************************/

ANT::~ANT() {

	int n;

	n = antdevs.size();

	foreach(int key, antdevs.keys() )  {
		delete antdevs.value(key);
	}
	antdevs.clear();


	if (timer) {
		timer->stop();
	}
	QThread::msleep(shutdown_delay);              // wait for threads to stop

	DEL(timer);

#ifdef _DEBUG
	DEL(tmr);
#endif

	if (ctx) {
		libusb_exit(ctx);
		ctx = NULL;
	}

	FCLOSE(logstream);

}                    // destructor

/****************************************************************************************

****************************************************************************************/

int ANT::init(void) {
	int status;

	cad.push_back(new CAD);
	sc.push_back(new SC());
	hr.push_back(new HR());

#if TEST_MODE == 1
	m_buttit = "Abort";

#elif TEST_MODE == 2
	timer = nullptr;
#endif

	shutdown_delay = 50;

#ifdef _DEBUG
	dbg = true;
	tmr = new RACERMATE::Tmr("ant");
#else
	dbg = false;
#endif

	bp = 0;
	ctx = NULL;                            // a libusb session
	nants = 0;
	verstruc = NULL;
	version = 0L;
	memset(gstr, 0, sizeof(gstr));

	logstream = NULL;
	memset(logstr, 0, sizeof(logstr));
	if (strlen(LOGNAME) != 0) {
		logstream = fopen(LOGNAME, "wt");
	}

	critsec = false;

	status = libusb_init(&ctx);
	if (status != 0) {
		logg("libusb_init error = %d\n", status);
		return 1;
	}

	libusb_set_debug(ctx, 3);                 // prints out more warnings!

	verstruc = libusb_get_version();
	version = ((verstruc->major << 24) & 0xff000000) | ((verstruc->minor << 16) & 0x00ff0000) | ((verstruc->micro << 8) & 0x0000ff00) | ((verstruc->nano) & 0x000000ff);
	logg("version = %08lx\n", version);          // version 1.0.20.107

#if TEST_MODE == 2
	timer = new QTimer(this);
	timer->setInterval(3000);
	start = QDateTime::currentMSecsSinceEpoch();
	connect(timer, SIGNAL(timeout()), this, SLOT(timeout_slot()));               // runs the background scanner
	timer->start();
#endif

	return 0;
}                    // init()

#if 0

/**************************************************************************************
	from old aunt.cpp:
**************************************************************************************/

int ANT::ant_init(void (*_ant_keyfunc)(void) ) {
	Q_UNUSED(_ant_keyfunc);

	if (asi) {
		return 0;
	}

	//ant_start_time = timeGetTime();
	ant_start_time = QDateTime::currentMSecsSinceEpoch();

/*
	cad.reset();
	hr.reset();
	sc.reset();
 */

//	ant_keyfunc = _ant_keyfunc;

	strcpy(ant_logname, "ant.log");

#ifdef _DEBUG
	do_ant_logging = false;
#else
	do_ant_logging = false;
#endif


	if (do_ant_logging) {
		ant_logstream = fopen(ant_logname, "wt");
	}

//	BOOL B;

#ifdef _DEBUG
//	hrcalls = 0;
//	sccalls = 0;
#endif

	//memset(ant_packet, 0, 8);

	ant_closed = false;

	//ant_channel_opened = false;
	memset(ant_caps, 0, sizeof(ant_caps));

	asi = false;
	sensors_initialized = false;
	inprocess = false;
/*
	pclSerialObject = (DSISerialGeneric*)NULL;

	framer = (DSIFramerANT*)NULL;
	uiDSIThread = (DSI_THREAD_ID)NULL;
 */

	ant_rundone = false;
	ant_done = false;
	ant_display = true;
	ant_broadcasting = false;

	memset(ant_txbuf, 0, ANT_STANDARD_DATA_PAYLOAD_SIZE);
	bursting = false;
	/*
		memset(&condTestDone, 0, sizeof(condTestDone));
		mutexTestDone = 0;
	 */

	memset(ant_gstring, 0, sizeof(ant_gstring));
	memset(ant_error_string, 0, sizeof(ant_error_string));
	memset(pstr, 0, sizeof(pstr));
	memset(ant_str, 0, sizeof(ant_str));
	//ucStatusByte = 0;

//	g_ant_tid = GetCurrentThreadId();

	memset(gstatus, 0, sizeof(gstatus));

	// Initialize condition var and mutex
//	UCHAR ucCondInit = DSIThread_CondInit(&condTestDone);
//	assert(ucCondInit == DSI_THREAD_ENONE);

//	UCHAR ucMutexInit = DSIThread_MutexInit(&mutexTestDone);
//	assert(ucMutexInit == DSI_THREAD_ENONE);

#if defined(DEBUG_FILE)
	// Enable ant_loging
	DSIDebug::Init();
	DSIDebug::SetDebug(TRUE);
#endif

	// Create Serial object
/*
	if (!pclSerialObject)  {
		pclSerialObject = new DSISerialGeneric();			// memleak
		assert(pclSerialObject);
	}
 */

	/*
		#ifdef _DEBUG
		if (do_ant_logging)  {
		if (pclSerialObject)  {
			ant_log("have pclSerialObject\n", true);
		}
		else  {
			ant_log("do not have pclSerialObject\n", true);
		}
		}

		#endif
	 */

	//--------------------------------
	// try 57600 baud:
	//--------------------------------

	/*
		ant_baud = 57600;

		{
		DEL(framer);
		B = pclSerialObject->Init(ant_baud, devnum);			// <<<<<<<<<<<<<<<< 57600, 0
		assert(B);

		if (do_ant_logging)  {
			sprintf(ant_gstring, "baud = %d, devnum = %d\n", ant_baud, devnum);
			ant_log(ant_gstring);
		}

		framer = new DSIFramerANT(pclSerialObject);
		assert(framer);
		B = framer->Init();
		assert(B);
		pclSerialObject->SetCallback(framer);
		if (do_ant_logging)  {
			sprintf(ant_gstring, "pclSerialObject->Open(), baud = %d\n", ant_baud);
			ant_log(ant_gstring, true);
		}

		//#ifdef _DEBUG
		#if 0
		{
			int dn = pclSerialObject->GetDeviceNumber();
			if(framer->GetDeviceUSBInfo(dn, aucDeviceDescription, aucDeviceSerial, USB_MAX_STRLEN))  {
				printf("  Product Description: %s\n", aucDeviceDescription);
				printf("  Serial String: %s\n", aucDeviceSerial);
			}
		}
		#endif

		B = pclSerialObject->Open();
		}
	 */

	// If the Open function failed, most likely the device
	// we are trying to access does not exist, or it is connected
	// to another program

	/*
		if(!B)  {
		sprintf(ant_gstring, "Failed to connect to device at USB port %d\n", devnum);
		ant_log(ant_gstring, true);
		DEL(framer);
		DEL(pclSerialObject);
		return 1;
		}

		// Create message thread.
		//uiDSIThread = DSIThread_CreateThread(&RunMessageThread, this);
		uiDSIThread = DSIThread_CreateThread(&RunMessageThread, NULL);
		assert(uiDSIThread);
	 */

	//-------------------------------------------------------------

	/*
		if (do_ant_logging)  {
		strcpy(ant_gstring, "ResetSystem()\n");
		ant_log(ant_gstring);
		}

		B = framer->ResetSystem();

		#ifdef _DEBUG
		Sleep(1000);
		#endif

		if (!B)  {
		if (do_ant_logging)  {
			strcpy(ant_error_string, "ResetSystem failed.\n");
			//printf("%s", ant_error_string);
			ant_log(ant_gstring, true);
		}
		DEL(framer);
		DEL(pclSerialObject);
		return 2;
		}

		DSIThread_Sleep(1000);
	 */

	bp = 0;

	//-------------------------------------------------------------

	if (do_ant_logging) {
		sprintf(ant_gstring, "SetNetworkKey(%d, <%x, %x, %x, %x, %x, %x, %x, %x >)\n",
				  netnum,                        // ant_sensors[n].net_num,
				  ant_key[0],
				  ant_key[1],
				  ant_key[2],
				  ant_key[3],
				  ant_key[4],
				  ant_key[5],
				  ant_key[6],
				  ant_key[7]
				  );
		//ant_log(ant_gstring, true);
	}

	/*
		B = framer->SetNetworkKey(netnum, ant_key);
		if (!B)  {
		if (do_ant_logging)  {
			strcpy(ant_error_string, "SetNetworkKey failed 1.\n");
			ant_log(ant_error_string, true);
		}
		return 3;
		}
		if (!ant_WaitAck(MESG_NETWORK_KEY_ID, MESSAGE_TIMEOUT))  {
		if (do_ant_logging)  {
			strcpy(ant_error_string, "SetNetworkKey failed 2.\n");
			ant_log(ant_error_string, true);
		}
		return 4;
		}

		#if defined (ENABLE_EXTENDED_MESSAGES)
		if (do_ant_logging)  {
		strcpy(ant_gstring, "RxExtMesgsEnable(TRUE)\n");
		ant_log(ant_gstring, true);
		}
		B = framer->RxExtMesgsEnable(TRUE);
		if (!B)  {
		if (do_ant_logging)  {
			strcpy(ant_error_string, "RxExtMesgsEnable failed 1\n");
			ant_log(ant_error_string, true);
		}
		return 1;
		}
		if (!ant_WaitAck(MESG_RX_EXT_MESGS_ENABLE_ID, MESSAGE_TIMEOUT))  {
		if (do_ant_logging)  {
			strcpy(ant_error_string, "RxExtMesgsEnable failed 2\n");
			ant_log(ant_error_string, true);
		}
		return 1;
		}

		#endif

		if (do_ant_logging)  {
		strcpy(ant_gstring, "Requesting capabilities\n");
		ant_log(ant_gstring, true);
		}
		ANT_MESSAGE_ITEM stResponse;
		framer->SendRequest(MESG_CAPABILITIES_ID, 0, &stResponse, 0);					// request capabilites

		// wait for request to be finished

		DWORD start = timeGetTime();
		got_caps = false;

		while(1)  {
		if ((timeGetTime()-start) > 1000L)  {
			break;
		}
		if (got_caps)  {
			break;
		}
		}
		got_caps = false;
	 */


/*
	if (do_ant_logging)  {
		strcpy(ant_gstring, "GetDeviceUSBVID(usDeviceVID)\n");
		ant_log(ant_gstring, true);
	}

	if(framer->GetDeviceUSBVID(usDeviceVID))  {
		if (do_ant_logging)  {
			sprintf(ant_gstring, "   VID: 0x%X\n", usDeviceVID);
			ant_log(ant_gstring, true);
		}
	}

	if (do_ant_logging)  {
		strcpy(ant_gstring, "GetDeviceUSBPID(usDevicePID)\n");
		ant_log(ant_gstring, true);
	}
	if(framer->GetDeviceUSBPID(usDevicePID))  {
		if (do_ant_logging)  {
			sprintf(ant_gstring, "   PID: 0x%X\n", usDevicePID);
			ant_log(ant_gstring, true);
		}
	}

	if (do_ant_logging)  {
		strcpy(ant_gstring, "GetDeviceUSBInfo\n");
		ant_log(ant_gstring, true);
	}
	if(framer->GetDeviceUSBInfo(pclSerialObject->GetDeviceNumber(), aucDeviceDescription, aucDeviceSerial, USB_MAX_STRLEN))  {
		if (do_ant_logging)  {
			sprintf(ant_gstring, "   Product Description: %s\n", aucDeviceDescription);
			ant_log(ant_gstring, true);

			sprintf(ant_gstring, "   Serial String: %s\n", aucDeviceSerial);
			ant_log(ant_gstring, true);
		}
	}


	//-------------------------------------------------------------

	if (do_ant_logging)  {
		ant_log("init device done\n\n", true);
	}

	ant_bp = 0;

	//ant_add_sc(sc);
	//ant_add_heartrate(hr);

	//ant_stick_initialized = true;
 */


	asi = true;

	return 0;

}                             // ant_init()
#endif                        // #if 1




#if TEST_MODE == 1

/****************************************************************************************

****************************************************************************************/

QString ANT::get_statstr() const {                 // getter
	return m_statstr;
}

/****************************************************************************************

****************************************************************************************/

void ANT::set_statstr(const QString &_test_str) {        // setter
	//qDebug() << "myClass::set_test_str() called with " << _test_str;
	if (m_statstr == _test_str) {
		return;
	}

	m_statstr = _test_str;
	emit statstr_changed();
}

/****************************************************************************************

****************************************************************************************/

QString ANT::get_buttit() const {                  // getter
	return m_buttit;
}

/****************************************************************************************

****************************************************************************************/


void ANT::set_buttit(const QString &_test_str) {         // setter
	if (m_buttit == _test_str) {
		return;
	}

	m_buttit = _test_str;
	emit buttit_changed();
}

#endif


/**************************************************************************
	every 3 seconds
**************************************************************************/


void ANT::timeout_slot() {
#ifdef _DEBUG
	//tmr->update();									// 1000 ms
#endif
	//scan();
	return;
}                    // timeout()



/**********************************************************************************************************

**********************************************************************************************************/

int ANT::enumerate_sticks(void) {
	int status = 0;
	ssize_t cnt;
	libusb_device *device;
	libusb_config_descriptor *config = NULL;
	int k;
	bool isant;
	char gstr[256];
	char str[256];
	FILE *stream = NULL;
	libusb_device_handle *handle = NULL;
	int antsticks = 0;
	int rc = 0;

	if (ctx == NULL) {
		status = libusb_init(&ctx);
		if (status != 0) {
			logg("libusb_init error = %d\n", status);
			rc = RMANT_ERROR_NO_CTX;
			goto finis;
		}
	}


	cnt = libusb_get_device_list(ctx, &usb_device_list);            // 16 with 2 ant sticks, 15 with 1 ant stick

	if (cnt <= 0) {
		if (usb_device_list) {
			libusb_free_device_list(usb_device_list, 1);
		}
		logg( "no usb devices found\n" );
		rc = RMANT_ERROR_NO_USB_DEVICES;
		goto finis;
	}

	stream = fopen("devs.txt", "wt");

	for (k = 0; k < cnt; k++) {

#ifdef _DEBUG
		if (k == 7) {
			bp = 1;
		}
#endif

		libusb_device_descriptor desc;
		device = usb_device_list[k];

		if (k == 10) {
			bp = 1;
		}

		status = libusb_get_device_descriptor(device, &desc);
		if (status != 0) {
			if (usb_device_list) {
				libusb_free_device_list(usb_device_list, 1);
			}
			logg("libusb_get_device_descriptor = %d\n", status);
			rc = RMANT_ERROR_GET_DEVICE_DESCRIPTOR;
			goto finis;
		}

		sprintf(gstr, "\n%2d Device:    vendor = %04x    product = %04x\n", k + 1, desc.idVendor, desc.idProduct);
		logg("%s", gstr);
		fprintf(stream, "%s", gstr);

		config = NULL;
#ifdef _DEBUG
		if (k == 2) {
			bp = 2;
		}
#endif

		status = libusb_get_config_descriptor(device, 0, &config);

#ifdef _DEBUG
		if (k == 2) {
			bp = 2;
		}
#endif

		if (status != 0) {
			sprintf(gstr, "   libusb_get_config_descriptor error: %d\n", status);
			logg("%s", gstr);
			fprintf(stream, "%s", gstr);

			if (status == LIBUSB_ERROR_NOT_FOUND) {
				bp = 1;
			}
			else  {
				bp = 2;
			}
			if (config) {
				libusb_free_config_descriptor(config);
				config = NULL;
			}
			continue;
		}

		if (config->bNumInterfaces == 0) {
			logg("   no interfaces!\n");
			libusb_free_config_descriptor(config);
			config = NULL;
			continue;
		}

		isant = false;

		/*
			#define GARMIN_USB2_VID   0x0fcf		4047
			#define GARMIN_USB2_PID   0x1008		4104

			#define GARMIN_OEM_PID    0x1009		4105
		 */

		//qDebug() << GARMIN_USB2_VID;
		//qDebug() << GARMIN_USB2_PID;
		//qDebug() << GARMIN_OEM_PID;

		if (desc.idVendor == GARMIN_USB2_VID) {
			if (desc.idProduct == GARMIN_USB2_PID) {
				isant = true;                                      // true for suunto and garmin
			}
			else if (desc.idProduct == GARMIN_OEM_PID)
			{
				// never gets here
				isant = true;
			}
		}

		if (isant) {

			status = libusb_open(device, &handle);       // Open a device and obtain a device handle

			switch (status) {
				case 0: {                        // on success
				break;
			}
				case LIBUSB_ERROR_NO_MEM:        // -11	on memory allocation failure
				case LIBUSB_ERROR_ACCESS:        // -3		if the user has insufficient permissions
				case LIBUSB_ERROR_NO_DEVICE:     // -4		if the device has been disconnected
				default:
				rc = status;
				goto finis;
			}

			/*
				handle = libusb_open_device_with_vid_pid(ctx, desc.idVendor, desc.idProduct);
				if (handle==NULL)  {
				sprintf(gstr, "   Unable to open usb device: %d <<<<<<<<<<<<<<<<<<<<<<<<<<\n", status);
				logg("%s", gstr);
				fprintf(stream, "%s", gstr);
				continue;				// I have 2 ant sticks (devices). One uses the libusb-win32 driver and the other one doesn't
				}
			 */
			status = libusb_get_string_descriptor_ascii(handle, desc.iManufacturer, (unsigned char*)str, sizeof(str) - 1);
			sprintf(gstr, "   manufacture = %s\n", str);
			logg("%s", gstr);
			fprintf(stream, "%s", gstr);

			status = libusb_get_string_descriptor_ascii(handle, desc.iProduct, (unsigned char*)str, sizeof(str) - 1);
			sprintf(gstr, "   product = %s\n", str);
			logg("%s", gstr);
			fprintf(stream, "%s", gstr);

			status = libusb_get_string_descriptor_ascii(handle, desc.iSerialNumber, (unsigned char*)str, sizeof(str));
			sprintf(gstr, "   serial number = %s\n", str);
			logg("%s", gstr);
			fprintf(stream, "%s", gstr);

			sprintf(gstr, "   num configs = %d\n", desc.bNumConfigurations);
			logg("%s", gstr);
			fprintf(stream, "%s", gstr);

			libusb_close(handle);
			handle = NULL;

			if (config) {
				libusb_free_config_descriptor(config);
				config = NULL;
			}

			antsticks++;
		}                       // if (isant)

		if (config) {
			libusb_free_config_descriptor(config);
			config = NULL;
		}
	}                             // devices, for(k)

	if (usb_device_list) {
		libusb_free_device_list(usb_device_list, 1);
		usb_device_list = NULL;
	}

finis:

	FCLOSE(stream);

	if (config) {
		libusb_free_config_descriptor(config);
		config = NULL;
	}

	if (handle) {
		libusb_close(handle);
		handle = NULL;
	}

	if (usb_device_list) {
		libusb_free_device_list(usb_device_list, 1);
		usb_device_list = NULL;
	}

	logg("\nfound %d ANT sticks that use the libusb driver in %d USB devices\n", antsticks, cnt);

	return rc;
}                                   // enumerate_sticks()

/********************************************************************************************************

********************************************************************************************************/

void ANT::logg(const char *format, ...) {

	if (!dbg) {
		return;
	}

	va_list ap;                                        // Argument pointer

	if (format == NULL) {
		return;
	}

	va_start(ap, format);
	vsprintf(logstr, format, ap);
	va_end(ap);


#ifdef _DEBUG
	qDebug() << rstrip(QString((char*)(logstr)));
#endif

	if (!logstream) {
		return;
	}

	fprintf(logstream, "%s", logstr);
	return;
}                                // logg()

/**********************************************************************************************************

	cnt = libusb_get_device_list(ctx, &list);				// memory leak
**********************************************************************************************************/

#if 0
int ANT::find_ant_sticks(void) {

	critsec = true;

	int rc = -1;
	int i, j, jj, k, cnt, n, status;
	libusb_config_descriptor *config = NULL;
	bool isant;
	const libusb_interface *inter;
	const libusb_interface_descriptor *interdesc;
	const libusb_endpoint_descriptor *epdesc;
	bool dolog = false;


#ifdef _DEBUG
	static int calls = 0;
	calls++;
	if (calls == 2) {
		bp = 3;
	}
#endif

	n = antdevs.size();

	for (int i = 0; i < n; i++) {
#ifdef _DEBUG
		if (calls == 2 && i == 1) {
			bp = 4;
		}
#endif
		/*
		if (antdevs[i].handle) {
			if ( libusb_kernel_driver_active(antdevs[i].handle, 0) ) {
				libusb_detach_kernel_driver(antdevs[i].handle, 0);
			}
		}
		antdevs[i].stop();
		*/
	}


	/*
	for (int i = 0; i < n; i++) {
		antdevs.pop_back();
	}
	antdevs.clear();
	*/

	if (usb_device_list) {
		libusb_free_device_list(usb_device_list, 1);
		usb_device_list = NULL;
	}

	cnt = libusb_get_device_list(ctx, &usb_device_list);            // memory leak


	if (cnt <= 0) {
		if (usb_device_list) {
			libusb_free_device_list(usb_device_list, 1);
			usb_device_list = NULL;
		}
		if (dolog) {
			logg( "no usb devices found\n" );
		}
		goto finis;
	}


	for (k = 0; k < cnt; k++) {
		//libusb_device_descriptor desc = {0};
		libusb_device_descriptor desc;
		libusb_device *device;

		device = usb_device_list[k];

		status = libusb_get_device_descriptor(device, &desc);
		if (status != 0) {
			if (usb_device_list) {
				libusb_free_device_list(usb_device_list, 1);
				usb_device_list = NULL;
			}
			if (dolog) {
				logg("libusb_get_device_descriptor = %d\n", status);
			}
			goto finis;
		}

		if (dolog) {
			logg("\n%2d Device:    vendor = %04x    product = %04x\n", k + 1, desc.idVendor, desc.idProduct);
		}

		config = NULL;
		status = libusb_get_config_descriptor(device, 0, &config);

		if (status != 0) {
			if (dolog) {
				logg("   libusb_get_config_descriptor error: %d\n", status);
			}
			if (status == LIBUSB_ERROR_NOT_FOUND) {
				bp = 1;
			}
			else  {
				bp = 2;
			}
			if (config) {
				libusb_free_config_descriptor(config);
				config = NULL;
			}
			continue;
			//goto finis;
		}

		if (config->bNumInterfaces == 0) {
			if (dolog) {
				logg("   no interfaces!\n");
			}
			libusb_free_config_descriptor(config);
			config = NULL;
			continue;
		}

		isant = false;

		//printf("vendor = %x, product = %x\n", desc.idVendor, desc.idProduct);

		if (desc.idVendor == GARMIN_USB2_VID && (desc.idProduct == GARMIN_USB2_PID || desc.idProduct == GARMIN_OEM_PID)) {
			isant = true;
		}

		if (isant) {
//			int jjj;
			nants++;

			//antdevs.push_back(ANTDEV());
//			jjj = antdevs.size() - 1;

			libusb_device_handle *handle = NULL;

			status = libusb_open(device, &handle);       // Open a device and obtain a device handle

			switch (status) {
				case 0: {                        // on success
				break;
			}
				case LIBUSB_ERROR_NO_MEM: {      // on memory allocation failure
				bp = 1;
				goto finis;
				break;
			}
				case LIBUSB_ERROR_ACCESS: {      // if the user has insufficient permissions
				bp = 1;
				goto finis;
				continue;
				//break;
			}
				case LIBUSB_ERROR_NO_DEVICE: {   // if the device has been disconnected
				bp = 1;
				goto finis;
				break;
			}
				default: {
				bp = 1;
				goto finis;
				break;
			}
			}
/*
			antdevs[jjj].set_vid(desc.idVendor);
			antdevs[jjj].set_pid(desc.idProduct);
			antdevs[jjj].set_bus_number(libusb_get_bus_number(device));
			antdevs[jjj].set_device_address(libusb_get_device_address(device));
			antdevs[jjj].set_ix(k);
			antdevs[jjj].set_device(usb_device_list[k]);
*/
//qDebug("fas6\n");

			char str[256];
			libusb_set_debug(ctx, 0);
			status = libusb_get_string_descriptor_ascii(handle, desc.iManufacturer, (unsigned char*)str, sizeof(str) - 1);
//qDebug("fas6b, status = %d\n", status);
			libusb_set_debug(ctx, 2);

			if (status < 0) {
				if (status == LIBUSB_ERROR_NOT_FOUND) {
//qDebug("fas6c\n");
					libusb_close(handle);
					handle = NULL;
					if (config) {
						libusb_free_config_descriptor(config);
						config = NULL;
					}
					//antdevs.pop_back();
					continue;
					//goto finis;
				}
				else  {
//qDebug("fas6d\n");
					libusb_close(handle);
					handle = NULL;
					if (config) {
						libusb_free_config_descriptor(config);
						config = NULL;
					}
					//antdevs.pop_back();
					continue;
				}
			}                             // if (status<0)  {
/*
			antdevs[jjj].set_mfgr(str);

			status = libusb_get_string_descriptor_ascii(handle, desc.iProduct, (unsigned char*)str, sizeof(str) - 1);
			antdevs[jjj].set_product(str);

			status = libusb_get_string_descriptor_ascii(handle, desc.iSerialNumber, (unsigned char*)str, sizeof(str));
			antdevs[jjj].set_sn(str);                                // garmin = "097", suunto = "1213804102"

			antdevs[jjj].set_nconfigs(desc.bNumConfigurations);
*/

			bp = 17;
//qDebug("fas7\n");

			for (i = 0; i < config->bNumInterfaces; i++) {
				inter = &config->interface[i];
				INTF intf;

				if (dolog) {
//					logg("      Interface Number: %d  /  %s  /  %s  /  %s\n", i + 1, antdevs[jjj].get_mfgr(), antdevs[jjj].get_product(), antdevs[jjj].get_sn());
				}

				for (j = 0; j < inter->num_altsetting; j++) {
					interdesc = &inter->altsetting[j];
					if (dolog) {
						logg("         alt setting number: %d\n", (int)interdesc->bInterfaceNumber);
					}
					std::vector<ALTSETTING> alts;
					ALTSETTING alt;

					for (jj = 0; jj < (int)interdesc->bNumEndpoints; jj++) {
						epdesc = &interdesc->endpoint[jj];
						if (dolog) {
							logg("            endpoint %d, Descriptor Type: %d, EP Address: %d\n",
								  jj + 1,
								  epdesc->bDescriptorType,
								  epdesc->bEndpointAddress
								  );
						}
						ENDPOINT ep;
						ep.set_type(epdesc->bDescriptorType);
						ep.set_addr(epdesc->bEndpointAddress);
						alt.add_ep(ep);
						alts.push_back(alt);
					}                 // endpoints
					//intf.alts = alts;
					intf.set_alt(alts);
				}                    // alt_settings
				//ad.ifs.push_back(intf);
//				antdevs[jjj].add_intf(intf);
				intf.clear();
			}                       // interfaces

			libusb_close(handle);
			handle = NULL;

			//antdevs.push_back(ad);
			//goto stop;
		}                                // if (isant)
		else {
			for (i = 0; i < config->bNumInterfaces; i++) {
				inter = &config->interface[i];
				if (dolog) {
					logg("      Interface Number: %d\n", i + 1);
				}

				for (j = 0; j < inter->num_altsetting; j++) {
					interdesc = &inter->altsetting[j];
					if (dolog) {
						logg("         alt setting number: %d\n", (int)interdesc->bInterfaceNumber);
					}

					for (jj = 0; jj < (int)interdesc->bNumEndpoints; jj++) {
						epdesc = &interdesc->endpoint[jj];
						if (dolog) {
							logg("            endpoint %d, Descriptor Type: %d, EP Address: %d\n", jj + 1, epdesc->bDescriptorType, epdesc->bEndpointAddress);
						}
					}                 // endpoints
				}                    // alt_settings
			}                       // interfaces
		}


		if (config) {
			libusb_free_config_descriptor(config);
			config = NULL;
		}

	}                             // devices, for(k)

	n = antdevs.size();
	rc = n;

finis:

	/*
		if (glist)  {
		libusb_free_device_list(glist, 1);
		list = NULL;
		}
	 */
//	qDebug("fasx, rc = %d\n", rc);

#ifdef WIN32
	//LeaveCriticalSection(&critsec);
//	scanning_active = false;
	critsec = false;
#else
	critsec = false;
#endif
	return rc;
}                                         // find_ant_sticks()
#endif										// #if 0




/**********************************************************************************************************

**********************************************************************************************************/

QString ANT::rstrip(const QString& str) {
	int n = str.size() - 1;

	for (; n >= 0; --n) {
		if (!str.at(n).isSpace()) {
			//if (!str.at(n)==0x0a) {
			return str.left(n + 1);
		}
	}
	return "";
}


/**********************************************************************************************************
	http://thingylab.com/wiki/c_example_with_libusb-1.0

  #pragma warning(disable:zzzz)
	your code here;

  #pragma warning(default:zzzz)

	the garmin stick is antdevs[0]
		channel 0 = speed/cadence

	the suunto stick is antdevs[1]
		channel 0 = heart rate

**********************************************************************************************************/

#if 0
int ANT::test1stick_1channel(void) {
	int status = 0;
	int attached[2] = { 0 };
	int chan;
	FILE *stream = NULL;
	QDir dir;


	Q_ASSERT(ctx);

	dir.remove("x.x");
	dir.remove("rx0.log");
	dir.remove("tx0.log");
	dir.remove("devs.txt");
	dir.remove("antdev.log");
	dir.remove("main.log");
	dir.remove("d.txt");
	dir.remove("raw.log");

	libusb_config_descriptor *config = NULL;
	int n;
	qint64 lastdisplaytime = 0L;
	qint64 now;
	unsigned short scperiod;
	int scdevtype;
	int ii;
	int k;

	bp = 0;

	libusb_device_descriptor desc;
	Q_UNUSED(desc);

	scperiod = 8086;                    // must be 8086 or you get a lot of timeouts, although it tries to work
	scdevtype = 121;                    // has to be 121

	n = find_ant_sticks();              // allocates list, creates antdevs[0], creates antdev.log (logstream)

#ifdef _DEBUG
	qDebug("ok2, n = %d\n", n);
#endif

	if (n <= 0) {
		//assert(n>0);
#ifdef _DEBUG
		qDebug("\nno ANT sticks\n\n");
#endif
		//goto finis;
		return 2;
	}

	stream = fopen("devs.txt", "wt");
//	antdevs[0].dump(stream);
	FCLOSE(stream);


	k = 0;                                 // we only have one device for this test, so it is device 0

#ifdef _DEBUG
//	antdevs[0].test();
#endif

	//antdevs[k].start_logs(k);                    // creates tx0.log and rx0.log

#ifdef _DEBUG
//	antdevs[0].test();
#endif

//	ii = antdevs[k].get_ix();                 // 7th in the list of usb devices
//	antdevs[k].set_device(usb_device_list[ii]);
/*
	status = libusb_open(antdevs[k].get_device(), &antdevs[k].handle);   // Open a device and obtain a device handle
	switch (status) {
		case 0: {                                                         // on success
		break;
	}
		case LIBUSB_ERROR_NO_MEM: {      // on memory allocation failure
		bp = 1;
		break;
	}
		case LIBUSB_ERROR_ACCESS: {      // if the user has insufficient permissions
		bp = 1;
		break;
	}
		case LIBUSB_ERROR_NO_DEVICE: {   // if the device has been disconnected
		bp = 1;
		break;
	}
		default: {
		bp = 1;
		break;
	}
	}

	if (antdevs[k].handle == NULL) {
		logg("Unable to open usb device: %d\n", status);
		//goto finis;
		return 3;
	}
*/


//#ifdef _DEBUG
#if 0
	status = libusb_get_device_descriptor(antdevs[k].get_device(), &desc);
	if (status != 0) {
		if (usb_device_list) {
			libusb_free_device_list(usb_device_list, 1);
			usb_device_list = NULL;
		}
		logg("libusb_get_device_descriptor = %d\n", status);
		//goto finis;
		return 4;
	}

	status = libusb_get_string_descriptor_ascii(antdevs[k].handle, desc.iManufacturer, (unsigned char*)antdevs[k].mfgr, sizeof(antdevs[k].mfgr) - 1);
	status = libusb_get_string_descriptor_ascii(antdevs[k].handle, desc.iProduct, (unsigned char*)antdevs[k].prod, sizeof(antdevs[k].prod) - 1);
	status = libusb_get_string_descriptor_ascii(antdevs[k].handle, desc.iSerialNumber, (unsigned char*)antdevs[k].serial_number, sizeof(antdevs[k].serial_number));
#endif

/*
	if ( libusb_kernel_driver_active(antdevs[k].handle, 0) ) {
		libusb_detach_kernel_driver(antdevs[k].handle, 0);
		attached[k] = 1;
	}

	status = libusb_claim_interface( antdevs[k].handle, 0 );             // memory leak
	if (status) {
		logg( "Failed to claim interface. " );

		switch (status) {
			case LIBUSB_ERROR_NOT_FOUND: {
			logg( "not found\n" );
			break;
		}
			case LIBUSB_ERROR_BUSY: {
			logg( "busy\n" );
			break;
		}
			case LIBUSB_ERROR_NO_DEVICE: {
			logg( "no device\n" );
			break;
		}
			default: {
			logg( "other\n" );
			break;
		}
		}

		//goto finis;
		return 6;
	}                             // if (status)
*/
	//logg( "Claimed interface\n");

#ifdef _DEBUG
//	antdevs[0].test();
#endif

//qDebug(("ok1\n");


//	status = antdevs[k].start();                                // start the device, creates rx, tx threads, calls ANTMsg::resetSystem() and ANTMsg::setNetworkKey(net, key)
//qDebug(("ok2, status = %d\n", status);

	//chan = 6;
	chan = 0;

//	antdevs[k].set_devtype(chan, scdevtype);
//	antdevs[k].set_period(chan, scperiod);

/*
	status = antdevs[k].start_channel(chan);                    // start channel
	if (status) {
#ifdef _DEBUG
		qDebug("start channel returned %d\n", status);
		qDebug("scerr = %s\n", antdevs[k].get_error_string());
#endif
		//goto finis;
		return 5;
	}
*/


#ifdef _DEBUG
	//antdevs[0].test();
#endif

	bp = 0;
	bool runflag = true;

	while (runflag) {

		QThread::msleep(100);



		now = QDateTime::currentMSecsSinceEpoch();

		if ((now - lastdisplaytime) >= 500L) {
#ifdef _DEBUG
		//	qDebug("cadence = %3.0f, wheel rpm = %3.0f, speed = %4.1f mph, distance = %4.0f feet\n", antdevs[k].ant_cadence, antdevs[k].ant_wheel_rpm, METERSTOMILES * antdevs[k].ant_speed, CMTOFEET * antdevs[k].ulDistance);
#endif
			lastdisplaytime = now;
		}                          // if ((now-lastdisplaytime) >= 5000L)  {

	}                             // while(1)


//finis:
	if ( attached[k] == 1 ) {
		//libusb_attach_kernel_driver( antdevs[k].handle, 0 );
	}

//finis:

	if (usb_device_list) {
		libusb_free_device_list(usb_device_list, 1);
		usb_device_list = NULL;
	}

	if (config) {
		libusb_free_config_descriptor(config);
		config = NULL;
	}

	if (antdevs.size() == 1) {
		//antdevs[k].stop();
	}

	n = antdevs.size();

	if (n == 1) {
		merge_log_files();
	}

	for (int i = 0; i < n; i++) {
		//antdevs.pop_back();
	}
	antdevs.clear();

	if (ctx) {
		libusb_exit(ctx);
		ctx = NULL;
	}

	n = antdevs.size();
	Q_ASSERT(n == 0);

	return 0;
}                                   // test1stick_1channel()
#endif


/**********************************************************************************************************
	merges rx0.log and tx0.log
**********************************************************************************************************/

void ANT::merge_log_files(void) {


	QFile::copy("rx0.log", "x.x");

#ifdef WIN32
	int status;
	const char *cmd1 = "c:\\cygwin64\\bin\\cat tx0.log >> x.x";
	status = system(cmd1);

	const char *cmd2 = "c:\\cygwin64\\bin\\sort x.x > d.txt";
	status = system(cmd2);
#endif

	QDir dir;
	dir.remove("x.x");
//	unlink("rx0.log");
//	unlink("tx0.log");


	return;
}


/**********************************************************************************************************
	http://thingylab.com/wiki/c_example_with_libusb-1.0
**********************************************************************************************************/

#if 0
int ANT::test1stick_2channels(void) {
	int status = 0;
	int attached[2] = { 0 };
	int k, i;
	//int nTimeout = 500;													//in milliseconds
	//int BytesWritten = 0;
	int chan1, chan2;
	FILE *stream = NULL;

	libusb_config_descriptor *config = NULL;
	int n;
	//const struct libusb_version *verstruc;
	//unsigned long version;
	//char c;
	//bool flag = true;
	qint64 lastdisplaytime = 0L;
	qint64 now;

	//unsigned char freq = 57;
	unsigned short scperiod;
	int scdevtype;
	unsigned short hrperiod;
	int hrdevtype;
	//bool bstatus;
	bool runflag = true;

	Q_ASSERT(ctx);
	QThread::msleep(500);


	//if (chan2==chan1)  {
	//	chan2 = (chan1 + 1) % 8;
	//}

	chan1 = 6;
	chan2 = 5;


	logg("chan1 = %d\n", chan1);
	logg("chan2 = %d\n", chan2);

	libusb_device_descriptor desc;
	Q_UNUSED(desc);

	scperiod = 8086;                    // must be 8086 or you get a lot of timeouts, although it tries to work
	scdevtype = 121;                    // has to be 121

	hrperiod = 8070;
	hrdevtype = 120;


	n = find_ant_sticks();

	Q_ASSERT(n > 0);

	stream = fopen("devs.txt", "wt");

	for (i = 0; i < n; i++) {
		antdevs[i].dump(stream);
	}

	FCLOSE(stream);

	int ii;

	/////////////////////////////////////////////////////////////////////////////////////////////////

	k = 0;

	ii = antdevs[k].get_ix();
	antdevs[k].set_device(usb_device_list[ii]);

	status = libusb_open(antdevs[k].get_device(), &antdevs[k].handle);   // Open a device and obtain a device handle
	switch (status) {
		case 0: {                                                         // on success
		break;
	}
		case LIBUSB_ERROR_NO_MEM: {      // on memory allocation failure
		bp = 1;
		break;
	}
		case LIBUSB_ERROR_ACCESS: {      // if the user has insufficient permissions
		bp = 1;
		break;
	}
		case LIBUSB_ERROR_NO_DEVICE: {   // if the device has been disconnected
		bp = 1;
		break;
	}
		default: {
		bp = 1;
		break;
	}
	}

	if (antdevs[k].handle == NULL) {
		logg("Unable to open usb device: %d\n", status);
		goto finis;
	}


#ifdef _DEBUG
	status = libusb_get_device_descriptor(antdevs[k].get_device(), &desc);
	if (status != 0) {
		if (usb_device_list) {
			libusb_free_device_list(usb_device_list, 1);
		}
		logg("libusb_get_device_descriptor = %d\n", status);
		goto finis;
	}

	status = libusb_get_string_descriptor_ascii(antdevs[k].handle, desc.iManufacturer, (unsigned char*)antdevs[k].mfgr, sizeof(antdevs[k].mfgr) - 1);
	status = libusb_get_string_descriptor_ascii(antdevs[k].handle, desc.iProduct, (unsigned char*)antdevs[k].prod, sizeof(antdevs[k].prod) - 1);

	logg("\nusing device:    %s / %s\n", antdevs[k].mfgr, antdevs[k].prod);
#endif


	logg( "\nopened USB device\n" );
	if ( libusb_kernel_driver_active(antdevs[k].handle, 0) ) {
		logg("Device busy...detaching...\n");
		libusb_detach_kernel_driver(antdevs[k].handle, 0);
		attached[k] = 1;
	}
	else  {
		logg("Device free from kernel\n");
	}

	//status = libusb_set_configuration(handle, 1);		// tell libusb to use the CONFIGNUM configuration of the device

	status = libusb_claim_interface( antdevs[k].handle, 0 );             // memory leak
	if (status) {
		logg( "Failed to claim interface. " );

		switch (status) {
			case LIBUSB_ERROR_NOT_FOUND: {
			logg( "not found\n" );
			break;
		}
			case LIBUSB_ERROR_BUSY: {
			logg( "busy\n" );
			break;
		}
			case LIBUSB_ERROR_NO_DEVICE: {
			logg( "no device\n" );
			break;
		}
			default: {
			logg( "other\n" );
			break;
		}
		}

		goto finis;
	}                             // if (status)

	logg( "Claimed interface\n");

	antdevs[k].set_devtype(chan1, scdevtype);
	antdevs[k].set_period(chan1, scperiod);

	/////////////////////////////////////////////////////////////////////////////////////////////////

	k = 1;


	ii = antdevs[k].get_ix();
	antdevs[k].set_device(usb_device_list[ii]);

	status = libusb_open(antdevs[k].get_device(), &antdevs[k].handle);   // Open a device and obtain a device handle
	switch (status) {
		case 0: {                                                         // on success
		break;
	}
		case LIBUSB_ERROR_NO_MEM: {      // on memory allocation failure
		bp = 1;
		break;
	}
		case LIBUSB_ERROR_ACCESS: {      // if the user has insufficient permissions
		bp = 1;
		break;
	}
		case LIBUSB_ERROR_NO_DEVICE: {   // if the device has been disconnected
		bp = 1;
		break;
	}
		default: {
		bp = 1;
		break;
	}
	}

	if (antdevs[k].handle == NULL) {
		logg("Unable to open usb device: %d\n", status);
		goto finis;
	}


#ifdef _DEBUG
	status = libusb_get_device_descriptor(antdevs[k].get_device(), &desc);
	if (status != 0) {
		if (usb_device_list) {
			libusb_free_device_list(usb_device_list, 1);
		}
		logg("libusb_get_device_descriptor = %d\n", status);
		goto finis;
	}

	status = libusb_get_string_descriptor_ascii(antdevs[k].handle, desc.iManufacturer, (unsigned char*)antdevs[k].mfgr, sizeof(antdevs[k].mfgr) - 1);
	status = libusb_get_string_descriptor_ascii(antdevs[k].handle, desc.iProduct, (unsigned char*)antdevs[k].prod, sizeof(antdevs[k].prod) - 1);

	logg("\nusing device:    %s / %s\n", antdevs[k].mfgr, antdevs[k].prod);
#endif


	logg( "\nopened USB device\n" );
	if ( libusb_kernel_driver_active(antdevs[k].handle, 0) ) {
		logg("Device busy...detaching...\n");
		libusb_detach_kernel_driver(antdevs[k].handle, 0);
		attached[k] = 1;
	}
	else  {
		logg("Device free from kernel\n");
	}

	//status = libusb_set_configuration(handle, 1);		// tell libusb to use the CONFIGNUM configuration of the device

	status = libusb_claim_interface( antdevs[k].handle, 0 );             // memory leak
	if (status) {
		logg( "Failed to claim interface. " );

		switch (status) {
			case LIBUSB_ERROR_NOT_FOUND: {
			logg( "not found\n" );
			break;
		}
			case LIBUSB_ERROR_BUSY: {
			logg( "busy\n" );
			break;
		}
			case LIBUSB_ERROR_NO_DEVICE: {
			logg( "no device\n" );
			break;
		}
			default: {
			logg( "other\n" );
			break;
		}
		}

		goto finis;
	}                             // if (status)

	logg( "Claimed interface\n");

	antdevs[k].set_devtype(chan2, hrdevtype);
	antdevs[k].set_period(chan2, hrperiod);

	antdevs[0].start();
	antdevs[1].start();                             // starts threads and initializes the ANT device

	bp = 0;


	while (runflag) {

		QThread::msleep(100);


		now = QDateTime::currentMSecsSinceEpoch();

		if ((now - lastdisplaytime) >= 500L) {
			logg("\n");
			k = 0;
			logg("cadence = %.0f, wheel rpm = %.0f, speed = %.1f mph, distance = %.0f feet\n", antdevs[k].ant_cadence, antdevs[k].ant_wheel_rpm, METERSTOMILES * antdevs[k].ant_speed, CMTOFEET * antdevs[k].ulDistance);
			k = 1;
			logg("ant_hr = %d, ant_calculated_hr = %d\n", antdevs[k].ant_hr, antdevs[k].ant_calculated_hr);
			lastdisplaytime = now;
		}                          // if ((now-lastdisplaytime) >= 5000L)  {

	}                             // while(1)

	//libusb_hotplug_deregister_callback(ctx, hphandle);
	//hphandle = NULL;

	//if we detached kernel driver, reattach.

	for (k = 0; k < n; k++) {
		if ( attached[k] == 1 ) {
			libusb_attach_kernel_driver( antdevs[k].handle, 0 );
		}
	}

finis:

	if (usb_device_list) {
		libusb_free_device_list(usb_device_list, 1);
		usb_device_list = NULL;
	}

	if (config) {
		libusb_free_config_descriptor(config);
		config = NULL;
	}

	/*
		if (antdevs[ix].handle)  {
		libusb_close(antdevs[ix].handle);
		antdevs[ix].handle = NULL;
		}
	 */

	//n = antdevs.size();
	n = nants;

	for (i = 0; i < n; i++) {
		//antdevs[i]->stop();
		//DEL(antdevs[i]);
		antdevs[i].stop();
		bp = i;
		//antdevs[i].clear();
		/*
			if (antdevs[ix].handle)  {
			libusb_close(antdevs[ix].handle);
			antdevs[ix].handle = NULL;
			}
		 */
	}
	antdevs.clear();

	if (ctx) {
		libusb_exit(ctx);
		ctx = NULL;
	}

	return 0;
}                                   // test1stick_2channels()
#endif	//#if 0


/**********************************************************************************************************
	http://thingylab.com/wiki/c_example_with_libusb-1.0

	the garmin stick is antdevs[0]
		channel 0 = speed/cadence

	the suunto stick is antdevs[1]
		channel 0 = heart rate

**********************************************************************************************************/
#if 0

int ANT::test2sticks(void) {
	int status = 0;
	int attached = 0;
	int k, i, j, jj;
	ssize_t cnt;
	//int rep = 0;							// read endpoint
	//int wep = 0;							// write endpoint
	//int nTimeout = 500;													//in milliseconds
	//int BytesWritten = 0;

	libusb_config_descriptor *config = NULL;
	const libusb_interface *inter;
	const libusb_interface_descriptor *interdesc;
	const libusb_endpoint_descriptor *epdesc;
	int n;
	bool isant;
	//char c;
	//bool flag = true;
	qint64 lastdisplaytime = 0L;
	qint64 now;
//	unsigned char buf[32];
	//unsigned char freq = 57;
	unsigned short scperiod;
	int scdevtype;
	unsigned short hrperiod;
	int hrdevtype;
	int scix;
	int hrix;

	Q_ASSERT(ctx);

	bp = 0;

	scperiod = 8086;                    // must be 8086 or you get a lot of timeouts, although it tries to work
	scdevtype = 121;                    // has to be 121

	hrperiod = 8070;
	hrdevtype = 120;

	cnt = libusb_get_device_list(ctx, &usb_device_list);            // memory leak

	if (cnt <= 0) {
		if (usb_device_list) {
			libusb_free_device_list(usb_device_list, 1);
		}
		printf("no usb devices found\n" );
		goto finis;
	}


	for (k = 0; k < cnt; k++) {
		libusb_device_descriptor desc;
		libusb_device *device;

#ifdef _DEBUG
		if (k == 13) {
			bp = 0;
		}
#endif
		device = usb_device_list[k];

		status = libusb_get_device_descriptor(device, &desc);
		if (status != 0) {
			if (usb_device_list) {
				libusb_free_device_list(usb_device_list, 1);
			}
			logg("libusb_get_device_descriptor = %d\n", status);
			goto finis;
		}

		//console->printxy(0, 24, "\n%2d Device:    vendor = %04x    product = %04x\n", k+1, desc.idVendor, desc.idProduct);
		logg("%2d Device:    vendor = %04x    product = %04x", k + 1, desc.idVendor, desc.idProduct);

		config = NULL;
		status = libusb_get_config_descriptor(device, 0, &config);

		if (status != 0) {
			logg("   libusb_get_config_descriptor error: %d\n", status);
			if (status == LIBUSB_ERROR_NOT_FOUND) {
				bp = 1;
			}
			else  {
				bp = 2;
			}
			if (config) {
				libusb_free_config_descriptor(config);
				config = NULL;
			}
			continue;
		}

		if (config->bNumInterfaces == 0) {
			logg("   no interfaces!\n");
			libusb_free_config_descriptor(config);
			config = NULL;
			continue;
		}

		isant = false;

		if (desc.idVendor == GARMIN_USB2_VID && (desc.idProduct == GARMIN_USB2_PID || desc.idProduct == GARMIN_OEM_PID)) {
			isant = true;
		}

		if (isant) {
			ANTDEV ad;
			libusb_device_handle *handle = NULL;

			status = libusb_open(device, &handle);       // Open a device and obtain a device handle

			switch (status) {
				case 0: {                        // on success
				break;
			}
				case LIBUSB_ERROR_NO_MEM: {      // on memory allocation failure
				bp = 1;
				break;
			}
				case LIBUSB_ERROR_ACCESS: {      // if the user has insufficient permissions
				bp = 1;
				break;
			}
				case LIBUSB_ERROR_NO_DEVICE: {   // if the device has been disconnected
				bp = 1;
				break;
			}
				default: {
				bp = 1;
				break;
			}
			}

			ad.set_vid(desc.idVendor);
			ad.set_pid(desc.idProduct);
			ad.set_bus_number(libusb_get_bus_number(device));
			ad.set_device_address(libusb_get_device_address(device));
			ad.set_ix(k);

			char str[256];
			status = libusb_get_string_descriptor_ascii(handle, desc.iManufacturer, (unsigned char*)str, sizeof(str) - 1);
			if (status < 0) {
				if (status == LIBUSB_ERROR_NOT_FOUND) {
					// fails here if the driver is set to libusb0 (win32)
					libusb_close(handle);
					handle = NULL;
					if (config) {
						libusb_free_config_descriptor(config);
						config = NULL;
					}
					continue;
					//goto finis;
				}
				else  {
					libusb_close(handle);
					handle = NULL;
					if (config) {
						libusb_free_config_descriptor(config);
						config = NULL;
					}
					continue;
				}
			}

			ad.set_mfgr(str);

			status = libusb_get_string_descriptor_ascii(handle, desc.iProduct, (unsigned char*)str, sizeof(str) - 1);
			ad.set_product(str);

			status = libusb_get_string_descriptor_ascii(handle, desc.iSerialNumber, (unsigned char*)str, sizeof(str));
			ad.set_sn(str);

			ad.set_nconfigs(desc.bNumConfigurations);

			bp = 17;

			for (i = 0; i < config->bNumInterfaces; i++) {
				inter = &config->interface[i];
				INTF intf;

				logg("      Interface Number: %d  /  %s  /  %s  /  %s\n", i + 1, ad.get_mfgr(), ad.get_product(), ad.get_sn());

				for (j = 0; j < inter->num_altsetting; j++) {
					interdesc = &inter->altsetting[j];
					logg("         alt setting number: %d\n", (int)interdesc->bInterfaceNumber);
					std::vector<ALTSETTING> alts;
					ALTSETTING alt;

					for (jj = 0; jj < (int)interdesc->bNumEndpoints; jj++) {
						epdesc = &interdesc->endpoint[jj];
						logg("            endpoint %d, Descriptor Type: %d, EP Address: %d\n",
							  jj + 1,
							  epdesc->bDescriptorType,
							  epdesc->bEndpointAddress
							  );
						ENDPOINT ep;
						ep.set_type(epdesc->bDescriptorType);
						ep.set_addr(epdesc->bEndpointAddress);
						alt.add_ep(ep);
						alts.push_back(alt);
					}                 // endpoints
					//intf.alts = alts;
					intf.set_alt(alts);
				}                    // alt_settings
				//ad.ifs.push_back(intf);
				ad.add_intf(intf);
				intf.clear();
			}                       // interfaces

			libusb_close(handle);
			handle = NULL;

			//antdevs.push_back(ad);
			//goto stop;
		}                                // if (isant)
		else {
			for (i = 0; i < config->bNumInterfaces; i++) {
				inter = &config->interface[i];
				logg("      Interface Number: %d\n", i + 1);

				for (j = 0; j < inter->num_altsetting; j++) {
					interdesc = &inter->altsetting[j];
					logg("         alt setting number: %d\n", (int)interdesc->bInterfaceNumber);

					for (jj = 0; jj < (int)interdesc->bNumEndpoints; jj++) {
						epdesc = &interdesc->endpoint[jj];
						logg("            endpoint %d, Descriptor Type: %d, EP Address: %d\n", jj + 1, epdesc->bDescriptorType, epdesc->bEndpointAddress);
					}                 // endpoints
				}                    // alt_settings
			}                       // interfaces
		}


		if (config) {
			libusb_free_config_descriptor(config);
			config = NULL;
		}

	}                             // devices, for(k)


//stop:
	FILE *stream;

	n = antdevs.size();
	if (n == 0) {
		logg("\nno ant devices\n");
		goto finis;
	}

	stream = fopen("devs.txt", "wt");

	for (i = 0; i < n; i++) {
		antdevs[i].dump(stream);
	}

	FCLOSE(stream);

	if (n < 2) {
		logg("\nonly 1 ANT device! Need at least 2 for this test!\n");
		goto finis;
	}

	//NOTE: the suunto is set up for dynastream's driver (libusb0), the Garmin stick is the second device (winusb)
	// use zadig to select the driver that you want for a particular device.


	scix = 0;
	hrix = 1;

	int ii;

	ii = antdevs[scix].get_ix();
	antdevs[scix].set_device(usb_device_list[ii]);

	ii = antdevs[hrix].get_ix();
	antdevs[hrix].set_device(usb_device_list[ii]);

	bp = 0;

	for (k = 0; k < n; k++) {
		status = libusb_open(antdevs[k].get_device(), &antdevs[k].handle);   // Open a device and obtain a device handle
		switch (status) {
			case 0: {                                                         // on success
			break;
		}
			case LIBUSB_ERROR_NO_MEM: {   // on memory allocation failure
			bp = 1;
			break;
		}
			case LIBUSB_ERROR_ACCESS: {   // if the user has insufficient permissions
			bp = 1;
			break;
		}
			case LIBUSB_ERROR_NO_DEVICE: { // if the device has been disconnected
			bp = 1;
			break;
		}
			default: {
			bp = 1;
			break;
		}
		}

		if (antdevs[k].handle == NULL) {
			logg("Unable to open usb device: %d\n", status);
			goto finis;
		}


#ifdef _DEBUG
		libusb_device_descriptor desc;

		status = libusb_get_device_descriptor(antdevs[k].get_device(), &desc);
		if (status != 0) {
			if (usb_device_list) {
				libusb_free_device_list(usb_device_list, 1);
			}
			logg("libusb_get_device_descriptor = %d\n", status);
			goto finis;
		}

		status = libusb_get_string_descriptor_ascii(antdevs[k].handle, desc.iManufacturer, (unsigned char*)antdevs[k].mfgr, sizeof(antdevs[k].mfgr) - 1);
		status = libusb_get_string_descriptor_ascii(antdevs[k].handle, desc.iProduct, (unsigned char*)antdevs[k].prod, sizeof(antdevs[k].prod) - 1);

		logg("\nusing device:    %s / %s\n", antdevs[k].mfgr, antdevs[k].prod);
#endif


		logg( "\nopened USB device\n" );
		if ( libusb_kernel_driver_active(antdevs[k].handle, 0) ) {
			logg("Device busy...detaching...\n");
			libusb_detach_kernel_driver(antdevs[k].handle, 0);
			attached = 1;
		}
		else  {
			logg("Device free from kernel\n");
		}

		//status = libusb_set_configuration(handle, 1);		// tell libusb to use the CONFIGNUM configuration of the device

		status = libusb_claim_interface( antdevs[k].handle, 0 );          // memory leak
		if (status) {
			logg( "Failed to claim interface. " );

			switch (status) {
				case LIBUSB_ERROR_NOT_FOUND: {
				logg( "not found\n" );
				break;
			}
				case LIBUSB_ERROR_BUSY: {
				logg( "busy\n" );
				break;
			}
				case LIBUSB_ERROR_NO_DEVICE: {
				logg( "no device\n" );
				break;
			}
				default: {
				logg( "other\n" );
				break;
			}
			}

			goto finis;
		}                          // if (status)

		logg( "Claimed interface\n");

		/*
			status = libusb_hotplug_register_callback(
			ctx,							// libusb_context *
			0,								// libusb_hotplug_event	events,
			0,								// libusb_hotplug_flag	flags,
			ad.vid,						// int   vendor_id,
			ad.pid,						// int   product_id,
			0,								// int   dev_class,
			hotplug,						// libusb_hotplug_callback_fn    cb_fn,
			NULL,							// void *   user_data,
			hphandle						// libusb_hotplug_callback_handle *    handle
			);
		 */

		bp = k;
	}                    // for (k)


	antdevs[scix].set_devtype(0, scdevtype);
	antdevs[scix].set_period(0, scperiod);

	antdevs[hrix].set_devtype(0, hrdevtype);
	antdevs[hrix].set_period(0, hrperiod);

	antdevs[scix].start();                             // starts threads and initializes the ANT device
	antdevs[hrix].start();                             // starts threads and initializes the ANT device

	bp = 0;

	logg("\n");
	logg("starting main loop");
	logg("\n");

	while (1) {
		QThread::msleep(100);


		now = QDateTime::currentMSecsSinceEpoch();

		if ((now - lastdisplaytime) >= 500L) {
			//char str[256];
			//logg("ant_hr = %d, ant_calculated_hr = %d\n", antdevs[hrix].ant_hr, antdevs[hrix].ant_calculated_hr);
			//logg("cadence = %.0f, wheel rpm = %.0f, speed = %.1f mph, distance = %.0f feet\n", antdevs[scix].ant_cadence, antdevs[scix].ant_wheel_rpm, METERSTOMILES*antdevs[scix].ant_speed, CMTOFEET*antdevs[scix].ulDistance);
			/*
				SMALL_RECT r;
				r.Left = SCROLL_LEFT;
				r.Top = 0;
				r.Bottom = r.Top+1;
				r.Right = console->getmaxx();
				console->clear_win(r, 0x07);
			 */

//#ifdef WIN32
#if 0
			console->textattr(0x07);
			sprintf(str, "ant_hr = %3d, ant_calculated_hr = %3d\n", antdevs[hrix].ant_hr, antdevs[hrix].ant_calculated_hr);
			console->printxy(0, 0, str);

			sprintf(str, "cadence = %3.0f, wheel rpm = %3.0f, speed = %4.1f mph, distance = %4.0f feet\n", antdevs[scix].ant_cadence, antdevs[scix].ant_wheel_rpm, METERSTOMILES * antdevs[scix].ant_speed, CMTOFEET * antdevs[scix].ulDistance);
			console->printxy(0, 1, str);
#else
			printf("cadence = %3.0f, wheel rpm = %3.0f, speed = %4.1f mph, distance = %4.0f feet\n", antdevs[scix].ant_cadence, antdevs[scix].ant_wheel_rpm, METERSTOMILES * antdevs[scix].ant_speed, CMTOFEET * antdevs[scix].ulDistance);
#endif
			lastdisplaytime = now;
		}                          // if ((now-lastdisplaytime) >= 5000L)  {
	}                             // while(1)

	//libusb_hotplug_deregister_callback(ctx, hphandle);
	//hphandle = NULL;

	//if we detached kernel driver, reattach.
	if ( attached == 1 ) {
		libusb_attach_kernel_driver( antdevs[scix].handle, 0 );
		libusb_attach_kernel_driver( antdevs[hrix].handle, 0 );
	}

finis:

//printf("finis1\n");
	if (usb_device_list) {
		libusb_free_device_list(usb_device_list, 1);
		usb_device_list = NULL;
	}

//printf("finis2\n");
	if (config) {
		libusb_free_config_descriptor(config);
		config = NULL;
	}

	/*
		if (antdevs[ix].handle)  {
		libusb_close(antdevs[ix].handle);
		antdevs[ix].handle = NULL;
		}
	 */

	n = antdevs.size();

	for (i = 0; i < n; i++) {
		//antdevs[i]->stop();
		//DEL(antdevs[i]);
		antdevs[i].stop();
		bp = i;
		//antdevs[i].clear();
		/*
			if (antdevs[ix].handle)  {
			libusb_close(antdevs[ix].handle);
			antdevs[ix].handle = NULL;
			}
		 */
	}
//printf("finis3\n");
	antdevs.clear();

//printf("finis4\n");
	if (ctx) {
		libusb_exit(ctx);
		ctx = NULL;
	}

//printf("finisx\n");

	return 0;
}                                   // test2sticks()
#endif			// #if 0

/**********************************************************************************************************

**********************************************************************************************************/
#if 0

int ANT::test_discovery_one_stick_one_channel(void) {
	int status = 0;
	int attached[2] = { 0 };
	FILE *stream = NULL;
	libusb_config_descriptor *config = NULL;
	int n;
	//char c;
	//bool flag = true;
	qint64 lastdisplaytime = 0L;
	qint64 now;
	int ii;
	bool runflag = true;

	Q_ASSERT(ctx);

	libusb_device_descriptor desc;
	Q_UNUSED(desc);

//	scperiod = 8086;							// must be 8086 or you get a lot of timeouts, although it tries to work
//	scdevtype = 121;							// has to be 121

	n = find_ant_sticks();                       // allocates list

	Q_ASSERT(n > 0);

	stream = fopen("devs.txt", "wt");
	antdevs[0].dump(stream);
	FCLOSE(stream);

	antdevs[0].start_logs(0);

	ii = antdevs[0].get_ix();
	antdevs[0].set_device(usb_device_list[ii]);

	status = libusb_open(antdevs[0].get_device(), &antdevs[0].handle);   // Open a device and obtain a device handle
	switch (status) {
		case 0: {                                                         // on success
		break;
	}
		case LIBUSB_ERROR_NO_MEM: {      // on memory allocation failure
		bp = 1;
		break;
	}
		case LIBUSB_ERROR_ACCESS: {      // if the user has insufficient permissions
		bp = 1;
		break;
	}
		case LIBUSB_ERROR_NO_DEVICE: {   // if the device has been disconnected
		bp = 1;
		break;
	}
		default: {
		bp = 1;
		break;
	}
	}

	if (antdevs[0].handle == NULL) {
		logg("Unable to open usb device: %d\n", status);
		goto finis;
	}


#ifdef _DEBUG
	status = libusb_get_device_descriptor(antdevs[0].get_device(), &desc);
	if (status != 0) {
		if (usb_device_list) {
			libusb_free_device_list(usb_device_list, 1);
			usb_device_list = NULL;
		}
		logg("libusb_get_device_descriptor = %d\n", status);
		goto finis;
	}

	status = libusb_get_string_descriptor_ascii(antdevs[0].handle, desc.iManufacturer, (unsigned char*)antdevs[0].mfgr, sizeof(antdevs[0].mfgr) - 1);
	status = libusb_get_string_descriptor_ascii(antdevs[0].handle, desc.iProduct, (unsigned char*)antdevs[0].prod, sizeof(antdevs[0].prod) - 1);

	logg("\nusing device:    %s / %s\n", antdevs[0].mfgr, antdevs[0].prod);
#endif


	logg( "\nopened USB device\n" );
	if ( libusb_kernel_driver_active(antdevs[0].handle, 0) ) {
		logg("Device busy...detaching...\n");
		libusb_detach_kernel_driver(antdevs[0].handle, 0);
		attached[0] = 1;
	}
	else  {
		logg("Device free from kernel\n");
	}

	//status = libusb_set_configuration(handle, 1);		// tell libusb to use the CONFIGNUM configuration of the device

	status = libusb_claim_interface( antdevs[0].handle, 0 );             // memory leak
	if (status) {
		logg( "Failed to claim interface. " );

		switch (status) {
			case LIBUSB_ERROR_NOT_FOUND: {
			logg( "not found\n" );
			break;
		}
			case LIBUSB_ERROR_BUSY: {
			logg( "busy\n" );
			break;
		}
			case LIBUSB_ERROR_NO_DEVICE: {
			logg( "no device\n" );
			break;
		}
			default: {
			logg( "other\n" );
			break;
		}
		}

		goto finis;
	}                             // if (status)

	logg( "Claimed interface\n");

	/*
		antdevs[0].set_devtype(chan, scdevtype);
		antdevs[0].set_period(chan, scperiod);
	 */


	antdevs[0].start();

	//logg( "\n");

	bp = 0;

	while (runflag) {

		QThread::msleep(100);


		now = QDateTime::currentMSecsSinceEpoch();

		if ((now - lastdisplaytime) >= 500L) {
//#ifdef WIN32
#if 0
			console->textattr(0x07);
			sprintf(str, "cadence = %3.0f, wheel rpm = %3.0f, speed = %4.1f mph, distance = %4.0f feet\n", antdevs[0].ant_cadence, antdevs[0].ant_wheel_rpm, METERSTOMILES * antdevs[0].ant_speed, CMTOFEET * antdevs[0].ulDistance);
			console->printxy(0, 0, str);
#else
			printf("cadence = %3.0f, wheel rpm = %3.0f, speed = %4.1f mph, distance = %4.0f feet\n", antdevs[0].ant_cadence, antdevs[0].ant_wheel_rpm, METERSTOMILES * antdevs[0].ant_speed, CMTOFEET * antdevs[0].ulDistance);
#endif
			lastdisplaytime = now;
		}                          // if ((now-lastdisplaytime) >= 5000L)  {

	}                             // while(1)

	//libusb_hotplug_deregister_callback(ctx, hphandle);
	//hphandle = NULL;

	//if we detached kernel driver, reattach.

	if ( attached[0] == 1 ) {
		libusb_attach_kernel_driver( antdevs[0].handle, 0 );
	}

finis:

	if (usb_device_list) {
		libusb_free_device_list(usb_device_list, 1);
		usb_device_list = NULL;
	}

	if (config) {
		libusb_free_config_descriptor(config);
		config = NULL;
	}

	antdevs[0].stop();

	n = antdevs.size();
	antdevs.clear();

	if (ctx) {
		libusb_exit(ctx);
		ctx = NULL;
	}

	return 0;
}                                   // test_discovery_one_stick_one_channel()
#endif				// #if 0


#if 0

/**********************************************************************************************************
	http://thingylab.com/wiki/c_example_with_libusb-1.0

	the garmin stick is antdevs[0]
		channel 0 = speed/cadence

	the suunto stick is antdevs[1]
		channel 0 = heart rate

**********************************************************************************************************/

int ANT::pairing_test(void) {
	qint64 now;
	int i, n;
	qint64 lastdisplaytime = 0L;
	int lastn = 0;
	int spindex = 0;
	char spinner[4] = { '-', '\\', '|', '/' };
	bool runflag = true;


	Q_ASSERT(ctx);

	critsec = false;

	bp = 0;
	printf("\n\n");
	QDir dir;

	dir.remove("x.x");
	dir.remove("rx0.log");
	dir.remove("tx0.log");
	dir.remove("devs.txt");
	dir.remove("antdev.log");
	dir.remove("main.log");
	dir.remove("d.txt");
	dir.remove("raw.log");

//	scanning = true;
//	scanthread = new tthread::thread(&scanner, NULL);

	//menu();

	while (runflag) {

#if 0
		if (_kbhit()) {
			c = (char)_getch();
			if (c == 0) {
				c = _getch();
			}
			else  {
				switch (c) {

					case 0x1b: {
					flag = false;
					break;
				}

					case 'm':
					case 'M': {
					menu();
					break;
				}

					case 's':
					case 'S': {
					printf("\r ");
					n = find_ant_sticks();
					lastdisplaytime = 0L;               // forces a display update
					break;
				}

					case 'p':
					case 'P': {
					bp = 2;
					break;
				}

					case '1':  {                                    // pair speed-cadence sensor
					if (lastchar == 'p' || lastchar == 'P') {
						if (antdevs.size() > 0) {
							//assert(ix==-1);
							assert(chan == -1);
							status = pair_device_and_channel(SCDEVTYPE, ix, chan);

							if (status == 0) {
								bp = 2;
							}
							else if (status == 1)
							{
								printf("\n\nyou must Scan for ANT devices first\n\n");
							}
							else if (status == 2)
							{
								printf("\nno channels can be opened\n");
							}
							else if (status == 3)
							{
								printf("\nno devices / channels can be opened\n");
							}
							else  {
								printf("\nstatus = %d\n", status);
							}
						}                                   // if (lastchar == 'p')  {
						else {
							bp = 1;                          // no ant devices yet
						}
					}                                      // if (lastchar == 'p')  {
					break;
				}                                         // case '1':

					case '2':  {                           // pair heartrate sensor
					if (lastchar == 'p') {
						n = antdevs.size();
						if (n > 0) {
							bp = 2;
							status = pair_device_and_channel(HRDEVTYPE, ix, chan);

							if (status == 0) {
								bp = 2;
							}
							else if (status == 1)
							{
								printf("\n\nyou must Scan for ANT devices first\n\n");
							}
							else if (status == 2)
							{
								printf("\nno channels can be opened\n");
							}
							else if (status == 3)
							{
								printf("\nno devices / channels can be opened\n");
							}
							else  {
								printf("\nstatus = %d\n", status);
							}
						}                                      // if (n > 0)  {
						else {
							bp = 1;                             // no ant devices yet
						}
					}                                         // if (lastchar == 'p')  {
					break;
				}

					case '3':  {                                 // pair power sensor
					if (lastchar == 'p') {
						n = antdevs.size();
						if (n > 0) {
							bp = 2;
						}
					}
					break;
				}

					default: {
					bp = 3;
					break;
				}
				}

				if (flag == false) {
					break;
				}

				lastchar = c;
			}
		}        // if (_kbhit())
#endif         // #if 0



		now = QDateTime::currentMSecsSinceEpoch();

		if ((now - lastdisplaytime) >= 100L) {
			//printf("cadence = %3.0f, wheel rpm = %3.0f, speed = %4.1f mph, distance = %4.0f feet\n", antdevs[k].ant_cadence, antdevs[k].ant_wheel_rpm, METERSTOMILES*antdevs[k].ant_speed, CMTOFEET*antdevs[k].ulDistance);
			#ifdef WIN32
			//EnterCriticalSection(&critsec);
			critsec = true;
			#else
			critsec = true;
			#endif

			n = antdevs.size();
			if (n != lastn) {
				lastn = n;
				//menu();
			}                          // if (n != lastn)  {

			critsec = false;

			printf("\r%c", spinner[spindex]);
			spindex = (spindex + 1) % 4;

			lastdisplaytime = now;
		}                                // if ((now-lastdisplaytime) >= 5000L)  {

		QThread::msleep(100);
	}                                   // while(1)


//finis:
	/*
	scanning = false;
	if (scanthread) scanthread->join();
	DEL(scanthread);
	 */

#ifdef WIN32
	//DeleteCriticalSection(&critsec);
#endif

	n = antdevs.size();

	for (i = 0; i < n; i++) {
		if (antdevs[i].handle) {
			if ( libusb_kernel_driver_active(antdevs[i].handle, 0) ) {
				libusb_detach_kernel_driver(antdevs[i].handle, 0);
			}
		}
	}

	if (usb_device_list) {
		libusb_free_device_list(usb_device_list, 1);
		usb_device_list = NULL;
	}

	for (i = 0; i < n; i++) {
		antdevs[i].stop();
	}

	for (int i = 0; i < n; i++) {
		//antdevs.pop_back();
	}
	antdevs.clear();

	if (ctx) {
		libusb_exit(ctx);
		ctx = NULL;
	}

	n = antdevs.size();
	Q_ASSERT(n == 0);

	return 0;
}                                   // pairing_test()
#endif								// #if 0



#if 0

/**************************************************************************************************

**************************************************************************************************/

int ANT::get_channel(int _devtype, unsigned short _period, int &_ix, int &_chan) {
	int n, k, ii, status;
	bool done = false;
	libusb_device_descriptor desc;

	Q_UNUSED(desc);

	n = antdevs.size();

	if (n == 0) {
		return 1;
	}

	for (k = 0; k < n; k++) {
		//antdevs[k].start_logs(k);							// creates tx0.log and rx0.log
		ii = antdevs[k].get_ix();                 // 7th in the list of usb devices
		antdevs[k].set_device(usb_device_list[ii]);

		status = libusb_open(antdevs[k].get_device(), &antdevs[k].handle);   // Open a device and obtain a device handle
		switch (status) {
			case 0: {                                                         // on success
			break;
		}
			case LIBUSB_ERROR_NO_MEM: {      // on memory allocation failure
			bp = 1;
			break;
		}
			case LIBUSB_ERROR_ACCESS: {      // if the user has insufficient permissions
			bp = 1;
			break;
		}
			case LIBUSB_ERROR_NO_DEVICE: {   // if the device has been disconnected
			bp = 1;
			break;
		}
			default: {
			bp = 1;
			break;
		}
		}

		if (antdevs[k].handle == NULL) {
			logg("Unable to open usb device: %d\n", status);
			antdevs[k].set_device(0);
			continue;
		}

		#ifdef _DEBUG
		status = libusb_get_device_descriptor(antdevs[k].get_device(), &desc);
		if (status != 0) {
			antdevs[k].set_device(0);
			if (usb_device_list) {
				libusb_free_device_list(usb_device_list, 1);
				usb_device_list = NULL;
			}
			logg("libusb_get_device_descriptor = %d\n", status);
			//goto finis;
			continue;
		}

		status = libusb_get_string_descriptor_ascii(antdevs[k].handle, desc.iManufacturer, (unsigned char*)antdevs[k].mfgr, sizeof(antdevs[k].mfgr) - 1);
		status = libusb_get_string_descriptor_ascii(antdevs[k].handle, desc.iProduct, (unsigned char*)antdevs[k].prod, sizeof(antdevs[k].prod) - 1);
		status = libusb_get_string_descriptor_ascii(antdevs[k].handle, desc.iSerialNumber, (unsigned char*)antdevs[k].serial_number, sizeof(antdevs[k].serial_number));
		#endif

		if ( libusb_kernel_driver_active(antdevs[k].handle, 0) ) {
			libusb_detach_kernel_driver(antdevs[k].handle, 0);
		}

		status = libusb_claim_interface( antdevs[k].handle, 0 );             // memory leak
		if (status) {
			logg( "Failed to claim interface. " );

			//antdevs[k].init();

			switch (status) {
				case LIBUSB_ERROR_NOT_FOUND: {
				logg( "not found\n" );
				break;
			}
				case LIBUSB_ERROR_BUSY: {
				logg( "busy\n" );
				break;
			}
				case LIBUSB_ERROR_NO_DEVICE: {
				logg( "no device\n" );
				break;
			}
				default: {
				logg( "other\n" );
				break;
			}
			}

			continue;
		}                             // if (status)

		status = antdevs[k].start();  // start the device, creates rx, tx threads, calls ANTMsg::resetSystem() and ANTMsg::setNetworkKey(net, key)

		for (_chan = 0; _chan < 8; _chan++) {
			antdevs[k].set_devtype(_chan, _devtype);
			antdevs[k].set_period(_chan, _period);

			status = antdevs[k].pair_channel(_chan);                    // start channel
			if (status) {
				printf("start channel returned %d\n", status);
				printf("scerr = %s\n", antdevs[k].get_error_string());
				antdevs[k].stop();
				continue;
			}
			else  {
				done = true;
				_ix = k;
				break;
			}
		}                                         // for(chan=0; chan<8; chan++)  {

		if (done) {
			Q_ASSERT(_chan != 8);
			Q_ASSERT(k != n);
			break;
		}
	}                                            // for(k=0; k<n; k++)  {

	if (k == n) {
		return 2;                                 // no channels available
	}

	// the channel is still open and running

	// set pairing bits?


	return 0;
}                                   // int get_channel(int _devtype, unsigned short _period, int &_ix, int &_chan)  {
#endif

#if 0

/**************************************************************************************************

**************************************************************************************************/

int ANT::pair_device_and_channel(int _devtype, int &_stick_index, int &_chan) {
	int n, k, status;
	bool done = false;
	libusb_device_descriptor desc;

	Q_UNUSED(desc);

	Q_ASSERT(_stick_index == -1);
	Q_ASSERT(_chan == -1);

	n = antdevs.size();

	if (n == 0) {
		return 1;
	}

	/*
		The base unit wishes to establish a permanent relationship with all temperature sensors.
		To initiate the pairing operation, each temperature sensor should be placed into a pairing mode.
		From a user perspective, it is left to the application to define the method of entry into pairing mode.
		For example this could be done upon initial insertion of a battery, or by means of a button push by the user, etc.
		As far as the ANT serial message interface is concerned, the host controller invokes a pairing mode by sending the
		following messages to the ANT engine (See section 9.3 for details):

		1. Configure Channel
		2. Set Channel ID (discoverable  i.e. device type=temperature sensor with pairing bit set)
		3. Open TX Channel
		4. Begin transmitting data on channel timeslot

		At this time, the base unit (slave) must be prepared to search for the ID of the appropriate device type (temperature sensor).
		It performs the following:

		1. Configure Channel
		2. Set Channel ID (Transmission Type = Specific or Wild card, Device Type = Temperature sensor with Pairing Bit Set, Device Number = Wild Card)
		3. Open RX Channel
		4. Begin searching

		The base unit finds a temperature sensor device type with pairing bit set. The channel is established,
		the slave ANT engine will pass the specific channel ID for that device to the host controller,
		which will store the ID for future channel establishment. This procedure is repeated for all three temperature sensors.

		Each temperature sensor can choose to disable its discoverability after a time-out period (or after connection acknowledgement from
		the base unit if bidirectional transmission is supported) in order to be invisible to future discovery by other slave devices.
	 */


	for (k = 0; k < n; k++) {                               // for each ant stick
		//antdevs[k].start_logs(k);							// creates tx0.log and rx0.log
		//ii = antdevs[k].get_ix();								// 7th in the list of usb devices, eg
		//antdevs[k].set_device(glist[ii]);

		status = libusb_open(antdevs[k].get_device(), &antdevs[k].handle);   // Open a device and obtain a device handle
		switch (status) {
			case 0: {                                                         // on success
			break;
		}
			case LIBUSB_ERROR_NO_MEM: {      // on memory allocation failure
			bp = 1;
			break;
		}
			case LIBUSB_ERROR_ACCESS: {      // if the user has insufficient permissions
			bp = 1;
			break;
		}
			case LIBUSB_ERROR_NO_DEVICE: {   // if the device has been disconnected
			bp = 1;
			break;
		}
			default: {
			bp = 1;
			break;
		}
		}

		if (antdevs[k].handle == NULL) {
			logg("Unable to open usb device: %d\n", status);
			continue;
		}

		#ifdef _DEBUG
		status = libusb_get_device_descriptor(antdevs[k].get_device(), &desc);
		if (status != 0) {
			if (usb_device_list) {
				libusb_free_device_list(usb_device_list, 1);
				usb_device_list = NULL;
			}
			logg("libusb_get_device_descriptor = %d\n", status);
			//goto finis;
			continue;
		}

		status = libusb_get_string_descriptor_ascii(antdevs[k].handle, desc.iManufacturer, (unsigned char*)antdevs[k].mfgr, sizeof(antdevs[k].mfgr) - 1);
		status = libusb_get_string_descriptor_ascii(antdevs[k].handle, desc.iProduct, (unsigned char*)antdevs[k].prod, sizeof(antdevs[k].prod) - 1);
		status = libusb_get_string_descriptor_ascii(antdevs[k].handle, desc.iSerialNumber, (unsigned char*)antdevs[k].serial_number, sizeof(antdevs[k].serial_number));
		#endif

		if ( libusb_kernel_driver_active(antdevs[k].handle, 0) ) {
			libusb_detach_kernel_driver(antdevs[k].handle, 0);
		}

		status = libusb_claim_interface( antdevs[k].handle, 0 );             // memory leak
		if (status) {
			logg( "Failed to claim interface. " );

			switch (status) {
				case LIBUSB_ERROR_NOT_FOUND: {
				logg( "not found\n" );
				break;
			}
				case LIBUSB_ERROR_BUSY: {
				logg( "busy\n" );
				break;
			}
				case LIBUSB_ERROR_NO_DEVICE: {
				logg( "no device\n" );
				break;
			}
				default: {
				logg( "other\n" );
				break;
			}
			}

			continue;
		}                             // if (status)

		// here we'll do synchronous communication

		status = antdevs[k].start();     // start the device, creates rx, tx threads, calls ANTMsg::resetSystem() and ANTMsg::setNetworkKey(net, key)

		// the device is open and started. Now find the first available channel

		for (_chan = 0; _chan < 8; _chan++) {
			antdevs[k].set_devtype(_chan, _devtype);
			//antdevs[k].set_period(_chan, _period);

			//status = antdevs[k].start_channel(_chan);
			status = antdevs[k].pair_channel(_chan);
			if (status) {
				printf("start channel returned %d\n", status);
				printf("scerr = %s\n", antdevs[k].get_error_string());
				//xxx
				antdevs[k].set_devtype(_chan, 0);
				antdevs[k].set_period(_chan, 0x0000);
				continue;
			}
			else  {
				_stick_index = k;
				done = true;
				break;
			}
		}                                         // for(chan=0; chan<8; chan++)  {

		if (_chan == 8) {
			bp = 1;
		}

		if (done) {
			Q_ASSERT(_chan != 8);
			Q_ASSERT(k != n);
			Q_ASSERT(antdevs[k].get_channels()[_chan].get_devtype() != 0);
			Q_ASSERT(antdevs[k].get_channels()[_chan].get_period() != 0);
			break;
		}
	}                                            // for(k=0; k<n; k++)  {

	if (k == n) {
		for (k = 0; k < n; k++) {
			antdevs[k].stop();
		}
		return 2;                                 // no channels available on any device
	}

	// the channel is still open and running

	// set pairing bits?


	return 0;
}                                   // int pair_device_and_channel(int _devtype, int &_ix, int &_chan)
#endif

#if 0

/**********************************************************************************************************

**********************************************************************************************************/

int ANT::post2(void) {
	int i, n;
	bool runflag = true;

	bp = 0;
	//printf("\n\n");
	QDir dir;

	dir.remove("x.x");
	dir.remove("rx0.log");
	dir.remove("tx0.log");
	dir.remove("devs.txt");
	dir.remove("antdev.log");
	dir.remove("main.log");
	dir.remove("d.txt");
	dir.remove("raw.log");

	//unsigned short scperiod = 8086;							// must be 8086 or you get a lot of timeouts, although it tries to work
	//int scdevtype = 121;							// has to be 121


	while (runflag) {
		//printf("\n");

		//n = find_ant_sticks();								// allocates list, creates antdevs[0], creates antdev.log (logstream)
		//////////////////////////////////////////////////////////////////

		//int rc = -1;
		int i, j, jj, k, cnt, n, status;
		libusb_config_descriptor *config = NULL;
		bool isant;
		const libusb_interface *inter;
		const libusb_interface_descriptor *interdesc;
		const libusb_endpoint_descriptor *epdesc;
		bool dolog = false;

		n = antdevs.size();

		for (int i = 0; i < n; i++) {
			if (antdevs[i].handle) {
				if ( libusb_kernel_driver_active(antdevs[i].handle, 0) ) {
					libusb_detach_kernel_driver(antdevs[i].handle, 0);
				}
			}
			antdevs[i].stop();
			//antdevs.pop_back();
		}
		antdevs.clear();

		if (usb_device_list) {
			libusb_free_device_list(usb_device_list, 1);
			usb_device_list = NULL;
		}

		//printf("fas1\n");

		cnt = libusb_get_device_list(ctx, &usb_device_list);         // memory leak

		//printf("fas2, cnt = %d\n", cnt);

		if (cnt <= 0) {
			if (usb_device_list) {
				libusb_free_device_list(usb_device_list, 1);
				usb_device_list = NULL;
			}
			if (dolog) {
				logg( "no usb devices found\n" );
			}
			goto finis;
		}


		for (k = 0; k < cnt; k++) {
			libusb_device_descriptor desc;
			libusb_device *device;

			device = usb_device_list[k];

			status = libusb_get_device_descriptor(device, &desc);
			if (status != 0) {
				if (usb_device_list) {
					libusb_free_device_list(usb_device_list, 1);
					usb_device_list = NULL;
				}
				if (dolog) {
					logg("libusb_get_device_descriptor = %d\n", status);
				}
				goto finis;
			}

			if (dolog) {
				logg("\n%2d Device:    vendor = %04x    product = %04x\n", k + 1, desc.idVendor, desc.idProduct);
			}

			config = NULL;
			status = libusb_get_config_descriptor(device, 0, &config);

			if (status != 0) {
				if (dolog) {
					logg("   libusb_get_config_descriptor error: %d\n", status);
				}
				if (status == LIBUSB_ERROR_NOT_FOUND) {
					bp = 1;
				}
				else  {
					bp = 2;
				}
				if (config) {
					libusb_free_config_descriptor(config);
					config = NULL;
				}
				continue;
				//goto finis;
			}

			if (config->bNumInterfaces == 0) {
				if (dolog) {
					logg("   no interfaces!\n");
				}
				libusb_free_config_descriptor(config);
				config = NULL;
				continue;
			}

			isant = false;

			//printf("vendor = %x, product = %x\n", desc.idVendor, desc.idProduct);

			if (desc.idVendor == GARMIN_USB2_VID && (desc.idProduct == GARMIN_USB2_PID || desc.idProduct == GARMIN_OEM_PID)) {
				isant = true;
			}

			if (isant) {
				int jjj;
				nants++;
				//antdevs.push_back(ANTDEV());
				jjj = antdevs.size() - 1;

				libusb_device_handle *handle = NULL;

				status = libusb_open(device, &handle);    // Open a device and obtain a device handle

				switch (status) {
					case 0: {                     // on success
					break;
				}
					case LIBUSB_ERROR_NO_MEM: {   // on memory allocation failure
					bp = 1;
					goto finis;
					break;
				}
					case LIBUSB_ERROR_ACCESS: {   // if the user has insufficient permissions
					bp = 1;
					goto finis;
					continue;
					//break;
				}
					case LIBUSB_ERROR_NO_DEVICE: { // if the device has been disconnected
					bp = 1;
					goto finis;
					break;
				}
					default: {
					bp = 1;
					goto finis;
					break;
				}
				}

				antdevs[jjj].set_vid(desc.idVendor);
				antdevs[jjj].set_pid(desc.idProduct);
				antdevs[jjj].set_bus_number(libusb_get_bus_number(device));
				antdevs[jjj].set_device_address(libusb_get_device_address(device));
				antdevs[jjj].set_ix(k);
//printf("fas6\n");

				char str[256];
				status = libusb_get_string_descriptor_ascii(handle, desc.iManufacturer, (unsigned char*)str, sizeof(str) - 1);
//printf("fas6b, status = %d\n", status);

				if (status < 0) {
					if (status == LIBUSB_ERROR_NOT_FOUND) {
//printf("fas6c\n");
						libusb_close(handle);
						handle = NULL;
						if (config) {
							libusb_free_config_descriptor(config);
							config = NULL;
						}
						continue;
						//goto finis;
					}
					else  {
//printf("fas6d\n");
						libusb_close(handle);
						handle = NULL;
						if (config) {
							libusb_free_config_descriptor(config);
							config = NULL;
						}
						continue;
					}
				}

				antdevs[jjj].set_mfgr(str);

				status = libusb_get_string_descriptor_ascii(handle, desc.iProduct, (unsigned char*)str, sizeof(str) - 1);
				antdevs[jjj].set_product(str);

				status = libusb_get_string_descriptor_ascii(handle, desc.iSerialNumber, (unsigned char*)str, sizeof(str));
				antdevs[jjj].set_sn(str);                             // garmin = "097", suunto = "1213804102"

				antdevs[jjj].set_nconfigs(desc.bNumConfigurations);

				bp = 17;
//printf("fas7\n");

				for (i = 0; i < config->bNumInterfaces; i++) {
					inter = &config->interface[i];
					INTF intf;

					if (dolog) {
						logg("      Interface Number: %d  /  %s  /  %s  /  %s\n", i + 1, antdevs[jjj].get_mfgr(), antdevs[jjj].get_product(), antdevs[jjj].get_sn());
					}

					for (j = 0; j < inter->num_altsetting; j++) {
						interdesc = &inter->altsetting[j];
						if (dolog) {
							logg("         alt setting number: %d\n", (int)interdesc->bInterfaceNumber);
						}
						std::vector<ALTSETTING> alts;
						ALTSETTING alt;

						for (jj = 0; jj < (int)interdesc->bNumEndpoints; jj++) {
							epdesc = &interdesc->endpoint[jj];
							if (dolog) {
								logg("            endpoint %d, Descriptor Type: %d, EP Address: %d\n",
									  jj + 1,
									  epdesc->bDescriptorType,
									  epdesc->bEndpointAddress
									  );
							}
							ENDPOINT ep;
							ep.set_type(epdesc->bDescriptorType);
							ep.set_addr(epdesc->bEndpointAddress);
							alt.add_ep(ep);
							alts.push_back(alt);
						}              // endpoints
						//intf.alts = alts;
						intf.set_alt(alts);
					}                 // alt_settings
					//ad.ifs.push_back(intf);
					antdevs[jjj].add_intf(intf);
					intf.clear();
				}                    // interfaces

				libusb_close(handle);
				handle = NULL;

				//antdevs.push_back(ad);
				//goto stop;
			}                             // if (isant)
			else {
				for (i = 0; i < config->bNumInterfaces; i++) {
					inter = &config->interface[i];
					if (dolog) {
						logg("      Interface Number: %d\n", i + 1);
					}

					for (j = 0; j < inter->num_altsetting; j++) {
						interdesc = &inter->altsetting[j];
						if (dolog) {
							logg("         alt setting number: %d\n", (int)interdesc->bInterfaceNumber);
						}

						for (jj = 0; jj < (int)interdesc->bNumEndpoints; jj++) {
							epdesc = &interdesc->endpoint[jj];
							if (dolog) {
								logg("            endpoint %d, Descriptor Type: %d, EP Address: %d\n", jj + 1, epdesc->bDescriptorType, epdesc->bEndpointAddress);
							}
						}              // endpoints
					}                 // alt_settings
				}                    // interfaces
			}


			if (config) {
				libusb_free_config_descriptor(config);
				config = NULL;
			}

		}                          // devices, for(k)

		n = antdevs.size();
		//rc = n;


		///////////////////////////////////////////////////////////////////

		if (n <= 0) {
			printf("no devices\n\n");
		}
		else  {
			for (i = 0; i < n; i++) {
				printf("%s %s\n", antdevs[i].get_mfgr(), antdevs[i].get_product());
			}
		}

		QThread::msleep(5000);

	}                             // while(1)


finis:

	n = antdevs.size();

	for (i = 0; i < n; i++) {
		if (antdevs[i].handle) {
			if ( libusb_kernel_driver_active(antdevs[i].handle, 0) ) {
				libusb_detach_kernel_driver(antdevs[i].handle, 0);
			}
		}
	}

	if (usb_device_list) {
		libusb_free_device_list(usb_device_list, 1);
		usb_device_list = NULL;
	}

	for (i = 0; i < n; i++) {
		antdevs[i].stop();
	}

	for (int i = 0; i < n; i++) {
		//antdevs.pop_back();
	}
	antdevs.clear();

	if (ctx) {
		libusb_exit(ctx);
		ctx = NULL;
	}

	n = antdevs.size();
	Q_ASSERT(n == 0);

	return 0;
}
#endif			// #if 0





//#if TEST_MODE==2
#if 0

/***********************************************************************
	 10ms after the application starts this method will run
	 all QT messaging is running at this point so threads, signals and slots will all work as expected.
***********************************************************************/

void ANT::run() {

	/*
		int status;
		Q_UNUSED(status);

		//--------------------------------------------------------------

		params.clear();
		params.append("sta_setting_encry=AES");
		params.append("sta_setting_auth=WPA2PSK");
		params.append("sta_setting_ssid=" + ssid);
		params.append("sta_setting_auth_sel=WPA2PSK");
		params.append("sta_setting_encry_sel=AES");
		params.append("sta_setting_type_sel=ASCII");
		params.append("sta_setting_wpakey=" + pass);
		params.append("wan_setting_dhcp=DHCP");


		urlstr = "http://10.10.100.254/do_cmd_en.html";
		referer = "http://10.10.100.254/wireless_en.html";

		state = SSID_COMMAND;
	 */

	//maintmr->start();

	//status = command();

}        // run()



/***********************************************************************
	 call this routine to quit the application
***********************************************************************/

void ANT::quit() {

	//QMessageBox::about((QWidget *)parent, "My Title", "Quitting");			// doesn't work
	emit finished();                    // signal CoreApplication to quit
}


/***********************************************************************
	 shortly after quit is called the CoreApplication will signal this routine
	 this is a good place to delete any objects that were created in the
	 constructor and/or to stop any threads
***********************************************************************/

void ANT::aboutToQuitApp() {
	// stop threads

	if (dbg) {
		//printf("about to quit\n");
	}

	if (timer) {
		timer->stop();
	}

	QThread::msleep(shutdown_delay);              // wait for threads to stop

	// delete any objects

	DEL(timer);

#ifdef _DEBUG
	DEL(at);
#endif

	//maintmr->stop();
	//DEL(maintmr);											// 580, 546, 542, 767, 497

	FCLOSE(stream);

	char str[64];

	if (dbg) {
		printf("\n");
	}

	/*
		switch(rc)  {
		case 0:
			strcpy(str, "OK");
			break;
		case 1:
			strcpy(str, "error 1");
			break;
		case 2:
			strcpy(str, "error 2");
			break;
		case 3:
			sprintf(str, "reply error, state = %d, err = %d", state, err);
			break;
		case 4:
			strcpy(str, "timed out");
			break;
		default:
			strcpy(str, "unknown error");
			break;
		}
	 */

#ifdef _DEBUG
	//qDebug("%s", str);
	//qDebug() << str;
	printf("%s\n", str);
#else
	printf("%s\n", str);
#endif
}                             // abouttoquit()

/**************************************************************************

**************************************************************************/

void ANT::timeout_slot() {
#ifdef _DEBUG
	at->update();                          // 10 ms
#endif

	if (done) {
		quit();
	}

	return;
}                       // timeout()


#endif                        // #if TEST_MODE==2


/**********************************************************************************************************
	scans for ant sticks and ant sensors
	takes about 6 ms
**********************************************************************************************************/

int ANT::scan(void) {

#ifdef _DEBUG
	static int calls = 0;
	calls++;
#endif

	critsec = true;

#ifdef _DEBUG
			if (calls==1)  {
				tmr->start();
			}
			else if (calls==2)  {
				bp = 3;
			}
#endif


	int rc = 0;
	int status = 0;
	ssize_t cnt;
	libusb_device *device;
	libusb_config_descriptor *config = NULL;
	int k;
	bool is_ant_stick;
	libusb_device_handle *handle = NULL;
	int i, key;
	char str[256];
	char sn[64];

	if (ctx == NULL) {
		rc = RMANT_ERROR_NO_CTX;
		goto finis;
	}




	cnt = libusb_get_device_list(ctx, &usb_device_list);         // 16 with 2 ant sticks, 15 with 1 ant stick

	if (cnt <= 0) {
		rc = RMANT_ERROR_NO_USB_DEVICES;
		goto finis;
	}

//	foreach(int key, antdevs.keys() )  {
//		for(k=0; k<cnt; k++)  {
//			device = usb_device_list[k];
//			libusb_device_descriptor desc;
//			status = libusb_get_device_descriptor(device, &desc);			// desc.idVendor, desc.idProduct
//			if (status != 0) {
//				rc = RMANT_ERROR_GET_DEVICE_DESCRIPTOR;
//				goto finis;
//			}
//			//if (antdevs.value(key)->g

//		}
//	}

	for (k = 0; k < cnt; k++) {
		libusb_device_descriptor desc;
		device = usb_device_list[k];

		status = libusb_get_device_descriptor(device, &desc);			// desc.idVendor, desc.idProduct
		if (status != 0) {
			rc = RMANT_ERROR_GET_DEVICE_DESCRIPTOR;
			goto finis;
		}

//		bool flag = false;
//		foreach(int key, antdevs.keys() )  {
//			//int key2;
//			//key2 = antdevs.value(key)->
//			//if (antdevs.value(key)->g
//			int key2;
//			key2 = desc.idProduct + desc.idVendor;
//			status = libusb_get_string_descriptor_ascii(handle, desc.iSerialNumber, (unsigned char*)sn, sizeof(sn));

//			for(int j=0; j<(int)strlen(sn); j++)  {
//				key2 += sn[j];
//			}

//			if (key==key2)  {
//				//continue;
//				flag = true;
//			}

//		}
//		if (flag)  {
//			continue;
//		}




		config = NULL;

		status = libusb_get_config_descriptor(device, 0, &config);

		if (status != 0) {
			if (config) {
				libusb_free_config_descriptor(config);
				config = NULL;
			}
			continue;
		}

		if (config->bNumInterfaces == 0) {
			libusb_free_config_descriptor(config);
			config = NULL;
			continue;
		}
		libusb_free_config_descriptor(config);
		config = NULL;




		is_ant_stick = false;

		/*
			#define GARMIN_USB2_VID   0x0fcf		4047
			#define GARMIN_USB2_PID   0x1008		4104

			#define GARMIN_OEM_PID    0x1009		4105
		 */

		//qDebug() << GARMIN_USB2_VID;
		//qDebug() << GARMIN_USB2_PID;
		//qDebug() << GARMIN_OEM_PID;

		if (desc.idVendor == GARMIN_USB2_VID) {
			if (desc.idProduct == GARMIN_USB2_PID) {
				is_ant_stick = true;                                   // true for suunto and garmin
			}
			else if (desc.idProduct == GARMIN_OEM_PID)
			{
				// never gets here
				is_ant_stick = true;
			}
		}

		if (is_ant_stick) {
			//stick.reset();
			//antdev.reset();
#ifdef _DEBUG
			if (calls==2)  {
				if (k==4)  {
					bp = 2;
				}
			}
#endif

			status = libusb_open(device, &handle);    // Open a device and obtain a device handle

			switch (status) {
				case 0: {                     // on success
					break;
				}
				case LIBUSB_ERROR_NO_MEM:     // -11	on memory allocation failure
				case LIBUSB_ERROR_ACCESS:     // -3		if the user has insufficient permissions
				case LIBUSB_ERROR_NO_DEVICE:  // -4		if the device has been disconnected
					rc = status;
					goto finis;
				default:
					rc = status;
					goto finis;
			}

//			if (config) {
//				libusb_free_config_descriptor(config);
//				config = NULL;
//			}

			key = desc.idProduct + desc.idVendor;
			status = libusb_get_string_descriptor_ascii(handle, desc.iSerialNumber, (unsigned char*)sn, sizeof(sn));

			for(i=0; i<(int)strlen(sn); i++)  {
				key += sn[i];
			}

#ifdef _DEBUG
			if (calls==2)  {
				bp = 2;
			}
#endif

			if (!antdevs.contains(key))  {
#ifdef _DEBUG
				if (calls>1)  {
					bp = 2;
				}
#endif

				antdevs[key] = new ANTDEV(this);
				status = antdevs[key]->set_device(device);


				/*
				antdevs[key]->set_handle(handle);
				antdevs[key]->set_device(device);

				antdevs[key]->set_pid(desc.idProduct);
				antdevs[key]->set_vid(desc.idVendor);
				antdevs[key]->set_nconfigs(desc.bNumConfigurations);

				status = libusb_get_string_descriptor_ascii(handle, desc.iManufacturer, (unsigned char*)str, sizeof(str) - 1);
				antdevs[key]->set_mfgr(str);
				status = libusb_get_string_descriptor_ascii(handle, desc.iProduct, (unsigned char*)str, sizeof(str) - 1);
				antdevs[key]->set_product(str);
				status = libusb_get_string_descriptor_ascii(handle, desc.iSerialNumber, (unsigned char*)sn, sizeof(sn));
				antdevs[key]->set_sn(sn);
				*/

				antdevs[key]->start();


				bp = 3;
			}
			else  {
				libusb_close(handle);
				handle = NULL;
			}

		}                    // if (isant)

//		if (config) {
//			libusb_free_config_descriptor(config);
//			config = NULL;
//		}
	}                          // devices, for(k)

	if (usb_device_list) {
		libusb_free_device_list(usb_device_list, 1);
		usb_device_list = NULL;
	}

finis:

//	if (config) {
//		libusb_free_config_descriptor(config);
//		config = NULL;
//	}

	if (handle) {
		libusb_close(handle);
		handle = NULL;
	}

	if (usb_device_list) {
		libusb_free_device_list(usb_device_list, 1);
		usb_device_list = NULL;
	}

	logg("\nfound %d ANT sticks that use the libusb driver in %d USB devices\n", antdevs.size(), cnt);

#ifdef _DEBUG
			if (calls==1)  {
				tmr->stop();
				double dt = tmr->get_seconds();					// 9 ms
				Q_UNUSED(dt);
			}
#endif

#ifdef _DEBUG
	if (rc != 0)  {
		bp = 7;
	}
#endif

	critsec = false;
	return rc;

}                          // scan()


