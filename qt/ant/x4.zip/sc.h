#ifndef _QTSC_H_
#define _QTSC_H_

#include <QtCore>

//#include "ant.h"

/********************************************************************************************

********************************************************************************************/

//class SC : public ANT {
class SC  {
private:
	enum BSCState {
		BSC_INIT = 0,
		BSC_ACTIVE = 1,
	};

public:
	SC(void);
	~SC();
	int decode(void);
	int reset(void);
	void set_circum(quint8 _cm);
	float inline get_wheel_rpm(void) { return wheel_rpm; }
	float inline get_speed(void) { return speed; }						// Instantaneous speed (meters/h)
	float inline get_cadence(void) { return cadence; }
	void inline set_cadence(float _f) { cadence = _f; }

private:
	float cadence;
	quint16 event_diff;
	quint16 time_diff;

	quint8 circumference_cm;						// wheel circumference (cm)
	float wheel_rpm;
	float speed;

	quint16 speed_event_count;					// Bike speed event count (wheel revolutions)
	quint16 speed_previous_event_count;		// Bike speed previous event count
	quint16 speed_time;							// Time of last bike speed event (1/1024s)
	quint16 speed_previous_time;				// Time of previous bike speed event (1/1024s)

	quint32 speed_acum_event_count;				// Cumulative bike speed event count (wheel revolutions)
	quint32 speed_acum_time;						// Cumulative time (1/1024 seconds)

	quint16 cad_event_count;						// Bike cadence event count (pedal revolutions)
	quint16 cad_previous_event_count;			// Bike cadence previous event count
	quint16 cad_time;								// Time of last bike cadence event (1/1024s)
	quint16 cad_previous_time;					// Time of previous bike cadence event (1/1024s)

	quint32 cad_acum_event_count;				// Cumulative bike cadence event count (pedal revolutions)
	quint32 cad_acum_time;							// Cumulative time (1/1024 seconds)
	quint32 cad_distance;								// Cumulative distance (cm)

	BSCState cad_state;								// state for speed cadence sensor
	bool cad_coasting;									// coasting flag
	bool cad_stopping;
	quint8 ucNoSpdEventCount;					// counter for successive transmissions with no new speed events
	quint8 ucNoCadEventCount;					// counter for successive transmissions with no new cadence events
};														// class SC


#endif



