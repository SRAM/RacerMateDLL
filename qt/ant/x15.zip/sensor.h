
#ifndef _SENSOR_H_
#define _SENSOR_H_

#include <QtCore>

/****************************************************************************

****************************************************************************/

class SENSOR  {
	friend class ANT;
	friend class ANTDEV;

	public:
			SENSOR(void);
			~SENSOR();
			int sn = -1;							// copy of the key for easier iteration
			int assigned_channel = -1;
			int hr=0;								// valid if type is is HR_DEV_TYPE

	private:
		unsigned char type = 0x00;
		unsigned char transtype = 0x00;
		qint64 lastcommtime=-1;
		static QMap<int, QString> types;

};

#endif


