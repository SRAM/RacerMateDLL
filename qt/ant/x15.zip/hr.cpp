
#include "hr.h"

/**************************************************************************************

**************************************************************************************/

HR::HR(void) {
	reset();
}

/**************************************************************************************

**************************************************************************************/

HR::~HR()  {
#ifdef _DEBUG
	bp = 2;
#endif
}

/**************************************************************************************

**************************************************************************************/

//HR::reset(void) {
//	reset();
//}

/**************************************************************************************
	ant_packet contains the payload
**************************************************************************************/

//int PAGE_SENSOR::decode()  {
int HR::decode()  {
	if (!initialized)  {
		return 0;
	}

	decoding_data = true;

	quint8 l_page_num = 0;
	quint8 l_ucEventDiff = 0;
	quint16 l_usTimeDiff1024 = 0;

	/*
	UCHAR ucPageNum = 0;
	UCHAR ucEventDiff = 0;
	USHORT usTimeDiff1024 = 0;
	*/

	//decode_time = timeGetTime();
	decode_time = QDateTime::currentMSecsSinceEpoch();

	//does_exist = true;

#ifdef _DEBUG
	hrcalls++;

	bool have_ant_packet;
	if (ant_packet[6] != 0xcc && ant_packet[7] != 0xcc)  {				// wait for valid ant_packet
		//hr = ant_packet[7];
		have_ant_packet = true;
	}
	else  {
		have_ant_packet = false;
	}
#endif

	// heartrate
	// monitor page toggle bit

	if(page != EXT_PAGE)  {
		if(page == INIT_PAGE)  { 
			page = (ant_packet[0] & TOGGLE_MASK) >>7;
			// initialize previous values to correctly get the cumulative values
			previous_event_count = ant_packet[6];
			previous_time_1024 = ant_packet[4];
			previous_time_1024 += ant_packet[5]<<8;
		}
		else if(page != ((ant_packet[0] & TOGGLE_MASK) >>7))  { 
			// first page toggle was seen, enable advanced data
			page = EXT_PAGE;
		}
	}
	
	// remove page toggle bit

	l_page_num = ant_packet[0] & ~TOGGLE_MASK;

	// Handle basic data
	// heartrate

	event_count = ant_packet[6];
	time_1024 = ant_packet[4];
	time_1024 += ant_packet[5]<<8;
	//if (hrcalls>15)  {
	//if (ant_packet[6] != 0xcc && ant_packet[7] != 0xcc)  {				// wait for valid ant_packet
#ifdef _DEBUG
	if (have_ant_packet)  {
		val = ant_packet[7];
	}

//	if (hr > 10)  {
//		ant_bp = 2;
//	}
#else
	val = ant_packet[7];
#endif

	accum += val;
	accum_count++;

	// heartrate
	// handle background data, if supported

	if(page == EXT_PAGE)  {
		switch(l_page_num)  {
			case PAGE1:
				elapsed_time2 = ant_packet[1];
				elapsed_time2 += ant_packet[2] << 8;
				elapsed_time2 += ant_packet[3] << 16;
				break;
			case PAGE2:
				mfgr_id = ant_packet[1];
				sernum = ant_packet[2];
				sernum += ant_packet[3] << 8;		// serial number = 3?
				break;
			case PAGE3:
				hw_version = ant_packet[1];			// 4
				sw_version = ant_packet[2];			// 20
				model = ant_packet[3];					// 7
				break;
			case PAGE4:
				previous_time_1024 = ant_packet[2];
				previous_time_1024 += ant_packet[3] << 8;
				break;
			default:
#ifdef _DEBUG
				bp = 0;
#endif
				break;
		}
	}

	// heartrate


	// only need to do calculations if dealing with a new event

	if(event_count != previous_event_count)  {
		no_event_count = 0;

		// update cumulative event count

		if(event_count > previous_event_count)  {
			l_ucEventDiff = event_count - previous_event_count;
		}
		else  {
			l_ucEventDiff = (quint8) 0xFF - previous_event_count + event_count + 1;
		}

		acum_event_count += l_ucEventDiff;

		// update cumulative time

		if(time_1024 > previous_time_1024)  {
			l_usTimeDiff1024 = time_1024 - previous_time_1024;
		}
		else  {
			l_usTimeDiff1024 = (quint16) (0xFFFF - previous_time_1024 + time_1024 + 1);
		}

		// heartrate
		ulAcumTime1024 += l_usTimeDiff1024;


		// calculate R-R Interval

		if(l_ucEventDiff == 1)  {
			rr_interval_1024 = l_usTimeDiff1024;
		}

		// calculate heart rate (from timing data), in ant_bpm

		if(l_usTimeDiff1024 > 0)  {
			calculated_val = (quint8) ( ((quint16) l_ucEventDiff * 0xF000) / l_usTimeDiff1024 );	// 1 min = 0xF000 = 60 * 1024

#ifdef _DEBUG
			if (val > 30 && val < 100)  {
				bp = 2;
			}
#endif

		}
	}
	// heartrate
	else  {
		no_event_count++;
		if(no_event_count >= MAX_NO_EVENTS)  {
			val = calculated_val = INVALID_PAGE;	// No new valid HR data has been received
		}
	}

	if (calculated_val != INVALID_PAGE)  {
		int diff = (int)abs(calculated_val - val);
		if (diff > 5)  {
			// maybe average hr with the calculated hr? What to do?
			// observed calculated_hr's after things were up and running:
			// 26, 27, 28
			// so you'd need a median filter if you use that.
		}
	}

	// update previous time and event count

	if(l_page_num != PAGE4)  {
		previous_time_1024 = time_1024;  // only if not previously obtained from HRM message
	}

	previous_event_count = event_count;
	// heartrate

#ifdef _DEBUG
	if (val > 10)  {
		bp = 2;
	}
#endif

	return 0;
}						// int HR::decode()


