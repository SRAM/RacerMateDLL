#ifndef _CAD_H_
#define _CAD_H_

#include "page_sensor.h"

/********************************************************************************************

********************************************************************************************/

class CAD : public PAGE_SENSOR {
public:
	CAD(void);
	~CAD();
	//int reset(void);
	//int decode(void);												// decoder used by heart rate and cadence-only
	//float get_val(void);						//  { return (float)val; }
	//unsigned char val;											// cadence
																		//unsigned char calculated_val;

private:
	//int init(void);
	//quint16 previous_event_count;
};

#endif



