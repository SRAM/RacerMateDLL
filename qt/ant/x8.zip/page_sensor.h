
#ifndef PAGE_SENSOR_H
#define PAGE_SENSOR_H

#include <QtCore>

#include "antdev.h"

/*
extern SC sc;
extern CAD cad;
extern HR hr;

// variables:

extern bool asi;
extern bool sensors_initialized;
extern bool ant_closed;
extern bool do_ant_logging;
extern bool log_raw;

// functions:
//extern int ant_init(void(*_ant_keyfunc)(void) = NULL);
extern int ant_start_sc(void);
extern int ant_start_cad(void);
extern int ant_start_heartrate(void);
extern void ant_set_circumference(float _mm);		//  { circumference_cm = ROUND(_mm/10.0f); }
extern int ant_close(void);
*/

//#include "ant.h"

/********************************************************************************************

********************************************************************************************/


//class PAGE_SENSOR : public ANT {
class PAGE_SENSOR  {

public:
	//float get_val(void);						//  { return (float)val; }
	void reset_accum(void) { accum = 0.0f; accum_count = 0L;	/* val = 0; */ }

	//unsigned char val;										// heartrate or cadence
	//unsigned char calculated_val;
protected:
	float accum;
	unsigned long accum_count;
	quint8 chan_type;				// CHANNEL_TYPE_SLAVE, Channel type as chosen by user (master or slave), 0 = slave?
	quint8 dev_type;				// 151
	quint8 freq;						// 57
	quint16 period;					// 8086
	quint8 chan_num;				// 0
	quint8 trans_type;				// 0
	char name[24];
	bool decoding_data;

	/*
	DWORD last_open_attempt_time;
	DWORD last_status_request_time;
	DWORD last_data_time;
	DWORD channel_open_time;
	bool initialized;
	DWORD lastnow;
	quint8 dev_type;				// 151
	quint8 freq;						// 57
	quint8 chan_type;				// CHANNEL_TYPE_SLAVE, Channel type as chosen by user (master or slave), 0 = slave?

	quint8 page;
	quint8 previous_event_count;
	quint16 previous_time_1024;
	quint16 time_1024;
	quint8 event_count;
	quint32 elapsed_time2;			// Cumulative operating time (elapsed time since battery insertion) in 2 second resolution
	quint8 mfgr_id;					// Manufacturing ID
	quint16 sernum;					// Serial number
	quint8 hw_version;				// Hardware version
	quint8 sw_version;				// Software version
	quint8 model;				   // Model number
	quint8 no_event_count;		// Successive transmissions with no new cadence events
	quint32 acum_event_count;		// Cumulative heart beat event count
	quint16 rr_interval_1024;	// R-R interval (1/1024 seconds), conversion to ms is performed for data display
	quint8 channel_status;

	bool inline tracking(void)  { return channel_status==STATUS_TRACKING_CHANNEL; }

	*/

private:
	int init(void);

protected:
#define PAGE0				((quint8) 0)
#define PAGE1				((quint8) 1)
#define PAGE2				((quint8) 2)
#define PAGE3				((quint8) 3)
#define PAGE4				((quint8) 4)
#define INVALID_PAGE		((quint8) 0)
#define TOGGLE_MASK		((quint8) 0x80)

	enum statePage {
		STD0_PAGE = 0,
		STD1_PAGE = 1,
		INIT_PAGE = 2,
		EXT_PAGE = 3
	};

	PAGE_SENSOR(void);
	~PAGE_SENSOR() {}
	int reset(void);

#ifdef _DEBUG
	int bp;
#endif

	unsigned char ant_packet[8];
	//quint8 MAX_NO_EVENTS;						// Maximum number of messages with no new events (3s)

	quint32 decode_time;
	quint16 previous_event_count;
	quint16 rr_interval_1024;			// R-R interval (1/1024 seconds), conversion to ms is performed for data display

	quint32 ulAcumTime1024;				// Cumulative time (1/1024 seconds), conversion to s is performed for data display
	quint8 page;
	//quint8 previous_event_count;
	quint16 previous_time_1024;
	quint16 time_1024;
	quint8 event_count;
	quint32 elapsed_time2;					// Cumulative operating time (elapsed time since battery insertion) in 2 second resolution
	quint8 mfgr_id;							// Manufacturing ID
	quint16 sernum;							// Serial number
	quint8 hw_version;						// Hardware version
	quint8 sw_version;						// Software version
	quint8 model;							// Model number
	quint8 no_event_count;				// Successive transmissions with no new cadence events
	quint32 acum_event_count;				// Cumulative heart beat event count

};													// class PAGE_SENSOR

#endif


