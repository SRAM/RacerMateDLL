#ifndef _ANTCHAN_H_
#define _ANTCHAN_H_

/****************************************************************************

****************************************************************************/

#ifdef WIN32
	class __declspec(dllexport) ANTCHAN  {
#else
	class ANTCHAN  {
#endif

			//private:
			public:
				int get_devtype(void)  { return devtype; }
				unsigned short get_period(void)  { return period; }

				unsigned char state;					// Un-Assigned = 0
																// Assigned = 1
																// Searching = 2
																// Tracking = 3
				static char statestr[4][32];
				unsigned char netnum;
				unsigned char returned_type;

				int number;											// channel number
				unsigned char freq;
				unsigned short period;
				int devtype;
				char typestr[32];
				bool open;

			public:
				ANTCHAN(void);
				~ANTCHAN(void);
		};

#endif		// #ifndef _SENTRY_H_

