
#ifdef WIN32
	#pragma warning(disable:4996)       // strncpy_s
#else
	#include <stdarg.h>
#endif

#include <assert.h>

#include <QtCore>

#include "tmr.h"
#include "antdev.h"


int ANTDEV::instances = 0;
#ifdef _DEBUG
int ANTDEV::calls = 0;
#endif


const unsigned char ANTDEV::USER_NETWORK_KEY[8] = { 0xB9, 0xA5, 0x21, 0xFB, 0xBD, 0x72, 0xC3, 0x45 };



/****************************************************************************
	copy constructor
****************************************************************************/

//ANTDEV::ANTDEV(const ANTDEV &copy)  {
//	bp = 0;
//}



/****************************************************************************
	constructor 1
****************************************************************************/

#ifdef ANTDEV_USES_QTIMER
ANTDEV::ANTDEV(QObject* _parent ) : QObject(_parent) {
#else
//ANTDEV::ANTDEV(void)  {
ANTDEV::ANTDEV(QObject* _parent ) : QObject(_parent) {
#endif

	calls++;

	init();
	assert(logstream == NULL);

	initialized = true;
	instances++;
	return;
}


/******************************************************************************

******************************************************************************/

ANTDEV::~ANTDEV(void) {

	destroy();

	instances--;

}

/******************************************************************************

******************************************************************************/

int ANTDEV::init(void) {
	int i;

#ifdef ANTDEV_USES_QTIMER
	somethread = NULL;
#else
	dotx = false;
	dorx = false;
#endif

#ifdef WIN32
#ifdef _DEBUG
	atid = GetCurrentThreadId();
#endif
#endif

	//devtype = -1;
	memset(&desc, 0, sizeof(desc));

	tid = -1;
	plogging = false;
	sequence = 0L;                                  // for logging

#ifdef WIN32
	InitializeCriticalSection(&critsec);
	// force code into memory, so we don't see any effects of paging? can't hurt.
	EnterCriticalSection(&critsec);
	LeaveCriticalSection(&critsec);
#endif

	id = -1;
	inpackets = 0;
	outpackets = 0;
	process_count = 0;
	ucStandardOptions = 0;
	ucAdvanced = 0;
	ucAdvanced2 = 0;
	msgdone = false;
	sernum = 0L;
	memset(sernum_string, 0, sizeof(sernum_string));
	memset(version, 0, sizeof(version));
	extended = false;                                        // if it can do extended messages

	memcpy(key, USER_NETWORK_KEY, sizeof(key));
	memset(logstr, 0, sizeof(logstr));
	memset(rxMessage, 0, sizeof(rxMessage));
	memset(serial_number, 0, sizeof(serial_number));

	net = 0;
	memset(error_string, 0, sizeof(error_string));
	ucStatePage = HRM_INIT_PAGE;           // Track if advanced data is supported

	memset(txq, 0, sizeof(txq));
	memset(rxq, 0, sizeof(rxq));

	ix = 0;
	state = ST_WAIT_FOR_SYNC;
	device = NULL;
	txtimer = NULL;
	rxtimer = NULL;

#ifdef _DEBUG
	memset(rxMessage, 0, sizeof(rxMessage));
#endif

	txstream = NULL;
	rxstream = NULL;

	ucStatePage = HRM_INIT_PAGE;  // Track if advanced data is supported
	ucPreviousEventCount = 0;     // Previous heart beat event count
	usPreviousTime1024 = 0;       // Time of previous heart beat event (1/1024 seconds)
	ucEventCount = 0;             // Heart beat event count
	usTime1024 = 0;               // Time of last heart beat event (1/1024 seconds)
	ant_hr = 0;
	ulElapsedTime2 = 0L;          // Cumulative operating time (elapsed time since battery insertion) in 2 second resolution
	ant_calculated_hr = 0;

	// Background Data

	ucMfgID = 0;               // Manufacturing ID
	ucHwVersion = 0;           // Hardware version
	ucSwVersion = 0;           // Software version
	ucModelNum = 0;            // Model number
	usSerialNum = 0;           // Serial number
	ucNoEventCount = 0;        // Successive transmissions with no new HR events
	ulAcumEventCount = 0L;     // Cumulative heart beat event count
	ulAcumTime1024 = 0L;       // Cumulative time (1/1024 seconds), conversion to s is performed for data display
	usR_RInterval1024 = 0;     // R-R interval (1/1024 seconds), conversion to ms is performed for data display


	usCadTime1024 = 0;
	usCadEventCount = 0;
	usSpdTime1024 = 0;
	usSpdEventCount = 0;
	eState = BSC_INIT;
	usCadPreviousEventCount = 0;
	usCadPreviousTime1024 = 0;
	usSpdPreviousEventCount = 0;
	usSpdPreviousTime1024 = 0;
	ucNoSpdEventCount = 0;
	ucNoCadEventCount = 0;
	ant_coasting = 0;
	ant_stopping = 0;
	ulCadAcumEventCount = 0;
	ulCadAcumTime1024 = 0;
	ant_cadence = 0;
	ulSpdAcumEventCount = 0;
	ulSpdAcumTime1024 = 0;
	ant_circumference_cm = 0;
	ant_wheel_rpm = 0;
	ant_speed = 0;
	ulDistance = 0;


#ifdef _DEBUG
	bp = 0;
	hrcalls = 0;
	sccalls = 0;
#endif

	length = 0;
	bytes = 0;
	check_sum = 0;

	logstream = NULL;
	rawstream = NULL;
	oktobreak = false;
	channel_event_ack = 0xff;
	gevent = 0;
	initialized = false;
	handle = NULL;

	total_tx_seconds = 0.0;
	tx_calls = 0L;

	total_rx_seconds = 0.0;
	rx_calls = 0L;
	read_calls = 0L;

	clear();

	for (i = 0; i < NANTCHANS; i++) {
		#ifdef _DEBUG
		bp = i;
		#endif
	}

	#ifdef _DEBUG
	bp = 0;
	#endif

	ant_circumference_cm = 70;

	//start_time = timeGetTime();
	start_time = QDateTime::currentMSecsSinceEpoch();

	initialized = true;

	return 0;
}                       // init()

/******************************************************************************

******************************************************************************/

void ANTDEV::clear(void) {
	if (handle) {
		libusb_close(handle);
		handle = NULL;
	}

	txinptr = 0;
	txoutptr = 0;
	rxinptr = 0;
	rxoutptr = 0;

	vid = 0;
	pid = 0;
	memset(mfgr, 0, sizeof(mfgr));
	memset(prod, 0, sizeof(prod));
	memset(sn, 0, sizeof(sn));
	nconfigs = 0;
	bus_number = 0;
	device_address = 0;
	int i, n;
	n = ifs.size();

	for (i = 0; i < n; i++) {
		ifs[i].clear();
	}

	ifs.clear();

	return;
}

/******************************************************************************

******************************************************************************/

void ANTDEV::add_intf(INTF _intf) {
	ifs.push_back(_intf);
	return;
}

/******************************************************************************

******************************************************************************/

void ANTDEV::dump(FILE *_stream) {

	if (_stream == NULL) {
		return;
	}

	fprintf(_stream, "\n");

	fprintf(_stream, "manufacturer = %s\n", mfgr);
	fprintf(_stream, "product = %s\n", prod);
	fprintf(_stream, "vendor = %d\n", vid);
	fprintf(_stream, "product = %d\n", pid);
	fprintf(_stream, "bus number = %d\n", bus_number);
	fprintf(_stream, "device address = %d\n", device_address);
	fprintf(_stream, "sn = %s\n", sn);
	fprintf(_stream, "ix = %d\n", ix);
	fprintf(_stream, "nconfigs = %d\n", nconfigs);
	fprintf(_stream, "ifs.size() = %lu\n", ifs.size());

	return;
}


#if 1

/*******************************************************************************************************
	message I/O
*******************************************************************************************************/

int ANTDEV::send(ANTMsg m, bool _flush, unsigned char _chan) {
	Q_UNUSED(_flush);
	static const unsigned char padding[5] = { '\0', '\0', '\0', '\0', '\0' };
	int i, j, n;
	//char str[8];
	char *buf = NULL;

	outpackets++;


	if (_chan != 0xff) {
		if (_chan != m.data[3]) {
			bp = 3;
		}

		if (channels[_chan].open) {
			bp = 1;
		}
	}

#ifdef _DEBUG
	if (outpackets == 3) {
		bp = 2;
	}
	//if (m.data[4] == ANT_VERSION)  {								// set power
	//	bp = 3;
	//}
	if (m.data[2] == ANT_REQ_MESSAGE) {                      // 0x4d
		int len = m.data[1];
		int req = m.data[4];

		if (len != 2) {
			//throw (fatalError(__FILE__, __LINE__));
			qFatal("error 37");
		}

		switch (req) {
			case ANT_CAPABILITIES: {                           // 0x54
				bp = 1;
				break;
			}
			case ANT_SERIAL_NUMBER: {                          // 0x61
				bp = 2;
				break;
			}
			case ANT_VERSION: {                                // 0x3d
				bp = 3;
				break;
			}
			case ANT_CHANNEL_STATUS: {                         // 0x52
				bp = 4;
				break;
			}
			case ANT_CHANNEL_ID: {                             // 0x51
				bp = 5;
				break;
			}
			default: {
				bp = 2;
				break;
			}
		}
	}
#endif

	memcpy(&m.data[m.length], padding, 2);       // tlm

	n = m.length + 2;
	buf = (char*)m.data;

	bp = 0;

#ifdef _DEBUG
	sequence++;
	if (buf[0] == 'e') {
		bp = 2;
	}
	printf("\nsend: ");
	for (i = 0; i < n - 1; i++) {
		printf("%02x ", buf[i] & 0xff);
	}
	printf("%02x\n", buf[i] & 0xff);
#endif

	for (i = 0; i < n; i++) {
		j = (txinptr + i) % TXBUFLEN;
		txq[j] = buf[i];
	}
	txinptr = (txinptr + i) % TXBUFLEN;

	return 0;
}                             // send()

#else
/**************************************************************************************************
	puts _buf into txq
**************************************************************************************************/

int send(unsigned char *_buf, int _n) {
	int i, j;


	#ifdef _DEBUG
	send_calls++;
	if (send_calls == 2) {
		bp = 4;
	}
	#endif

	for (i = 0; i < _n; i++) {
		j = (txinptr + i) % TXBUFLEN;
		txq[j] = _buf[i];
	}
	txinptr = (txinptr + i) % TXBUFLEN;
	return 0;
}                          // send()
#endif

/**************************************************************************************************
	called from writer thread
**************************************************************************************************/

int ANTDEV::tx(unsigned char *_buf, int _n, unsigned long _timeout) {
	int written, total, wep, status;
	bool flag;
	int i, n, rc = -1;


	if (txinptr == txoutptr) {
		return 0;
	}

	if (handle == NULL) {
		return -1;
	}

	tx_calls++;

	wep = 1;                                  // write to address 1
	total = 0;
	i = 0;
	n = _n;
	flag = true;


	while (flag) {
		status = libusb_bulk_transfer( handle, wep, &_buf[i], n, &written, _timeout );
		switch (status) {
			case 0: {
				if (written == _n) {
					flag = false;
					rc = _n;
				}
				else  {
					total += written;
					if (total == _n) {
						flag = false;
						rc = _n;
					}
					else  {
						i += written;
						n -= written;
					}
				}
				break;
			}
			case LIBUSB_ERROR_TIMEOUT: {        // if the transfer timed out
				bp = 1;
				break;
			}
			case LIBUSB_ERROR_PIPE: {           // if the endpoint halted
				rc = -1;
				flag = false;
				break;
			}
			case LIBUSB_ERROR_OVERFLOW: {       // if the device offered more data, see Packets and overflows
				rc = -2;
				flag = false;
				break;
			}
			case LIBUSB_ERROR_NO_DEVICE: {      // if the device has been disconnected
				rc = -3;
				flag = false;
				break;
			}
			default: {                          // LIBUSB_ERROR code on other error
				rc = -4;
				flag = false;
				break;
			}
		}                 // switch()
	}                    // while(flag)

	return rc;
}                       // tx()


/**************************************************************************************************
	called from reader about 3 times per second
	simply puts stuff in the rxq
**************************************************************************************************/

int ANTDEV::rx(void) {
	int bytes_read, rep, status;
	bool flag;
	int i, rc = -1;
	unsigned char buf[64];
	unsigned short len;

	if (!handle) {
		return 0;
	}

	unsigned int timeout = 100;

	rep = 0x81;
	i = 0;
	flag = true;

	bp = 0;
	int reads = 0;
	int timeouts = 0;

	rx_calls++;


	while (flag) {
		reads++;
		#ifdef _DEBUG
		memset(buf, 0, sizeof(buf));
		#endif

		status = libusb_bulk_transfer(
			handle,                       // struct libusb_device_handle *dev_handle,
			rep,                          // unsigned char endpoint, 0x81
			buf,                          // unsigned char *data,
			(int)sizeof(buf),             // int length,
			&bytes_read,                  // int *transferred,
			timeout                       // unsigned int timeout
			);

#ifdef _DEBUG
		char *cptr;
		if (status == -1)  {
			cptr = strerror(errno);			// Device or resource busy
			Q_UNUSED(cptr);
		}

#endif

		switch (status) {
			case 0: {
				if (bytes_read == 0) {
					rc = 0;
					flag = false;
					break;
				}

				int j;

				for (i = 0; i < bytes_read; i++) {
					j = (rxinptr + i) % RXBUFLEN;
					rxq[j] = buf[i];
				}

				rxinptr = (rxinptr + bytes_read) % RXBUFLEN;
				len = rxinptr - rxoutptr;

				// check for overflows here? (to do)

				len &= (RXBUFLEN - 1);
				bp = 0;

				if (bytes_read <= RXBUFLEN) {
					rc = bytes_read;
					flag = false;
				}
				else  {
					bp = 1;
				}

				break;
			}

			case LIBUSB_ERROR_TIMEOUT: {        // if the transfer timed out
				timeouts++;
				//if (timeouts >= ROUND(1000.0f/(float)timeout))  {			// allow only 1 second of timeouts before giving up
				if (timeouts > 0) {
					rc = LIBUSB_ERROR_TIMEOUT;
					flag = false;
				}
				break;
			}
			case LIBUSB_ERROR_PIPE: {           // if the endpoint halted -9
				//sprintf(str, "error2 writing TO ANT stick: %d, endpoint = %02x\n", status, wep);
				rc = LIBUSB_ERROR_PIPE;
				flag = false;
				break;
			}
			case LIBUSB_ERROR_OVERFLOW: {       // if the device offered more data, see Packets and overflows
				//sprintf(str, "error3 writing TO ANT stick: %d, endpoint = %02x\n", status, wep);
				rc = LIBUSB_ERROR_OVERFLOW;
				flag = false;
				break;
			}
			case LIBUSB_ERROR_NO_DEVICE: {      // if the device has been disconnected
				//sprintf(str, "error4 writing TO ANT stick: %d, endpoint = %02x\n", status, wep);
				rc = LIBUSB_ERROR_NO_DEVICE;
				flag = false;
				break;
			}

			case LIBUSB_ERROR_IO: {
				flag = false;
				rc = LIBUSB_ERROR_IO;
				break;
			}

			default: {                          // LIBUSB_ERROR code on other error
				//sprintf(str, "error5 writing TO ANT stick: %d, endpoint = %02x\n", status, wep);
				printf("default rx: status = %d\n", status);
				rc = -999;
				flag = false;
				break;
			}
		}                 // switch()
	}                    // while(flag)


	return rc;
}                       // rx()

/**************************************************************************************************

**************************************************************************************************/

void ANTDEV::process(void) {
	unsigned char msg;

	//unsigned char channel, event, response;

	process_count++;

#ifdef _DEBUG
	char str[256];
	if (process_count == 2) {
		bp = 1;
	}
	memset(str, 0, sizeof(str));
#ifdef WIN32
	DWORD tid = GetCurrentThreadId();
	assert(tid == rtid);
#endif
#endif

	//struct timeval timestamp;
	//gettimeofday (&timestamp, NULL);

	#ifdef _DEBUG
	bp = 1;
	int i = rxMessage[ANT_OFFSET_ID];
	#endif



	msg = rxMessage[OFFS_MSG];                               // OFFS_MSG = 2

#ifdef _DEBUG
	char msgstr[32];
	//DWORD now = timeGetTime();
	qint64 now = QDateTime::currentMSecsSinceEpoch();


	switch (msg) {
		case ANT_CHANNEL_EVENT: {    // 0x40
			strcpy(msgstr, "ANT_CHANNEL_EVENT");
			break;
		}
		case ANT_CHANNEL_ID: {        // 0X51, set channel id
			strcpy(msgstr, "ANT_CHANNEL_ID");
			break;
		}
		case ANT_CHANNEL_STATUS: {    // 0X52
			strcpy(msgstr, "ANT_CHANNEL_STATUS");
			break;
		}
		case ANT_SET_NETWORK: {       // 0X46
			strcpy(msgstr, "ANT_SET_NETWORK");
			break;
		}
		case MESG_STARTUP_MESG_ID: {    // 0X6F
			//strcpy(msgstr, "MESG_STARTUP_MESG_ID");
			strcpy(msgstr, "STARTUP");
			break;
		}
		case ANT_CAPABILITIES: {    // 0x54
			strcpy(msgstr, "ANT_CAPABILITIES");
			break;
		}
		case ANT_SERIAL_NUMBER: {    // 0x61
			strcpy(msgstr, "ANT_SERIAL_NUMBER");
			break;
		}
		case ANT_VERSION: {    // 0x3e
			strcpy(msgstr, "ANT_VERSION");
			break;
		}
		case ANT_BROADCAST_DATA: {
			strcpy(msgstr, "ANT_BROADCAST_DATA");
			break;
		}

		default: {
			strcpy(msgstr, "------------");
			break;
		}
	}


	int len = rxMessage[1];
	len += 2;

	bool flag = true;

	switch (msg) {
		case ANT_CHANNEL_EVENT: {                       // 0x40
			switch (rxMessage[OFFS_EVENT_ID]) {
				case EVENT_RX_SEARCH_TIMEOUT: {           // 0x01
					flag = false;
					break;
				}
				default: {
					break;
				}
			}
			break;
		}

		case ANT_BROADCAST_DATA: {                      // 0x4e
			flag = false;
			break;
		}

		default: {
			bp = 1;
			break;
		}
	}

	if (flag) {
		printf("  ");
		for (i = 0; i < len; i++) {
			printf("%02x ", rxMessage[i]);
		}
	}


	if (msg == 0x40) {
		char eventstr[32];
		unsigned char _ev;
		_ev = rxMessage[OFFS_EVENT_ID];
		switch (_ev) {
			case EVENT_RX_SEARCH_TIMEOUT: {                             // UNSOLICITED
				strcpy(eventstr, "EVENT_RX_SEARCH_TIMEOUT");
				break;
			}
			case MESG_NETWORK_KEY_ID: {
				strcpy(eventstr, "MESG_NETWORK_KEY_ID");
				break;
			}
			case ANT_ASSIGN_CHANNEL: {                                  // 0x42
				strcpy(eventstr, "ANT_ASSIGN_CHANNEL");
				break;
			}
			case ANT_CHANNEL_TX_POWER: {                                // 0x60
				strcpy(eventstr, "ANT_CHANNEL_TX_POWER");
				break;
			}
			case ANT_CHANNEL_FREQUENCY: {                               // 0x45
				strcpy(eventstr, "ANT_CHANNEL_FREQUENCY");
				break;
			}
			case ANT_CHANNEL_ID: {                                      // 0x51
				strcpy(eventstr, "ANT_CHANNEL_ID");
				break;
			}
			case ANT_CHANNEL_PERIOD: {                                  // 0x43
				strcpy(eventstr, "ANT_CHANNEL_PERIOD");
				break;
			}
			case ANT_OPEN_CHANNEL: {                                    // 0x4b
				strcpy(eventstr, "ANT_OPEN_CHANNEL");
				break;
			}
			case ANT_ENABLE_EXT_MSGS: {                                 // 0x66
				strcpy(eventstr, "ANT_ENABLE_EXT_MSGS");
				break;
			}
			default: {
				strcpy(eventstr, "----");
				break;
			}
		}

		// don't print unsolicited messages?

		switch (_ev) {
			case EVENT_RX_SEARCH_TIMEOUT: {
				break;
			}
			default: {
				printf("%8lld %02x [%02x %02x] %s %s\n", now, _ev, gevent, channel_event_ack, msgstr, eventstr);
				break;
			}
		}
	}
	else  {
		switch (msg) {
			case ANT_BROADCAST_DATA: {
				break;
			}
			default:
				printf("%8lld msgdone=%s %s\n", now, msgdone ? "true " : "false", msgstr);
				if (msgdone) {
					//throw (fatalError(__FILE__, __LINE__));
					qFatal("paxton");
				}
		}
	}
#endif

	switch (msg) {                                           // rxMessage[2]
		case ANT_CHANNEL_EVENT:  {                            // MESG_RESPONSE_EVENT_ID (0x40)
			int status = handle_channel_event();
			assert(status == 0);
			break;
		}

		case MESG_STARTUP_MESG_ID:  {                // 0x6f = 111
			//gmsg2 = msg;
			//strcpy(str, "process(): MESG_STARTUP_MESG_ID:\n");
			UCHAR ucReason = rxMessage[OFFS_DATA];

			if (ucReason == RESET_POR) {
				bp = 1;
				strcat(str, "   RESET_POR");
			}

			if (ucReason & RESET_SUSPEND) {
				strcat(str, "   RESET_SUSPEND");
			}

			if (ucReason & RESET_SYNC) {
				strcat(str, "   RESET_SYNC");
			}

			if (ucReason & RESET_CMD) {
				strcat(str, "   RESET_CMD");
			}

			if (ucReason & RESET_WDT) {
				strcat(str, "   RESET_WDT");
			}

			if (ucReason & RESET_RST) {
				strcat(str, "   RESET_RST");
			}

			//while(plogging) {} plogg("%s\n", str);
			//gack = ANT_SYSTEM_RESET;				// 0x4a
			msgdone = true;
			//gack2 = 0x00;
			break;
		}

		case ANT_CHANNEL_STATUS:  {                        // 0x52
			int chan = rxMessage[3];

			channels[chan].state = rxMessage[4] & 0x03;           // get bits 0 and 1 only
			//#ifdef _DEBUG
			#if 0
			sprintf(str, "	STATUS: %s\n", ANTCHAN::statestr[channels[chan].state]);
			while (plogging) {
			}
			plogg("%s", str);
			#endif

			bool AP1 = false;

			if (!AP1) {
				channels[chan].netnum = rxMessage[4] & 0x0c;                // get bits 2 and 3 only
				channels[chan].returned_type = rxMessage[4] & 0xf0;
			}

			msgdone = true;
			break;
		}


		case ANT_CHANNEL_ID:  {                                           // 0x51
			int chan = rxMessage[3];
			unsigned short devnum;
			unsigned char type_id;
			unsigned char transmission_type;
			memcpy(&devnum, &rxMessage[4], sizeof(unsigned short));
			type_id = rxMessage[6];                                        // should be the same as channels[chan].devtype
			assert(type_id == channels[chan].devtype);
			transmission_type = rxMessage[7];
			Q_UNUSED(transmission_type);

			//strcpy(str, "process(): ANT_CHANNEL_ID:");
			msgdone = true;
			break;
		}

		case ANT_BROADCAST_DATA:  {               // 0x4e, called about 3 times per second
			if (initialized) {
				int k = rxMessage[OFFS_CHAN];       // k = channel number (0-7)

				switch (channels[k].devtype) {
					case 121: {
						ant_decode_speed_cadence();
						break;
					}
					case 120: {
						ant_decode_hr();
						break;
					}
				}
			}
			else  {
				bp = 1;
			}
			break;
		}

		case ANT_ACK_DATA: {
			#ifdef _DEBUG
			sprintf(str, "ANT_ACK_DATA %s\n", mfgr);
			while (plogging) {
			}
			plogg("%s", str);
			bp  = 1;
			#endif
			break;
		}

		case ANT_BURST_DATA: {
			#ifdef _DEBUG
			sprintf(str, "ANT_BURST_DATA %s\n", mfgr);
			while (plogging) {
			}
			plogg("%s", str);
			#endif
			break;
		}

		case ANT_VERSION:  {
			//gmsg2 = msg;
			int len = rxMessage[1];
			if (len > (int)sizeof(version) - 1) {
				//throw (fatalError(__FILE__, __LINE__, "version too long"));
				qFatal("version too long");
			}
			memcpy(version, &rxMessage[3], len);                        // "AJK1.04RAF"
			msgdone = true;
			//assert(gack2==0xff);
			//gack2 = 0;
			break;
		}

		case ANT_SERIAL_NUMBER: {
			//gmsg2 = msg;
			sernum = (rxMessage[3] << 24) & 0xff000000;
			sernum |= (rxMessage[4] << 16) & 0x00ff0000;
			sernum |= (rxMessage[5] << 8) & 0x0000ff00;
			sernum |= (rxMessage[6] << 24) & 0x000000ff;

			memcpy(&sernum, &rxMessage[3], 4);                                   // reverses the order of the above code
			sprintf(sernum_string, "%04lx", sernum);
			//gack2 = 0x00;
			msgdone = true;
			break;
		}

		case ANT_CAPABILITIES:  {
			//gmsg2 = msg;
			//assert(gmsg2==ANT_CAPABILITIES);
			unsigned char *buf = &rxMessage[3];

			//while(plogging) {} plogg("		%s Max ANT Channels: %d\n", mfgr, buf[0]);
			//while(plogging) {} plogg("		%s Max ANT Networks: %d\n", mfgr, buf[1]);

			ucStandardOptions = buf[2];               // 0x00
			ucAdvanced = buf[3];                      // 0xba
			ucAdvanced2 = buf[4];                     // 0x36
			// note: buf[5] is reserved (unused)

			//while(plogging) {} plogg("	%s Standard Options:\n", mfgr);

			if ( ucStandardOptions & CAPABILITIES_NO_RX_CHANNELS ) {
				//while(plogging) {} plogg("		CAPABILITIES_NO_RX_CHANNELS\n");
			}

			if ( ucStandardOptions & CAPABILITIES_NO_TX_CHANNELS ) {
				//while(plogging) {} plogg("		CAPABILITIES_NO_TX_CHANNELS\n");
			}

			if ( ucStandardOptions & CAPABILITIES_NO_RX_MESSAGES ) {
				//while(plogging) {} plogg("		CAPABILITIES_NO_RX_MESSAGES\n");
			}

			if ( ucStandardOptions & CAPABILITIES_NO_TX_MESSAGES ) {
				//while(plogging) {} plogg("		CAPABILITIES_NO_TX_MESSAGES\n");
			}

			if ( ucStandardOptions & CAPABILITIES_NO_ACKD_MESSAGES ) {
				//while(plogging) {} plogg("		CAPABILITIES_NO_ACKD_MESSAGES\n");
			}

			if ( ucStandardOptions & CAPABILITIES_NO_BURST_TRANSFER ) {
				//while(plogging) {} plogg("		CAPABILITIES_NO_BURST_TRANSFER\n");
			}

			////////////////////////////////////////////

			//while(plogging) {} plogg("	Advanced Options:\n");

			if ( ucAdvanced & CAPABILITIES_OVERUN_UNDERRUN ) {
				//while(plogging) {} plogg("		CAPABILITIES_OVERUN_UNDERRUN\n");
			}

			if ( ucAdvanced & CAPABILITIES_NETWORK_ENABLED ) {
				//while(plogging) {} plogg("		CAPABILITIES_NETWORK_ENABLED\n");								// this
			}

			if ( ucAdvanced & CAPABILITIES_AP1_VERSION_2 ) {
				//while(plogging) {} plogg("		CAPABILITIES_AP1_VERSION_2\n");
			}

			if ( ucAdvanced & CAPABILITIES_SERIAL_NUMBER_ENABLED ) {
				//while(plogging) {} plogg("		CAPABILITIES_SERIAL_NUMBER_ENABLED\n");						// this
			}

			if ( ucAdvanced & CAPABILITIES_PER_CHANNEL_TX_POWER_ENABLED ) {
				//while(plogging) {} plogg("		CAPABILITIES_PER_CHANNEL_TX_POWER_ENABLED\n");				// this
			}

			if ( ucAdvanced & CAPABILITIES_LOW_PRIORITY_SEARCH_ENABLED ) {
				//while(plogging) {} plogg("		CAPABILITIES_LOW_PRIORITY_SEARCH_ENABLED\n");				// this
			}

			if ( ucAdvanced & CAPABILITIES_SCRIPT_ENABLED ) {
				//while(plogging) {} plogg("		CAPABILITIES_SCRIPT_ENABLED\n");
			}

			if ( ucAdvanced & CAPABILITIES_SEARCH_LIST_ENABLED ) {
				//while(plogging) {} plogg("		CAPABILITIES_SEARCH_LIST_ENABLED\n");							// this
			}

			////////////////////////////////////////////

			//plogg("	Advanced 2 Options:\n");

			if ( ucAdvanced2 & CAPABILITIES_LED_ENABLED ) {
				//while(plogging) {} plogg("		CAPABILITIES_LED_ENABLED\n");
			}

			if ( ucAdvanced2 & CAPABILITIES_EXT_MESSAGE_ENABLED ) {
				//while(plogging) {} plogg("		CAPABILITIES_EXT_MESSAGE_ENABLED\n");							// this
			}

			if ( ucAdvanced2 & CAPABILITIES_SCAN_MODE_ENABLED ) {
				//while(plogging) {} plogg("		CAPABILITIES_SCAN_MODE_ENABLED\n");								// this
			}

			if ( ucAdvanced2 & CAPABILITIES_RESERVED ) {
				//while(plogging) {} plogg("		CAPABILITIES_RESERVED\n");
			}

			if ( ucAdvanced2 & CAPABILITIES_PROX_SEARCH_ENABLED ) {
				//while(plogging) {} plogg("		CAPABILITIES_PROX_SEARCH_ENABLED\n");							// this, proximity search
				bp = 1;
			}

			if ( ucAdvanced2 & CAPABILITIES_EXT_ASSIGN_ENABLED ) {
				//while(plogging) {} plogg("		CAPABILITIES_EXT_ASSIGN_ENABLED\n");							// this
			}

			if ( ucAdvanced2 & CAPABILITIES_FS_ANTFS_ENABLED) {
				//while(plogging) {} plogg("		CAPABILITIES_FREE_1\n");
			}

			if ( ucAdvanced2 & CAPABILITIES_FIT1_ENABLED ) {
				//while(plogging) {} plogg("		CAPABILITIES_FIT1_ENABLED\n");
			}

			msgdone = true;
			//gack2 = 0x00;
			break;
		}                    //	case ANT_CAPABILITIES:

		default: {
			#ifdef _DEBUG
			sprintf(str, "woopsy %s\n", mfgr);
			while (plogging) {
			}
			plogg("%s", str);
			bp = 1;
			#endif
			break;
		}
	}                 // switch (rxMessage[ANT_OFFSET_ID])

	memset(rxMessage, 0, sizeof(rxMessage));

	return;
}                          // void process()

/**************************************************************************************************

**************************************************************************************************/

void ANTDEV::receiveByte(unsigned char byte) {

	switch (state) {
		case ST_WAIT_FOR_SYNC: {
			if (byte == ANT_SYNC_BYTE) {                                // 0xa4
				check_sum = ANT_SYNC_BYTE;
				rxMessage[0] = byte;
				state = ST_GET_LENGTH;
			}
			break;
		}

		case ST_GET_LENGTH: {
			if ((byte == 0) || (byte > ANT_MAX_LENGTH)) {               // ANT_MAX_LENGTH = 9
				state = ST_WAIT_FOR_SYNC;
			}
			else  {
				//rxMessage[ANT_OFFSET_LENGTH] = byte;
				rxMessage[1] = byte;
				check_sum ^= byte;
				length = byte;
				bytes = 0;
				state = ST_GET_MESSAGE_ID;
			}
			break;
		}

		case ST_GET_MESSAGE_ID: {
			//rxMessage[ANT_OFFSET_ID] = byte;
			rxMessage[2] = byte;
			check_sum ^= byte;
			state = ST_GET_DATA;
			break;
		}

		case ST_GET_DATA: {
			//rxMessage[ANT_OFFSET_DATA + bytes] = byte;
			rxMessage[3 + bytes] = byte;                                   // 0x6f 0x20 = "command reset" response
			check_sum ^= byte;
			if (++bytes == length) {
				state = ST_VALIDATE_PACKET;
			}
			break;
		}

		case ST_VALIDATE_PACKET: {
			if (byte == check_sum) {
				//rxMessage[ANT_OFFSET_DATA + bytes] = byte;
				inpackets++;
				rxMessage[3 + bytes] = byte;

#ifdef _DEBUG
				if (inpackets == 2) {
					fflush(rxstream);
					bp = 1;
				}
#endif
				rxlog();
#ifdef _DEBUG
				if (inpackets < 10) {
					//fclose(rxstream);
					//rxstream = fop
					fflush(rxstream);
					bp = 1;
				}
#endif
				process();
			}
			else  {
				bp = 1;                    // bad checksum
			}

			state = ST_WAIT_FOR_SYNC;
			break;
		}
	}
	return;
}                             // receiveByte()

/********************************************************************************************************

********************************************************************************************************/

bool ANTDEV::wait_event_ack(UCHAR _event, qint64 _ms) {
	bool b = false;
	qint64 start;

#ifdef _DEBUG
	//if (_event == ANT_CAPABILITIES)  {
	//if (_event==ANT_ENABLE_EXT_MSGS)  {
	if (_event == ANT_CHANNEL_TX_POWER) {                            // set channel power, 0x60
		//if (_event==ANT_OPEN_CHANNEL)  {											// set channel power, 0x60
		//if (_event==ANT_ASSIGN_CHANNEL)  {
		bp = 8;
	}
#endif

	//start = timeGetTime();
	start = QDateTime::currentMSecsSinceEpoch();

	while (1) {
		if (_event == gevent) {
			#ifdef _DEBUG
			//if (_event == ANT_CAPABILITIES)  {
			//if (_event == ANT_ENABLE_EXT_MSGS)  {
			//if (_event==ANT_OPEN_CHANNEL)  {											// 0x4b

				#ifdef WIN32
			tid = GetCurrentThreadId();
			assert(tid == atid);
				#endif

			if (_event == ANT_CHANNEL_TX_POWER) {                                // set channel power, 0x60
				if (channel_event_ack == RESPONSE_NO_ERROR) {
					bp = 2;
				}
			}
			#endif

			if (channel_event_ack == RESPONSE_NO_ERROR) {
				b = true;
			}
			#ifdef _DEBUG
			else {
				bp = 2;
				//break;
			}
			#endif
		}
		if (b) {
			break;
		}
		if ((QDateTime::currentMSecsSinceEpoch() - start) >= _ms) {
			printf("\nwea timed out\n");
			break;
		}
	}

	#ifdef _DEBUG
	//DWORD now = timeGetTime();
	//qint64 now = QDateTime::currentMSecsSinceEpoch();
	bp = 0;
	#endif

	channel_event_ack = 0xff;
	gevent = 0;

	return b;
}                 // wait_event_ack()

/********************************************************************************************************

 *******************************************************************/

/********************************************************************************************************

********************************************************************************************************/


bool ANTDEV::wait_for_message_completion(UCHAR _msg, qint64 _ms) {
	Q_UNUSED(_msg);

	//unsigned long start;

	//start = timeGetTime();
	qint64 start = QDateTime::currentMSecsSinceEpoch();

	while (!msgdone) {
		if ((QDateTime::currentMSecsSinceEpoch() - start) >= _ms) {
			break;
		}
		QThread::msleep(10);
	}

	return msgdone;

}                 // wait_for_message_completion()

/**************************************************************************************

	this decoder based on


	entry:
		ucWheelCircumference set to calculate speed
		ant_packet contains the payload

	exit:
		cadence calculated
		speed (meters / hour) calculated
		wheel_rpm calculated
		(all floats)

**************************************************************************************/

int ANTDEV::ant_decode_speed_cadence(void) {

	USHORT usEventDiff = 0;
	USHORT usTimeDiff1024 = 0;
	unsigned char *buf = &rxMessage[4];

	//--------------------------------------
	// cadence:
	//--------------------------------------

	usCadTime1024 = buf[0];
	usCadTime1024 += buf[1] << 8;              // crankMeasurmentTime

	usCadEventCount = buf[2];
	usCadEventCount += buf[3] << 8;            // crankRevolutions

	//--------------------------------------
	// speed:
	//--------------------------------------

	usSpdTime1024 = buf[4];
	usSpdTime1024 += buf[5] << 8;              // wheelMeasurementTime

	usSpdEventCount = buf[6];
	usSpdEventCount += buf[7] << 8;            // wheelRevolutions


	if (eState == BSC_INIT) {
		usCadPreviousTime1024 = usCadTime1024;
		usCadPreviousEventCount = usCadEventCount;

		usSpdPreviousTime1024 = usSpdTime1024;
		usSpdPreviousEventCount = usSpdEventCount;

		eState = BSC_ACTIVE;
	}

	//-----------------------------------------------------
	// update cadence calculations on new cadence event
	// this is the large bump on the sensor body
	//-----------------------------------------------------

	if (usCadEventCount != usCadPreviousEventCount) {
		ucNoCadEventCount = 0;
		ant_coasting = false;

		// update cumulative event count

		if (usCadEventCount > usCadPreviousEventCount) {
			usEventDiff = usCadEventCount - usCadPreviousEventCount;
		}
		else  {
			usEventDiff = (USHORT)(0xFFFF - usCadPreviousEventCount + usCadEventCount + 1);
		}
		ulCadAcumEventCount += usEventDiff;

		// update cumulative time (1/1024s)

		if (usCadTime1024 > usCadPreviousTime1024) {
			usTimeDiff1024 = usCadTime1024 - usCadPreviousTime1024;
		}
		else  {
			usTimeDiff1024 = (USHORT)(0xFFFF - usCadPreviousTime1024 + usCadTime1024 + 1);
		}
		ulCadAcumTime1024 += usTimeDiff1024;

		// calculate cadence (rpm)

		if (usTimeDiff1024 > 0) {
			ant_cadence = (float)( ((ULONG)usEventDiff * 0xF000) / (ULONG)usTimeDiff1024 );     // 1 min = 0xF000 = 60 * 1024
		}
	}
	else  {
		ucNoCadEventCount++;

		if (ucNoCadEventCount >= MAX_NO_EVENTS) {
			ant_coasting = true;                         // coasting
			ant_cadence = 0.0f;
		}
	}


	//-----------------------------------------------------
	// Update speed calculations on new speed event
	// this is the head of the giraffe
	//-----------------------------------------------------

	if (usSpdEventCount != usSpdPreviousEventCount) {
		ucNoSpdEventCount = 0;
		ant_stopping = false;
		// Update cumulative event count
		if (usSpdEventCount > usSpdPreviousEventCount) {
			usEventDiff = usSpdEventCount - usSpdPreviousEventCount;
		}
		else  {
			usEventDiff = (USHORT)(0xFFFF - usSpdPreviousEventCount + usSpdEventCount + 1);
		}
		ulSpdAcumEventCount += usEventDiff;

		// Update cumulative time (1/1024s)

		if (usSpdTime1024 > usSpdPreviousTime1024) {
			usTimeDiff1024 = usSpdTime1024 - usSpdPreviousTime1024;
		}
		else  {
			usTimeDiff1024 = (USHORT)(0xFFFF - usSpdPreviousTime1024 + usSpdTime1024 + 1);
		}

		ulSpdAcumTime1024 += usTimeDiff1024;


		ant_wheel_rpm = ((float)usEventDiff / (float)usTimeDiff1024) * 60.0f * 1024.0f;

		if (ant_circumference_cm) {
#ifdef _DEBUG
			//float diameter = (float) (circumference_cm / PI);
#endif
			// Calculate speed (meters/h)
			ant_speed = (float)(ant_circumference_cm * 0x9000 * (ULONG)usEventDiff) / (ULONG)usTimeDiff1024;      // 1024 * 36 = 0x9000
		}

		// Calculate distance (cm)

		ulDistance = (ULONG)ant_circumference_cm * ulSpdAcumEventCount;
	}
	else  {
		ucNoSpdEventCount++;
		if (ucNoSpdEventCount >= MAX_NO_EVENTS) {
			ant_stopping = true;
			ant_wheel_rpm = 0.0f;
			ant_speed = 0.0f;
		}
	}

	// Update previous values

	usCadPreviousTime1024 = usCadTime1024;
	usCadPreviousEventCount = usCadEventCount;

	usSpdPreviousTime1024 = usSpdTime1024;
	usSpdPreviousEventCount = usSpdEventCount;

	return 0;
}              // decode_speed_cadence()

/**************************************************************************************

**************************************************************************************/

int ANTDEV::ant_decode_hr(void) {
	UCHAR ucPageNum = 0;
	UCHAR ucEventDiff = 0;
	USHORT usTimeDiff1024 = 0;

	unsigned char *buf = &rxMessage[4];

#ifdef _DEBUG
	hrcalls++;
#endif


	// monitor page toggle bit

	if (ucStatePage != HRM_EXT_PAGE) {
		if (ucStatePage == HRM_INIT_PAGE) {
			ucStatePage = (buf[0] & HRM_TOGGLE_MASK) >> 7;
			// initialize previous values to correctly get the cumulative values
			ucPreviousEventCount = buf[6];
			usPreviousTime1024 = buf[4];
			usPreviousTime1024 += buf[5] << 8;
		}
		else if (ucStatePage != ((buf[0] & HRM_TOGGLE_MASK) >> 7))
		{
			// first page toggle was seen, enable advanced data
			ucStatePage = HRM_EXT_PAGE;
		}
	}

	// remove page toggle bit

	ucPageNum = buf[0] & ~HRM_TOGGLE_MASK;       // page 0 and 4 are the main data pages

	// Handle basic data

	ucEventCount = buf[6];
	usTime1024 = buf[4];
	usTime1024 += buf[5] << 8;
	//if (hrcalls>15)  {
	//if (buf[6] != 0xcc && buf[7] != 0xcc)  {				// wait for valid buf
#ifdef _DEBUG
	//if (have_ant_packet)  {
	ant_hr = buf[7];
	//}
#else
	ant_hr = buf[7];
#endif


	// handle background data, if supported

	if (ucStatePage == HRM_EXT_PAGE) {
		switch (ucPageNum) {
			case HRM_PAGE1: {
				ulElapsedTime2 = buf[1];
				ulElapsedTime2 += buf[2] << 8;
				ulElapsedTime2 += buf[3] << 16;
				break;
			}
			case HRM_PAGE2: {
				ucMfgID = buf[1];
				usSerialNum = buf[2];
				usSerialNum += buf[3] << 8;      // serial number = 3?
				break;
			}
			case HRM_PAGE3: {
				ucHwVersion = buf[1];         // 4
				ucSwVersion = buf[2];         // 4
				ucModelNum = buf[3];          // 5
				break;
			}
			case HRM_PAGE4: {
				usPreviousTime1024 = buf[2];
				usPreviousTime1024 += buf[3] << 8;
				break;
			}
			default: {
#ifdef _DEBUG
				bp = 0;
#endif
				break;
			}
		}
	}


	// only need to do calculations if dealing with a new event

	if (ucEventCount != ucPreviousEventCount) {
		ucNoEventCount = 0;

		// update cumulative event count

		if (ucEventCount > ucPreviousEventCount) {
			ucEventDiff = ucEventCount - ucPreviousEventCount;
		}
		else  {
			ucEventDiff = (UCHAR)0xFF - ucPreviousEventCount + ucEventCount + 1;
		}

		ulAcumEventCount += ucEventDiff;

		// update cumulative time

		if (usTime1024 > usPreviousTime1024) {
			usTimeDiff1024 = usTime1024 - usPreviousTime1024;
		}
		else  {
			usTimeDiff1024 = (USHORT)(0xFFFF - usPreviousTime1024 + usTime1024 + 1);
		}

		ulAcumTime1024 += usTimeDiff1024;


		// calculate R-R Interval

		if (ucEventDiff == 1) {
			usR_RInterval1024 = usTimeDiff1024;
		}

		// calculate heart rate (from timing data), in ant_bpm

		if (usTimeDiff1024 > 0) {
			ant_calculated_hr = (UCHAR)( ((USHORT)ucEventDiff * 0xF000) / usTimeDiff1024 );     // 1 min = 0xF000 = 60 * 1024
		}
	}
	else  {
		ucNoEventCount++;
		if (ucNoEventCount >= MAX_NO_EVENTS) {
			ant_hr = ant_calculated_hr = HRM_INVALID_BPM;   // No new valid HR data has been received
		}
	}

	if (ant_calculated_hr != HRM_INVALID_BPM) {
		int diff = abs(ant_calculated_hr - ant_hr);
		if (diff > 5) {
			// maybe average ant_hr with the calculated hr? What to do?
			// observed calculated_hr's after things were up and running:
			// 26, 27, 28
			// so you'd need a median filter if you use that.
			bp = 7;
		}
	}

	// update previous time and event count

	if (ucPageNum != HRM_PAGE4) {
		usPreviousTime1024 = usTime1024;  // only if not previously obtained from HRM message
	}

	ucPreviousEventCount = ucEventCount;

	return 0;
}                 // int decode_hr()

/**************************************************************************************

	called from receiveByte at end of a valid packet

	sync byte
	msg length
	msg id
	data[length]
	(no checksum, (passed in) )

**************************************************************************************/

void ANTDEV::rxlog(bool _flush) {      // default flush is false
	if (!rxstream) {
		return;
	}

	int i, k, len;

#ifdef WIN32
	EnterCriticalSection(&critsec);
	sequence++;
	LeaveCriticalSection(&critsec);
#else
	sequence++;
#endif

	if (process_count == 0) {
		bp = 1;
	}

	//start_time = QDateTime::currentMSecsSinceEpoch();

	fprintf(rxstream, "%10ld %10lld rx  %02x %02x %02x ", sequence, QDateTime::currentMSecsSinceEpoch() - start_time, rxMessage[0], rxMessage[1], rxMessage[2]);

	len = rxMessage[1];

	for (i = 0; i < len; i++) {
		k = i + 3;
		fprintf(rxstream, "%02x ", rxMessage[k]);
	}
	k = i + 3;
	fprintf(rxstream, "%02x\n", rxMessage[k]);

	if (_flush) {
		fflush(rxstream);
	}

	return;
}                             // rxlog()

/********************************************************************************************************
		logs the RAW data from the ant stick
********************************************************************************************************/

void ANTDEV::rawlog(unsigned char *msg, int len, bool flush) {

	if (!rawstream) {
		return;
	}

	int i;

	for (i = 0; i < len; i++) {
		fprintf(rawstream, "%c", msg[i]);
	}
	fprintf(rawstream, "\n");

	if (flush) {
		fclose(rawstream);
		rawstream = fopen(RAWNAME, "a+t");           // raw.log
	}
	return;
}                    // rawlog

/********************************************************************************************************

********************************************************************************************************/

void ANTDEV::destroy(void) {

	stop();

	if (tx_calls > 0) {
		//logg("avg = %lf\n", total_tx_seconds / tx_calls);			// .3398
	}

	#ifdef _DEBUG
	if (txstream) {
		fclose(txstream);
		txstream = NULL;
	}
	if (rxstream) {
		fclose(rxstream);
		rxstream = NULL;
	}
	if (logstream) {
		fclose(logstream);
		logstream = NULL;
	}
	#endif

	FCLOSE(rawstream);
	return;
}                          // destroy(void)


/********************************************************************************************************

********************************************************************************************************/

int ANTDEV::stop(void) {

#ifdef ANTDEV_USES_QTIMER
	txtimer->stop();
	//delete(txtimer);
	//txtimer = NULL;
	txtimer->deleteLater();

	rxtimer->stop();
//	delete(rxtimer);
//	rxtimer = NULL;
	rxtimer->deleteLater();
#else
	if (dorx) {
		dorx = false;
		//if (txthread) txthread->join();
		delete(rxtimer);
		rxtimer = NULL;
	}

	if (dotx) {
		dotx = false;
		//if (txthread) txthread->join();
		delete(txtimer);
		txtimer = NULL;
	}
#endif

	if (handle) {
		libusb_close(handle);
		handle = NULL;
	}

	return 0;
}                                // stop()

/********************************************************************************************************

********************************************************************************************************/

int ANTDEV::set_devtype(int _chan_num, int _devtype) {
	//devtype = _devtype;
	int rc;

	if (_chan_num < 0 || _chan_num > 7) {
		return 2;
	}

	channels[_chan_num].devtype = _devtype;

	switch (channels[_chan_num].devtype) {
		case 121: {                   // speed/cadence
			rc = 0;
			channels[_chan_num].freq = 57;
			channels[_chan_num].period = 8086;
			channels[_chan_num].number = _chan_num;
			strcpy(channels[_chan_num].typestr, "Speed Cadence");
			break;
		}

		case 120: {                   // heartrate
			rc = 0;
			channels[_chan_num].freq = 57;
			channels[_chan_num].period = 8070;
			channels[_chan_num].number = _chan_num;
			strcpy(channels[_chan_num].typestr, "Heart Rate");
			break;
		}

		default: {
			rc = 1;
			break;
		}
	}

	return rc;
}                             // set_devtype()


/********************************************************************************************************

********************************************************************************************************/

int ANTDEV::set_period(int _chan_num, unsigned short _period) {

	if (_chan_num < 0 || _chan_num > 7) {
		return 2;
	}

	channels[_chan_num].period = _period;

	return 0;
}                                   // set_period()





/********************************************************************************************************
	called from get_channel()
********************************************************************************************************/

int ANTDEV::start_channel(int _chan) {
	int status;

	Q_UNUSED(status);

	//bool pair = true;


	if (_chan == -1) {
		return 1;
	}


	msgdone = false;
	status = send(ANTMsg::get_caps(_chan), false, _chan);
	if (!wait_for_message_completion(ANT_CAPABILITIES, MESSAGE_TIMEOUT)) {
		strcpy(error_string, "ANT get_caps failed.\n");
		return 1;
	}



	if ( ucAdvanced & CAPABILITIES_SERIAL_NUMBER_ENABLED ) {
		msgdone = false;
		status = send(ANTMsg::get_serial_number(_chan), false, _chan);
		if (!wait_for_message_completion(ANT_SERIAL_NUMBER, MESSAGE_TIMEOUT)) {
			strcpy(error_string, "ANT get_serial_number failed.\n");
			return 1;
		}

	}

	msgdone = false;
	status = send(ANTMsg::get_version(_chan), false, _chan);
	if (!wait_for_message_completion(ANT_VERSION, MESSAGE_TIMEOUT)) {
		strcpy(error_string, "ANT get_version failed.\n");
		return 1;
	}

	int type = 0;

	//xxx

	/*
		// Example Usage
		// Tx channel
		ANT_AssignChannel(0, 0x10, 0);
		// wait for RESPONSE_NO_ERROR
		ANT_SetChannelId(0, 1234, 120, 1);

		// Rx channel
		ANT_AssignChannel(0, 0x00, 0);
		// wait for RESPONSE_NO_ERROR
		ANT_SetChannelId(0, 0, 120, 1); // device number is wild-card

		// Pairing bit on Rx channel
		ANT_AssignChannel(0, 0x00, 0);
		// wait for RESPONSE_NO_ERROR
		ANT_SetChannelId(0, 0, 248, 1); // device number is wild-card, device type 120 with pairing bit ON
	 */


	/*
		9.5.2.2

		type:
		Bidirectional Channels:
			0x00  Receive Channel
			0x10 - Transmit Channel

		Unidirectional Channels:
			0x50  Transmit Only Channel
			0x40  Receive Only Channel

		Shared Channels:
			0x20  Shared Bidirectional Receive Channel
			0x30  Shared Bidirectional Transmit Channel

		net:
		Specifies the network to be used for this channel. Set this to 0, to use the default public network. See section 5.2.5 for more details.

	 */

	status = send(ANTMsg::assignChannel(_chan, type, net), false, _chan);               // const unsigned char channel, const unsigned char type, const unsigned char network
	if (!wait_event_ack(ANT_ASSIGN_CHANNEL, MESSAGE_TIMEOUT)) {
		strcpy(error_string, "assign channel failed\n");
		return 1;
	}

	if ( ucAdvanced & CAPABILITIES_PER_CHANNEL_TX_POWER_ENABLED ) {
		status = send(ANTMsg::setChannelTransmitPower(channels[_chan].number, 3), false, _chan);
		if (!wait_event_ack(ANT_CHANNEL_TX_POWER, MESSAGE_TIMEOUT)) {        // happens rarely
			strcpy(error_string, "set channel power failed\n");
			return 1;
		}
	}

	status = send(ANTMsg::setChannelFreq(_chan, channels[_chan].freq), false, _chan);         // happens
	if (!wait_event_ack(ANT_CHANNEL_FREQUENCY, MESSAGE_TIMEOUT)) {
		strcpy(error_string, "set channel frequency failed\n");
		return 1;
	}

	int txtype = 0;
	unsigned short devnum = 0;

	/*
		devnum:
			The device number. For a slave, use 0 to match any device number.

		.devtype:
			bit 7
				Pairing Request.
				Set this bit on master to request pairing
				Set this bit on slave to find a pairing transmitter.
			bits 0-6
				The device type. For a slave use 0 to match any device type
	 */

	//xxx
	msgdone = false;
	status = send(
		ANTMsg::setChannelID(
			_chan,
			devnum,                                   // The device number. For a slave, use 0 to match any device number.
			channels[_chan].devtype,
			txtype),
		false,
		_chan);              // unsigned char channel, unsigned short device, unsigned char devicetype, unsigned char txtype
	if (!wait_event_ack(ANT_CHANNEL_ID, MESSAGE_TIMEOUT)) {
		strcpy(error_string, "set channel ID failed\n");
		return 1;
	}

	status = send(ANTMsg::setChannelPeriod(_chan, channels[_chan].period), false, _chan);
	if (!wait_event_ack(ANT_CHANNEL_PERIOD, MESSAGE_TIMEOUT)) {
		strcpy(error_string, "set channel period failed\n");
		//logg("%s", error_string);
		return 1;
	}
	if (channel_event_ack != 0xff) {
		bp = 2;
	}
	if (gevent != 0x00) {
		bp = 3;
	}
	oktobreak = true;

	status = send(ANTMsg::open(_chan), false, _chan);
	if (channel_event_ack != 0xff) {
		bp = 2;
	}
	if (gevent != 0x00) {
		bp = 3;
	}

	if (!wait_event_ack(ANT_OPEN_CHANNEL, MESSAGE_TIMEOUT)) {
		strcpy(error_string, "open channel failed\n");
		//logg("%s", error_string);
		return 1;
	}

	msgdone = false;
	status = send(ANTMsg::get_channel_status(_chan), false, _chan);
	if (!wait_for_message_completion(ANT_CHANNEL_STATUS, MESSAGE_TIMEOUT)) {
		strcpy(error_string, "ANT reset failed.\n");
		return 1;
	}

	status = send(ANTMsg::set_extended_messages(_chan), false, _chan);                  // is this per channel?
	if (!wait_event_ack(ANT_ENABLE_EXT_MSGS, MESSAGE_TIMEOUT)) {
		strcpy(error_string, "setting extended messages failed\n");
		return 1;
	}

	msgdone = false;
	status = send(ANTMsg::get_channel_status(_chan), false, _chan);
	if (!wait_for_message_completion(ANT_CHANNEL_STATUS, MESSAGE_TIMEOUT)) {
		strcpy(error_string, "ANT_CHANNEL_STATUS failed.\n");
		return 1;
	}


	msgdone = false;
	status = send(ANTMsg::get_channel_id(_chan), false, _chan);
	if (!wait_for_message_completion(ANT_CHANNEL_ID, MESSAGE_TIMEOUT)) {
		strcpy(error_string, "ANT_CHANNEL_ID failed.\n");
		return 1;
	}
	bp = 0;

	return 0;
}                                // start_channel()			starts a channel

/********************************************************************************************************
	called ONLY from the receiver thread
	logs to antdev.log
	raw rx logging is in rx0.log or rx1.log

********************************************************************************************************/

void ANTDEV::plogg(const char *format, ...) {
	plogging = true;
	va_list ap;                                        // Argument pointer


#ifdef _DEBUG
	if (logstream) {
		if (logstream == txstream) {
			bp = 1;
		}
	}
	static int logs = 0;
	logs++;
#endif

	if (format == NULL) {
		plogging = false;
		return;
	}

#if 1
	va_start(ap, format);
	vsprintf(logstr, format, ap);
	va_end(ap);

	if (!logstream) {
		plogging = false;
		return;
	}

	fprintf(logstream, "%10lld  %s", QDateTime::currentMSecsSinceEpoch() - start_time, logstr);
	plogging = false;
	return;
#else
	plogging = false;
	return;
#endif

}                                // plogg()

/********************************************************************************************************

********************************************************************************************************/

void ANTDEV::start_logs(int _i) {
	char str[32];

	id = _i;

	sprintf(str, "antdev%d.log", id);
	logstream = fopen(str, "wt");

	sprintf(str, "tx%d.log", id);
	txstream = fopen(str, "wt");

	sprintf(str, "rx%d.log", id);
	rxstream = fopen(str, "wt");

#ifdef _DEBUG
	test();
#endif

	return;
}                             // start_log()


/******************************************************************************

******************************************************************************/

void ANTDEV::test(void) {

#ifdef _DEBUG
	if (logstream != NULL) {
		if (logstream == txstream) {
			bp = 1;
		}
	}
#endif

	return;
}

/******************************************************************************

******************************************************************************/

int ANTDEV::handle_channel_event(void) {
	//unsigned char msg;
	unsigned char channel, event, response;
	char str[256];

	channel = rxMessage[OFFS_CHAN];                    // offs_chan = 3
	event = rxMessage[OFFS_EVENT_ID];                  // offs_event_id = 4, pdf, pg 48, e id
	response = rxMessage[OFFS_EVENT_CODE];             // offs_event_code = 5, pdf, pg 48, e code, 0x28
	gevent = event;

#ifdef _DEBUG
	if (event == ANT_ASSIGN_CHANNEL) {
		bp = 1;
	}
#endif

	#ifdef _DEBUG
	strcpy(str, "opsy\n");
#ifdef WIN32
	DWORD tid = GetCurrentThreadId();
	assert(tid == rtid);
#endif
	#endif

	switch (event) {                                   // length is always 3
		case ANT_OPEN_CHANNEL: {                        // 0x4b
			#ifdef _DEBUG
			//sprintf(str, "process():\n   event: %s %d ANT_OPEN_CHANNEL %d\n", mfgr, channel, response);
			#endif
			assert(channel_event_ack == 0xff);
			channels[channel].open = true;
			break;
		}

		case ANT_ENABLE_EXT_MSGS:  {                    // 0x66
			//sprintf(str, "process():\n   event: %s %d ANT_ENABLE_EXT_MSGS %d\n", mfgr, channel, response);
			if (response == INVALID_MESSAGE) {
				extended = false;
			}
			else if (response != RESPONSE_NO_ERROR)
			{
				bp = 2;
			}
			else  {
				extended = true;
			}
			break;
		}

		case EVENT_RX_SEARCH_TIMEOUT:  {                // 0x01
			/*
				A receive channel has timed out on searching. The search is terminated, and the channel
				has been automatically closed.
				In order to restart the search the Open Channel message must be sent again.
			 */

			#ifdef _DEBUG
			if (response != 1 && response != 7) {
				//sprintf(str, "process():\n   event: %s, %d, EVENT_RX_SEARCH_TIMEOUT, %d\n", mfgr, channel, response);
			}
			else  {
				str[0] = 0;
			}
			#endif

			channels[channel].open = false;
			break;
		}

		case MESG_INVALID_ID: {                         // ((UCHAR)0x00)
			#ifdef _DEBUG
			//sprintf(str, "process():\n   event: %s %d MESG_INVALID_ID %d\n", mfgr, channel, response);
			#endif
			bp = 1;
			break;
		}

		case EVENT_TRANSFER_TX_FAILED: {             // 0x06
			#ifdef _DEBUG
			//sprintf(str, "process():\n   event: %s %d EVENT_TRANSFER_TX_FAILED %d\n", mfgr, channel, response);
			#endif
			bp = 1;
			break;
		}

		case MESG_NETWORK_KEY_ID: {                           // 0x46
			#ifdef _DEBUG
			//sprintf(str, "process():\n   event: %s %d MESG_NETWORK_KEY_ID %d\n", mfgr, channel, response);
			#endif
			break;
		}

		case ANT_ASSIGN_CHANNEL: {                            // 0x42
			#ifdef _DEBUG
			/*
				if (gevent != ANT_ASSIGN_CHANNEL)  {
				printf("ant_assign_channel error, gevent = %d\n", gevent);
				throw (fatalError(__FILE__, __LINE__, "ant_assign_channel error"));
				}
			 */
			//sprintf(str, "process():\n   event: %s %d ANT_ASSIGN_CHANNEL %d\n", mfgr, channel, response);
			#endif
			break;
		}

		case ANT_CHANNEL_ID: {                             // 0x51
			bp = 2;
			#ifdef _DEBUG
			//sprintf(str, "process():\n   event: %s %d ANT_CHANNEL_ID %d\n", mfgr, channel, response);
			#endif
			break;
		}

		case ANT_CHANNEL_PERIOD: {                      // 0x43
			#ifdef _DEBUG
			//sprintf(str, "process():\n   event: %s %d ANT_CHANNEL_PERIOD %d\n", mfgr, channel, response);
			#endif
			break;
		}

		case ANT_CHANNEL_FREQUENCY: {                               // 0x45
			#ifdef _DEBUG
			//sprintf(str, "process():\n   event: %s %d ANT_CHANNEL_FREQUENCY %d\n", mfgr, channel, response);
			#endif
			break;
		}

		case ANT_TX_POWER: {                                  // set device power, 0x47
			#ifdef _DEBUG
			//sprintf(str, "process():\n   event: %s %d ANT_TX_POWER %d\n", mfgr, channel, response);
			#endif
			break;
		}

		case ANT_CHANNEL_TX_POWER: {                          // set channel power, 0x60
			#ifdef _DEBUG
			//sprintf(str, "process():\n   event: %s %d ANT_CHANNEL_TX_POWER %d\n", mfgr, channel, response);
			bp = 0;
			#endif
			break;
		}

		case EVENT_TRANSFER_TX_COMPLETED: {                      // 0x05
			#ifdef _DEBUG
			//sprintf(str, "process():\n   event: %s %d EVENT_TRANSFER_TX_COMPLETED %d\n", mfgr, channel, response);
			#endif
			break;
		}

		default: {
			#ifdef _DEBUG
			//sprintf(str, "process():\n   event: %s %d / %d / %d ?????????????????????\n", mfgr, channel, event, response);
			bp = 2;
			#endif
			break;
		}
	}                                                  // switch(event)  {

#ifdef _DEBUG
	//while(plogging) {} plogg("%s", str);
#endif
	channel_event_ack = response;
	return 0;
}                                      // handle_channnel_event()

/********************************************************************************************************

********************************************************************************************************/

int ANTDEV::pair_channel(int _chan) {
	int status;

	Q_UNUSED(status);

	//bool pair = true;


	if (_chan == -1) {
		return 1;
	}


	msgdone = false;
	status = send(ANTMsg::get_caps(_chan), false, _chan);
	if (!wait_for_message_completion(ANT_CAPABILITIES, MESSAGE_TIMEOUT)) {
		strcpy(error_string, "ANT get_caps failed.\n");
		return 1;
	}

	if ( ucAdvanced & CAPABILITIES_SERIAL_NUMBER_ENABLED ) {
		msgdone = false;
		status = send(ANTMsg::get_serial_number(_chan), false, _chan);
		if (!wait_for_message_completion(ANT_SERIAL_NUMBER, MESSAGE_TIMEOUT)) {
			strcpy(error_string, "ANT get_serial_number failed.\n");
			return 1;
		}

	}

	msgdone = false;
	status = send(ANTMsg::get_version(_chan), false, _chan);
	if (!wait_for_message_completion(ANT_VERSION, MESSAGE_TIMEOUT)) {
		strcpy(error_string, "ANT get_version failed.\n");
		return 1;
	}

	//xxx

	/*
		// Example Usage
		// Tx channel
		ANT_AssignChannel(0, 0x10, 0);
		// wait for RESPONSE_NO_ERROR
		ANT_SetChannelId(0, 1234, 120, 1);

		// Rx channel
		ANT_AssignChannel(0, 0x00, 0);
		// wait for RESPONSE_NO_ERROR
		ANT_SetChannelId(0, 0, 120, 1); // device number is wild-card

		// Pairing bit on Rx channel
		ANT_AssignChannel(0, 0x00, 0);
		// wait for RESPONSE_NO_ERROR
		ANT_SetChannelId(0, 0, 248, 1); // device number is wild-card, device type 120 with pairing bit ON
	 */


	/*
		9.5.2.2

		type:
		Bidirectional Channels:
			0x00  Receive Channel
			0x10 - Transmit Channel

		Unidirectional Channels:
			0x50  Transmit Only Channel
			0x40  Receive Only Channel

		Shared Channels:
			0x20  Shared Bidirectional Receive Channel
			0x30  Shared Bidirectional Transmit Channel

		net:
		Specifies the network to be used for this channel. Set this to 0, to use the default public network. See section 5.2.5 for more details.

	 */

	int type = 0;

	status = send(ANTMsg::assignChannel(_chan, type, net), false, _chan);               // const unsigned char channel, const unsigned char type, const unsigned char network
	if (!wait_event_ack(ANT_ASSIGN_CHANNEL, MESSAGE_TIMEOUT)) {
		strcpy(error_string, "assign channel failed\n");
		return 1;
	}

	if ( ucAdvanced & CAPABILITIES_PER_CHANNEL_TX_POWER_ENABLED ) {
		status = send(ANTMsg::setChannelTransmitPower(channels[_chan].number, 3), false, _chan);
		if (!wait_event_ack(ANT_CHANNEL_TX_POWER, MESSAGE_TIMEOUT)) {        // happens rarely
			strcpy(error_string, "set channel power failed\n");
			return 1;
		}
	}

	status = send(ANTMsg::setChannelFreq(_chan, channels[_chan].freq), false, _chan);         // happens
	if (!wait_event_ack(ANT_CHANNEL_FREQUENCY, MESSAGE_TIMEOUT)) {
		strcpy(error_string, "set channel frequency failed\n");
		return 1;
	}

	int txtype = 0;
	unsigned short devnum = 0;

	/*
		devnum:
			The device number. For a slave, use 0 to match any device number.

		.devtype:
			bit 7
				Pairing Request.
				Set this bit on master to request pairing
				Set this bit on slave to find a pairing transmitter.
			bits 0-6
				The device type. For a slave use 0 to match any device type
	 */

	//xxx
	msgdone = false;
	status = send(
		ANTMsg::setChannelID(
			_chan,
			devnum,                                   // The device number. For a slave, use 0 to match any device number.
			channels[_chan].devtype,
			txtype),
		false,
		_chan);              // unsigned char channel, unsigned short device, unsigned char devicetype, unsigned char txtype
	if (!wait_event_ack(ANT_CHANNEL_ID, MESSAGE_TIMEOUT)) {
		strcpy(error_string, "set channel ID failed\n");
		return 1;
	}

	status = send(ANTMsg::setChannelPeriod(_chan, channels[_chan].period), false, _chan);
	if (!wait_event_ack(ANT_CHANNEL_PERIOD, MESSAGE_TIMEOUT)) {
		strcpy(error_string, "set channel period failed\n");
		//logg("%s", error_string);
		return 1;
	}
	if (channel_event_ack != 0xff) {
		bp = 2;
	}
	if (gevent != 0x00) {
		bp = 3;
	}
	oktobreak = true;

	status = send(ANTMsg::open(_chan), false, _chan);
	if (channel_event_ack != 0xff) {
		bp = 2;
	}
	if (gevent != 0x00) {
		bp = 3;
	}

	if (!wait_event_ack(ANT_OPEN_CHANNEL, MESSAGE_TIMEOUT)) {
		strcpy(error_string, "open channel failed\n");
		//logg("%s", error_string);
		return 1;
	}

	msgdone = false;
	status = send(ANTMsg::get_channel_status(_chan), false, _chan);
	if (!wait_for_message_completion(ANT_CHANNEL_STATUS, MESSAGE_TIMEOUT)) {
		strcpy(error_string, "ANT reset failed.\n");
		return 1;
	}

	status = send(ANTMsg::set_extended_messages(_chan), false, _chan);                  // is this per channel?
	if (!wait_event_ack(ANT_ENABLE_EXT_MSGS, MESSAGE_TIMEOUT)) {
		strcpy(error_string, "setting extended messages failed\n");
		return 1;
	}

	msgdone = false;
	status = send(ANTMsg::get_channel_status(_chan), false, _chan);
	if (!wait_for_message_completion(ANT_CHANNEL_STATUS, MESSAGE_TIMEOUT)) {
		strcpy(error_string, "ANT_CHANNEL_STATUS failed.\n");
		return 1;
	}


	msgdone = false;
	status = send(ANTMsg::get_channel_id(_chan), false, _chan);
	if (!wait_for_message_completion(ANT_CHANNEL_ID, MESSAGE_TIMEOUT)) {
		strcpy(error_string, "ANT_CHANNEL_ID failed.\n");
		return 1;
	}
	bp = 0;

	return 0;
}                                // pair_channel()

/********************************************************************************************************

********************************************************************************************************/

int ANTDEV::set_device(libusb_device *_device) {
	//int ANTDEV::set_desc(libusb_device_descriptor _desc)  {
	int status;
	int rc = 0;
	char str[256];

	device = _device;

	status = libusb_get_device_descriptor(device, &desc);       // desc.idVendor, desc.idProduct
	if (status != 0) {
		rc = status;
		goto finis;
	}

	status = libusb_open(device, &handle);    // Open a device and obtain a device handle

	switch (status) {
		case 0: {                  // on success
			break;
		}
		case LIBUSB_ERROR_NO_MEM:           // -11	on memory allocation failure
		case LIBUSB_ERROR_ACCESS:           // -3		if the user has insufficient permissions
		case LIBUSB_ERROR_NO_DEVICE: {      // -4		if the device has been disconnected
			rc = status;
			goto finis;
		}
		default:
			rc = status;
			goto finis;
	}

	pid = desc.idProduct;
	vid = desc.idVendor;
	nconfigs = desc.bNumConfigurations;

	status = libusb_get_string_descriptor_ascii(handle, desc.iManufacturer, (unsigned char*)str, sizeof(str) - 1);
	strncpy(mfgr, str, sizeof(mfgr) - 1);

	status = libusb_get_string_descriptor_ascii(handle, desc.iProduct, (unsigned char*)str, sizeof(str) - 1);
	strncpy(prod, str, sizeof(prod) - 1);

	status = libusb_get_string_descriptor_ascii(handle, desc.iSerialNumber, (unsigned char*)sn, sizeof(sn));
	strncpy(serial_number, str, sizeof(serial_number) - 1);


finis:
	return rc;
}                             // set_device()

/********************************************************************************************************

********************************************************************************************************/

int ANTDEV::start(void) {
	int status;


	channel_event_ack = 0xff;

#ifdef ANTDEV_USES_QTIMER
	bool b;

	if (somethread==NULL)  {

		somethread = new QThread(this);
		if (txtimer == NULL) {
			txtimer = new QTimer(0);
			txtimer->setInterval(333);
			txtimer->moveToThread(somethread);
			b = (bool)connect(txtimer, SIGNAL(timeout()), this, SLOT(writer(void)), Qt::DirectConnection);
			Q_ASSERT(b);
			b = (bool)QObject::connect(somethread, SIGNAL(started()), txtimer, SLOT(start()));
			Q_ASSERT(b);
			//b = connect(somethread, SIGNAL(started()), txtimer, SLOT(start()));
			//Q_ASSERT(b);
		}

		if (rxtimer == NULL) {
			rxtimer = new QTimer(0);
			rxtimer->setInterval(350);
			rxtimer->moveToThread(somethread);
			b = (bool)connect(rxtimer, SIGNAL(timeout()), this, SLOT(reader(void)), Qt::DirectConnection);
			Q_ASSERT(b);
			b = (bool)QObject::connect(somethread, SIGNAL(started()), rxtimer, SLOT(start()));
			Q_ASSERT(b);
		}
		//status = somethread->exec();			// protected
		somethread->start();
	}

while(1)  {
	QThread::msleep(10);
}
#else
	if (dotx == false) {
		dotx = true;
		txtimer = new QThread();
	}
	if (dorx == false) {
		dorx = true;
		rxtimer = new QThread();
	}
#endif


	msgdone = false;
	status = send(ANTMsg::resetSystem(), false);



	assert(status == 0);
	if (!wait_for_message_completion(MESG_STARTUP_MESG_ID, MESSAGE_TIMEOUT)) {             // waits up to 3.3 seconds
		strcpy(error_string, "ANT reset failed.\n");
		return 1;
	}
	//Sleep(750);					// specs say wait 500ms after reset before sending any more host commands
	QThread::msleep(750);               // specs say wait 500ms after reset before sending any more host commands
	// don't logg in start() or anything that it calls because it will interfere with the trheads logging
	//logg("%s reset ANT OK\n", mfgr);

	status = send(ANTMsg::setNetworkKey(net, key), false);
	if (!wait_event_ack(MESG_NETWORK_KEY_ID, MESSAGE_TIMEOUT)) {
		strcpy(error_string, "SetNetworkKey failed 2.\n");
		//logg("%s", error_string);
		return 1;
	}

	return 0;

}                          // start(void)  {			starts the device only


#ifdef ANTDEV_USES_QTIMER


/**************************************************************************************************

**************************************************************************************************/

void ANTDEV::writer(void) {
	unsigned char wep;                        // read endpoint
	unsigned short len;
	int status;


	bp = 0;
	wep = 0x01;                            // read from address 1
	Q_UNUSED(wep);

	if (txinptr != txoutptr) {
		len = txinptr - txoutptr;
		len &= (TXBUFLEN - 1);
		status = tx(&txq[txoutptr], len, 500L);
		if (status != len) {
			bp = 2;
		}
		txoutptr = (txoutptr + len) % TXBUFLEN;
	}
	return;
}                                               // writer()

/**************************************************************************************************
	Thread function: Thread ID
	loads stuff into rxq and advances the rxinptr
**************************************************************************************************/

void ANTDEV::reader(void) {
	int status;

	status = rx();
	switch (status) {
		case 0: {
			bp = 1;
			break;
		}

		case LIBUSB_ERROR_TIMEOUT: {                             // timeout
			bp = 2;
			break;
		}

		case LIBUSB_ERROR_PIPE: {              // if the endpoint halted -9
			bp = 2;
			break;
		}

		case LIBUSB_ERROR_OVERFLOW: {          // if the device offered more data, see Packets and overflows, -8
			bp = 2;
			break;
		}

		case LIBUSB_ERROR_NO_DEVICE: {         // if the device has been disconnected, -4
			bp = 2;
			break;
		}

		case LIBUSB_ERROR_IO: {                // Device or resource busy
			bp = 2;
			break;
		}

		default:  {
			// normally returns the number of bytes received
			if (status < 0) {
				printf("ANTDEV::reader() status = %d\n", status);
			}
			// new data in queue
			//process();

			int i, j, len;

			i = rxinptr - rxoutptr;
			len = i & (RXBUFLEN - 1);

			#ifdef _DEBUG
			if (status != len) {
				bp = 2;
			}
			#endif
			bp = 1;

			for (i = 0; i < len; i++) {
				j = (rxoutptr + i) % RXBUFLEN;
				receiveByte(rxq[j]);
			}
			rxoutptr = (rxoutptr + len) % RXBUFLEN;

			bp = 99;
			break;
		}
	}

	return;
}                                               // reader()

#else


/**************************************************************************************************

**************************************************************************************************/

void ANTDEV::writer(void) {
	int status;
	//int n;
	unsigned char wep;                        // read endpoint
	unsigned long timeout;                    //in milliseconds
	unsigned short len;

	//ANTDEV *ad = (ANTDEV *) arg;
	//ANTDEV *ad = this;

	bp = 0;
	wep = 0x01;                            // read from address 1
	Q_UNUSED(wep);

	timeout = 333;
	txoutptr = 0;

	while (dotx) {
		QThread::msleep(timeout);

		if (txinptr != txoutptr) {
			len = txinptr - txoutptr;
			len &= (TXBUFLEN - 1);
			status = tx(&txq[txoutptr], len, 500L);
			if (status != len) {
				bp = 2;
			}
			txoutptr = (txoutptr + len) % TXBUFLEN;
		}
	}

	//logg("\nending write thread\n");

	return;
}                                               // writer()

/**************************************************************************************************

**************************************************************************************************/

void ANTDEV::reader(void) {
	//unsigned char rep;								// read endpoint
	unsigned long timeout;                             //in milliseconds
	int status;

	//ANTDEV *ad = (ANTDEV *) arg;
	ANTDEV *ad = this;

#ifdef WIN32
	rtid = GetCurrentThreadId();
#endif

	ad->bp = 0;
	//rep = 0x81;										// read from address 1
	timeout = 350;
	ad->rxinptr = 0;


	while (!ad->initialized) {
		//Sleep(10);									// unix version is in glib_defines.h
		QThread::msleep(10);
	}

	//Sleep(100);
	QThread::msleep(100);

	ad->bp = 1;
	while (ad->plogging) {
	}
	ad->plogg("\n");

	while (ad->dorx) {
		//Sleep(timeout);
		QThread::msleep(timeout);

		status = ad->rx();
		switch (status) {
			case 0: {
				ad->bp = 1;
				break;
			}

			case LIBUSB_ERROR_TIMEOUT: {                          // timeout
				ad->bp = 2;
				break;
			}

			case LIBUSB_ERROR_PIPE: {           // if the endpoint halted -9
				ad->bp = 2;
				break;
			}

			case LIBUSB_ERROR_OVERFLOW: {       // if the device offered more data, see Packets and overflows, -8
				ad->bp = 2;
				break;
			}

			case LIBUSB_ERROR_NO_DEVICE: {      // if the device has been disconnected, -4
				ad->bp = 2;
				break;
			}

			case LIBUSB_ERROR_IO: {             //
				ad->bp = 2;
				break;
			}

			default:  {
				// normally returns the number of bytes received
				if (status < 0) {
					printf("ANTDEV::reader() status = %d\n", status);
				}
				// new data in queue
				//process();

				int i, j, len;

				i = ad->rxinptr - ad->rxoutptr;
				len = i & (RXBUFLEN - 1);

	#ifdef _DEBUG
				if (status != len) {
					ad->bp = 2;
				}
	#endif
				ad->bp = 1;

				for (i = 0; i < len; i++) {
					j = (ad->rxoutptr + i) % RXBUFLEN;
					ad->receiveByte(ad->rxq[j]);
				}
				ad->rxoutptr = (ad->rxoutptr + len) % RXBUFLEN;

				ad->bp = 99;
				break;
			}
		}
	}

	//ad->logg("ending read thread\n");

	return;
}                                               // reader()

#endif

