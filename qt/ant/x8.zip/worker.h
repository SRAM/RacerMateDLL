
#ifndef _WORKER_H_
#define _WORKER_H_
#include "antdev.h"



#ifdef WORKER_OWNS_DEVICES

//#define WORKER_TIMER


#include <QtCore>
#include <tmr.h>


namespace RACERMATE  {


class ANT;

class Worker : public QObject  {
	Q_OBJECT

	friend class ANT;

	public:
		 Worker(int _debug_level, QObject* parent = 0);
		// don't use a destructor!!! use the stop() slot instead

	private:
		//QObject *parent = NULL;
#ifdef WORKER_TIMER
		QTimer *timer = NULL;
#endif

		Tmr *tmr = NULL;
		int ticks = 0;
		int debug_level = 0;
		//RACERMATE::SDIRS *sdirs=NULL;
		FILE *logstream = NULL;
		char logname[256] = {0};
#ifdef _DEBUG
		int bp = 0;
#endif

	public slots:
		void start();
		void stop();

	private slots:
#ifdef WORKER_TIMER
		void timeout_slot();
#endif

	signals:
		void finished();
};

}				// namespace RACERMATE
#endif		// #ifdef WORKER_OWNS_DEVICES

#endif

