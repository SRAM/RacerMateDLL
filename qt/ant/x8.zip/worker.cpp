
#include "worker.h"


#include "ant.h"

namespace RACERMATE  {

#ifdef WORKER_OWNS_DEVICES

/**************************************************************************

**************************************************************************/

Worker::Worker(int _debug_level, QObject* _parent ) : QObject(_parent) {
	debug_level = _debug_level;
	//parent = _parent;

	int status;

	tmr = new Tmr("W");

	if (debug_level > 0) {
		RACERMATE::SDIRS *sdirs = new RACERMATE::SDIRS(debug_level, "rmant");
		status = sdirs->get_rc();
		switch(status)  {
			case 0:
				break;
			case -1:
				throw("sdirs error 1");			// ctsrv catches this
			case -2:
				throw("sdirs error 2");			// ctsrv catches this
			case -3:
				throw("sdirs error 3");			// ctsrv catches this
			default:
				throw("sdirs error 101");		// ctsrv catches this
		}

		QString s = sdirs->get_debug_dir() + "worker.log";
		DEL(sdirs);

		strncpy(logname, s.toUtf8().constData(), sizeof(logname)-1);
		logstream = fopen(logname, "wt");
		QDateTime dt = QDateTime::currentDateTime();
		s = dt.toString("yyyy-MM-dd-hh-mm-ss");
		fprintf(logstream, "%s starting at %s, debug_level = %d\n\n", logname, s.toUtf8().constData(), debug_level);
		fflush(logstream);
	}           // if (debug_level > 0)

#ifdef WORKER_TIMER
	timer = new QTimer(this);
	timer->setInterval(100);
	connect(timer, SIGNAL(timeout()), this, SLOT(timeout_slot()));             // , Qt::DirectConnection, prepareResult()
#endif

	return;
}                    // constructor()


#ifdef WORKER_TIMER

/**************************************************************************

**************************************************************************/

void Worker::timeout_slot() {                  // see prepareResult(), trackshun

#ifdef _DEBUG
	//tmr->update();									// 100 ms
#endif
	ticks++;

	if (ticks < 30)  {								// every 3000 ms
		return;
	}

	ticks = 0;

//	ANTDEV *device;
//	ANT *ant;

//	ant = (ANT *)parent;

//	if (ant)  {
//		if (ant->devices.size()==0)  {
//			return;
//		}

//		device = ant->devices.first();

//		if (!device->is_listening())  {
//			int status;
//			Q_UNUSED(status);
//			status = device->open_listening_channel();
//		}
//	}

	return;
}                    // timeout_slot()

#endif

/**************************************************************************

**************************************************************************/

void Worker::start() {
	if (QThread::currentThread() != thread()) {
		QMetaObject::invokeMethod(this, "start");
		return;
	}


#ifdef WORKER_TIMER
	#ifdef _DEBUG
		//qDebug() << "      Worker::start(): calling m_timer->start()";
	#endif
	if (timer) {
		timer->start();
	}
#endif

}                       // start() slot

/**************************************************************************
	don't do this in a destructor!!!!!
**************************************************************************/

void Worker::stop() {
	if (QThread::currentThread() != thread()) {
		QMetaObject::invokeMethod(this, "stop");
		return;
	}

#ifdef WORKER_TIMER
	if (timer) {
		timer->stop();
	}
#endif

#ifdef _DEBUG
	if (tmr)  {
		tmr->setdbg();			// causes Tmr to print update results
	}
#endif

	DEL(tmr);
	//DEL(sdirs);

	FCLOSE(logstream);

	emit finished();
}           // stop() slot
#endif			// #ifdef WORKER_OWNS_DEVICES

}           // namespace RACERMATE


