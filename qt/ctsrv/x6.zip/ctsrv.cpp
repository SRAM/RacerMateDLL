
#include "worker.h"
#include "ctsrv.h"

	#include <QNetworkInterface>
	#include <QNetworkAddressEntry>
	#include <QHostInfo>

	#ifdef WIN32
	#include <assert.h>
	#endif

	#include <comutils.h>

namespace RACERMATE  {

Ctsrv* Ctsrv::m_instance = 0;
//QCoreApplication* Ctsrv::m_application = NULL;


/**********************************************************************

**********************************************************************/

Ctsrv::Ctsrv(int _listen_port, int _broadcast_port, int _debug_level, QObject *_parent) : QObject(_parent) {
		Q_ASSERT(!m_instance);
		m_instance = this;

		debug_level = _debug_level;
		parent = _parent;
#ifdef _DEBUG
	qDebug() << "   Ctsrv(): tid = " << QThread::currentThreadId();
#endif

		int argc = 1;
		//m_application = qApp ? 0 : new QCoreApplication(argc, 0);

		if (qApp)  {
			m_application = 0;
			qDebug() << "   qApp exists, so m_application set to 0";
		}
		else  {
			m_application = new QCoreApplication(argc, 0);
			qDebug() << "   qApp is 0, so creating a QCoreApplication";
		}

		m_workerThread = new QThread(this);

#ifdef _DEBUG
		qDebug() << "   Ctsrv() creating worker";
#endif
		m_worker = new Worker(_listen_port, _broadcast_port, debug_level);
#ifdef _DEBUG
		qDebug() << "   Ctsrv(): moving worker to workerThread";
#endif
		m_worker->moveToThread(m_workerThread);

		connect(m_workerThread, SIGNAL(started()), m_worker, SLOT(start()));
		connect(m_worker, SIGNAL(resultReady(QString)), SLOT(handleResults(QString)), Qt::DirectConnection);
		connect(m_worker, SIGNAL(finished()), m_workerThread, SLOT(quit()));

#ifdef _DEBUG
		qDebug() << "   Ctsrv(): starting worker thread";
#endif
		m_workerThread->start();

		logstream = 0;
		memset(&ssd, 0, sizeof(ssd));

#ifdef _DEBUG
		//qDebug() << "Ctsrv returning from constructor";
#endif

	}


/**********************************************************************
	destructor
**********************************************************************/

Ctsrv::~Ctsrv() {
	bool dbg;

#ifdef _DEBUG
	dbg = true;
#else
	dbg = false;
#endif
			QString s;

	if (dbg)  {
		qDebug() << "   ~Ctsrv()";
	}

	if (dbg)  {
		s = m_application?"m_application exists":"m_application is 0";

		if (qApp)  {
			qDebug() << "   qApp is NOT 0";
		}
		else  {
			qDebug() << "   qApp is 0";
		}
		qDebug() << "   ~Ctsrv(): connecting m_workerThread finished signal to eventLoop quit() slot, " << s;
	}


	QEventLoop eventLoop;

		if (dbg)  {
			qDebug() << "   ~Ctsrv(): calling m_worker->stop()";
		}

	m_worker->stop();			// <<<<<<<  QEventLoop: Cannot be used without QApplication


			if (dbg)  {
				qDebug() << "   ~Ctsrv(): back from m_worker->stop()";
			}



	// Wait worker and it's thread to finish gracefully
	connect(m_workerThread, SIGNAL(finished()), &eventLoop, SLOT(quit()));
			if (dbg)  {
				qDebug() << "   ~Ctsrv(): calling eventLoop.exec(), " << s;
			}
	eventLoop.exec();

			if (dbg)  {
				qDebug() << "   ~Ctsrv(): back from eventLoop.exec()";
			}

		//#ifdef _DEBUG
		//QThread::msleep(1000);			// ???
		//#endif

	delete m_worker;

			#ifdef _DEBUG
			qDebug() << "   ~Ctsrv(): 1";
			#endif

	if (m_application)  {
			if (dbg)  {
					qDebug() << "   ~Ctsrv(): deleting m_application";
				}
		delete m_application;
				#ifdef _DEBUG
				qDebug() << "   ~Ctsrv(): 2";
				#endif
		m_application = 0;
	}

	m_instance = 0;

	if (logstream)  {
		fclose(logstream);
		logstream = 0;
	}
	bp = 0;

		#ifdef _DEBUG
		qDebug() << "   ~Ctsrv() tid = " << QThread::currentThreadId();
		qDebug() << "   ~Ctsrv() finished";
		#endif

}					// ~Ctsrv()

#if 0
/**********************************************************************

**********************************************************************/

void Ctsrv::gradechanged_slot(int _ix, int _igradex10)  {
	//emit(gradechanged_signal(_ix, _igradex10));
	//int ix = _ix - UDP_SERVER_SERIAL_PORT_BASE + 1;

	if (m_worker->udpclients[_ix])  {
		//bp = 2;
		m_worker->udpclients[_ix]->set_grade(_igradex10);
	}
	return;
}

/**********************************************************************

**********************************************************************/

void Ctsrv::windchanged_slot(int _ix, float _wind)  {
	//emit(gradechanged_signal(_ix, _igradex10));
	//int ix = _ix - UDP_SERVER_SERIAL_PORT_BASE + 1;

	if (m_worker->udpclients[_ix])  {
		m_worker->udpclients[_ix]->set_wind(_wind);
	}
	return;
}
#endif


/**********************************************************************

**********************************************************************/

void Ctsrv::data_slot(int _ix, RACERMATE::QT_DATA *_data)  {
	emit(data_signal(_ix, _data));
	return;
}

/**********************************************************************

**********************************************************************/

void Ctsrv::ss_slot(int _ix, RACERMATE::qt_SS::SSD *_ssd)  {
		emit(ss_signal(_ix, _ssd));
		return;
	}


/**********************************************************************

**********************************************************************/

void Ctsrv::rescale_slot(int _ix, int _maxforce)  {
	emit(rescale_signal(_ix, _maxforce));
	return;
}

/**********************************************************************
	client slot
**********************************************************************/

void Ctsrv::connected_to_trainer_slot(int _id, bool _b)  {

	//xxx

#ifdef _DEBUG
	if (_b==false)  {
		bp = 3;
	}
#endif

	emit connected_to_trainer_signal(_id, _b);
	return;
}


/**********************************************************************

***********************************************************************/

void Ctsrv::logg(bool _print, const char *format, ...) {
		int len;

		len = (int)strlen(format);
		if (len > 1023) {
				if (_print) {
						qDebug() << "string too long in logg()";
					}
				if (logstream) {
						fprintf(logstream, "\r\n(string too long in logg())\r\n");
						//fflush(logstream);
					}
				return;
			}


		return;
	}                                      // logg()

/**********************************************************************

**********************************************************************/

qint32 ArrayToInt(QByteArray source) {
		qint32 temp;
		QDataStream data(&source, QIODevice::ReadWrite);

		data >> temp;
		return temp;
	}                       // ArrayToInt()



/**********************************************************************

**********************************************************************/

qt_SS::BARINFO *Ctsrv:: get_barinfo(int i) {
		//Q_UNUSED(i);
		//return udpclients[0]->ss->get_barinfo(i);
		return m_worker->get_barinfo(i);
//		return 0;
	}                          // get_barinfo(int i)

/**********************************************************************

**********************************************************************/

void Ctsrv::setStarted(int _ix, bool _value) {
	Q_UNUSED(_ix);
	Q_UNUSED(_value);
	return;
}

/**********************************************************************

**********************************************************************/

void Ctsrv::setFinished(int _ix, bool _value) {
	Q_UNUSED(_ix);
	Q_UNUSED(_value);
	return;
}

/**********************************************************************

**********************************************************************/

void Ctsrv::setPaused(int _ix, bool _paused) {
	//Q_UNUSED(value);
	int ix = _ix - UDP_SERVER_SERIAL_PORT_BASE + 1;
	if (ix < 0)  {
		ix = _ix;
	}

#if MAXCLIENTS==1
		if (m_worker->udpclients[ix]) {
			m_worker->udpclients[ix]->set_paused(_paused);
		}
#else
	if (m_worker->udpclients[ix]) {
		m_worker->udpclients[ix]->set_paused(_paused);
	}

#endif

	return;

}

/**********************************************************************

**********************************************************************/

void Ctsrv::doSomeOtherStuff(int value)  {
		QMutexLocker locker(&m_accessMutex);								// Prevent calling following code from different threads simultaneously
		qDebug() << "Doing some other stuff..." << value;
	}


// added for non-qt testing jan 4, 2016 (rm1 compatibility)

/*********************************************************************************************************************************

*********************************************************************************************************************************/

struct TrainerData Ctsrv::GetTrainerData(int _ix, int _fw)  {
	Q_UNUSED(_fw);

	int ix = _ix - UDP_SERVER_SERIAL_PORT_BASE + 1;
	if (ix < 0)  {
		ix = _ix;
	}

	if (m_worker->udpclients[ix])  {
#ifdef DOITTOTHEMAX
		td = udpclients[ix]->GetTrainerData(_fw);
#else
		td = m_worker->udpclients[ix]->GetTrainerData(_fw);
#endif
	}
	else  {
		memset(&td, 0, sizeof(td));
	}

	return td;

}


/*********************************************************************************************************************************

*********************************************************************************************************************************/

int Ctsrv::reset_client(int _ix)  {
	int ix = _ix - UDP_SERVER_SERIAL_PORT_BASE + 1;
	if (ix < 0)  {
		ix = _ix;
	}

	if (m_worker->udpclients[ix])  {
		m_worker->udpclients[ix]->reset();
		return 0;
	}
	return 1;
}


/*********************************************************************************************************************************

*********************************************************************************************************************************/

int Ctsrv::rx(int _ix, unsigned char *buf, int buflen)  {
	//Q_UNUSED(_ix);
	//Q_UNUSED(buf);
	//Q_UNUSED(buflen);
	int ix;

	//if (m_worker->udpclients) {
	if (1)  {
		ix = _ix - UDP_SERVER_SERIAL_PORT_BASE;
		if (m_worker->udpclients[ix]) {

//			int status;
//			status = m_worker->udpclients[ix]->rx(buf, buflen);
			m_worker->udpclients[ix]->rx(buf, buflen);

			//bp = 1;
		}
	}

	return 0;
}

/*********************************************************************************************************************************

*********************************************************************************************************************************/

int Ctsrv::send(int _ix, const unsigned char *_str, int _len, bool _flush)  {
	//int i=0;
	//int ix;
	//int n;
	//unsigned char c;
	Q_UNUSED(_ix);
	Q_UNUSED(_str);
	Q_UNUSED(_len);
	Q_UNUSED(_flush);


	/*
	ix = _ix + 1 - SERVER_SERIAL_PORT_BASE;
	n = (int)tcpclients.size();

	if (ix >= n)  {
		return 0;
	}

	tcpclients[ix].mysend(_str, _len, _flush);
	*/

	return 0;
}

/*********************************************************************************************************************************

*********************************************************************************************************************************/

int Ctsrv::set_ergo_mode(int _ix, int _fw, int _rrc, float _manwatts)  {
	//int ix = _ix - UDP_SERVER_SERIAL_PORT_BASE + 1;				// rm1 compatible
	int status = -1;
	int ix = _ix - UDP_SERVER_SERIAL_PORT_BASE + 1;
	if (ix < 0)  {
		ix = _ix;
	}

	if (m_worker->udpclients[ix]) {
		status = m_worker->udpclients[ix]->set_ergo_mode(_fw, _rrc, _manwatts);
	}

	return status;

}

/*********************************************************************************************************************************

*********************************************************************************************************************************/

void Ctsrv::set_export(int _ix, const char *_dbgfname)  {
	int ix = _ix - UDP_SERVER_SERIAL_PORT_BASE + 1;

	if (m_worker->udpclients[ix]) {
		m_worker->udpclients[ix]->set_export(_dbgfname);
	}
	return;
}

/*********************************************************************************************************************************

*********************************************************************************************************************************/

void Ctsrv::set_file_mode(int _ix, bool _mode)  {
	int ix = _ix - UDP_SERVER_SERIAL_PORT_BASE + 1;
	if (ix < 0)  {
		ix = _ix;
	}

	if (m_worker->udpclients[ix])  {
		m_worker->udpclients[ix]->set_file_mode(_mode);
	}

	return;
}


/*********************************************************************************************************************************

*********************************************************************************************************************************/

bool Ctsrv::client_is_running(int _ix)  {
	int ix = _ix - UDP_SERVER_SERIAL_PORT_BASE + 1;
	if (ix < 0)  {
		ix = _ix;
	}

	if (m_worker->udpclients[ix]) {
		return true;
	}
	return false;
}


/*********************************************************************************************************************************

*********************************************************************************************************************************/

int Ctsrv::expect(int _ix, const char *_str, DWORD _timeout)  {
	//Q_UNUSED(_ix);
	//Q_UNUSED(str);
	//Q_UNUSED(timeout);

	int len,i=0;
	unsigned char c[8];
	DWORD start,end;
	int n;

	len = (int)strlen(_str);

	start = getms();

	while(1)  {
		n = rx(_ix, c, 1);

		if (n==1)  {
			if (c[0]==_str[i])  {
				i++;
				if (i==len)  {
					return 0;
				}
			}
			else  {
				i = 0;
			}
		}
		else  {
			end = getms();
			if ((end-start)>_timeout)  {
				return 1;
			}
		}
	}

	return 1;

	return 0;
}

/*********************************************************************************************************************************

*********************************************************************************************************************************/

float *Ctsrv::get_average_bars(int _ix)  {
	//Q_UNUSED(_ix);
	//return nullptr;
	int ix = _ix - UDP_SERVER_SERIAL_PORT_BASE + 1;
	if (ix < 0)  {
		ix = _ix;
	}

	if (m_worker->udpclients[ix])  {
		return m_worker->udpclients[ix]->get_average_bars();
	}

	//return nullptr;
	return 0;
}

/*********************************************************************************************************************************

*********************************************************************************************************************************/

float *Ctsrv::get_bars(int _ix)  {
	//Q_UNUSED(_ix);
	//return nullptr;
	int ix = _ix - UDP_SERVER_SERIAL_PORT_BASE + 1;
	if (ix < 0)  {
		ix = _ix;
	}

	if (m_worker->udpclients[ix])  {
		return m_worker->udpclients[ix]->get_bars();
	}

	//return nullptr;
	return 0;
}


/*********************************************************************************************************************************

*********************************************************************************************************************************/

float Ctsrv::get_ftp(int _ix)  {
	//Q_UNUSED(_ix);
	//return 0.0f;
	int ix = _ix - UDP_SERVER_SERIAL_PORT_BASE + 1;
	if (ix < 0)  {
		ix = _ix;
	}

	if (m_worker->udpclients[ix]) {
		float f;
		f = m_worker->udpclients[ix]->get_ftp();
		return f;
	}
	return -1.0f;
}

/*********************************************************************************************************************************

*********************************************************************************************************************************/

int Ctsrv::get_handlebar_buttons(int _ix)  {
	//Q_UNUSED(_ix);
	//return 0;
	int i;
	int ix = _ix - UDP_SERVER_SERIAL_PORT_BASE + 1;
	if (ix < 0)  {
		ix = _ix;
	}

	if (m_worker)  {
		if (m_worker->udpclients[ix]) {
			i = m_worker->udpclients[ix]->get_handlebar_buttons();
		}
		else {
			i = 0;
		}
	}
	else {
		i = 0;
	}

	return i;
}

/*********************************************************************************************************************************

*********************************************************************************************************************************/

bool Ctsrv::is_client_connected(int _ix)  {
	//Q_UNUSED(_ix);
	//return 0;
	int ix;

	//std::vector<CLIENT2> tcpclients;
	//UDPClient *udpclients[MAXUDPCLIENTS];

	//if (m_worker->udpclients)  {
	if (1)  {
		ix = _ix - UDP_SERVER_SERIAL_PORT_BASE + 1;
		if (ix < 0)  {
			ix = _ix;
		}

		if (m_worker->udpclients[ix]) {
			if (m_worker->udpclients[ix]->is_connected()) {
				return true;
			}
		}
	}
	return false;
}

/*********************************************************************************************************************************

*********************************************************************************************************************************/

bool Ctsrv::is_paused(int _ix)  {
	int ix = _ix - UDP_SERVER_SERIAL_PORT_BASE + 1;
	if (ix < 0)  {
		ix = _ix;
	}

	if (m_worker->udpclients[ix]) {
		bool b = false;
		b = m_worker->udpclients[ix]->is_paused();
		return b;
	}
	return false;
}

/*********************************************************************************************************************************

*********************************************************************************************************************************/

int Ctsrv::reset_averages(int _ix)  {
	int ix = _ix - UDP_SERVER_SERIAL_PORT_BASE + 1;
	if (ix < 0)  {
		ix = _ix;
	}

	if (m_worker->udpclients[ix]) {
		m_worker->udpclients[ix]->reset_stats();
		return 0;
	}
	return 1;
}


/*********************************************************************************************************************************

*********************************************************************************************************************************/

int Ctsrv::set_ftp(int _ix, float _ftp)  {
	int ix = _ix - UDP_SERVER_SERIAL_PORT_BASE + 1;
	if (ix < 0)  {
		ix = _ix;
	}

	if (m_worker->udpclients[ix]) {
		m_worker->udpclients[ix]->set_ftp(_ftp);
		return 0;
	}
	return 1;
}

/*********************************************************************************************************************************

*********************************************************************************************************************************/

int Ctsrv::set_hr_bounds(int _ix, int _minhr, int _maxhr, bool _beepEnabled)  {
	int ix = _ix - UDP_SERVER_SERIAL_PORT_BASE + 1;
	if (ix < 0)  {
		ix = _ix;
	}

	if (m_worker->udpclients[ix]) {
		m_worker->udpclients[ix]->set_hr_bounds(_minhr, _maxhr, _beepEnabled);
		return 0;
	}
	return 1;
}

/*********************************************************************************************************************************

*********************************************************************************************************************************/

int Ctsrv::set_paused(int _ix, bool _paused)  {
	int ix = _ix - UDP_SERVER_SERIAL_PORT_BASE + 1;
	if (ix < 0)  {
		ix = _ix;
	}
	if (m_worker->udpclients[ix]) {
		m_worker->udpclients[ix]->set_paused(_paused);
		return 0;
	}
	return 1;
}


/**************************************************************

**************************************************************/

int Ctsrv::set_grade(int _ix, float _bike_kgs, float _person_kgs, float _drag_factor, int _igradex10)  {				// sets windload mode
//void Ctsrv::setgrade(int _ix, int _igradex10)  {
	int ix = _ix - UDP_SERVER_SERIAL_PORT_BASE + 1;
	if (ix < 0)  {
		ix = _ix;
	}

	if (m_worker->udpclients[ix]) {
		m_worker->udpclients[ix]->set_grade(_bike_kgs, _person_kgs, _drag_factor, _igradex10);
	}
	return 0;
}

/*********************************************************************************************************************************
	rm1 compatibility
*********************************************************************************************************************************/

int Ctsrv::set_slope(int _ix, float _bike_kgs, float _person_kgs, int _drag_factor, float _grade)  {
	int ix = _ix - UDP_SERVER_SERIAL_PORT_BASE + 1;
	if (ix < 0)  {
		ix = _ix;
	}

	if (m_worker->udpclients[ix]) {
		int igradex10 = qRound(_grade*10.0f);
		m_worker->udpclients[ix]->set_grade(_bike_kgs, _person_kgs, _drag_factor, igradex10);
		return 0;
	}
	return 1;
}

/*********************************************************************************************************************************

*********************************************************************************************************************************/

int Ctsrv::start_cal(int _ix)  {
	int ix, status=-1;

	ix = _ix - UDP_SERVER_SERIAL_PORT_BASE + 1;
	if (ix < 0)  {
		ix = 0;
	}

	if (m_worker->udpclients[ix]) {
		status = m_worker->udpclients[ix]->start_cal();
	}

	return status;
}

/*********************************************************************************************************************************

*********************************************************************************************************************************/

int Ctsrv::end_cal(int _ix)  {
	int ix, status=-1;

	ix = _ix - UDP_SERVER_SERIAL_PORT_BASE + 1;
	if (ix < 0)  {
		ix = 0;
	}

	if (m_worker->udpclients[ix]) {
		status = m_worker->udpclients[ix]->end_cal();
	}

	return status;
}




/*********************************************************************************************************************************

*********************************************************************************************************************************/

void Ctsrv::txx(unsigned char *b, int n)  {
	Q_UNUSED(b);
	Q_UNUSED(n);

	return;
}

/**************************************************************

**************************************************************/

float Ctsrv::get_watts_factor(int _ix)  {
	//Q_UNUSED(_ix);
	int ix = _ix - UDP_SERVER_SERIAL_PORT_BASE + 1;
	if (ix < 0)  {
		ix = _ix;
	}

	if (m_worker->udpclients[ix]) {
		float f;
		f = m_worker->udpclients[ix]->get_watts_factor();
		return f;
	}
	return 0.0f;

}

/**************************************************************

**************************************************************/

SSDATA Ctsrv::get_ss_data(int _ix, int _fw)  {

	int ix = _ix - UDP_SERVER_SERIAL_PORT_BASE + 1;
	if (ix < 0)  {
		ix = _ix;
	}

	if (m_worker->udpclients[ix]) {
		return m_worker->udpclients[ix]->get_ss_data(_fw);
	}

	return ssd;
}


/**************************************************************

**************************************************************/

void Ctsrv::setwind(int _ix, float _wind_kph)  {
	int ix = _ix - UDP_SERVER_SERIAL_PORT_BASE + 1;
	if (ix < 0)  {
		ix = _ix;
	}

	if (m_worker->udpclients[ix])  {
		m_worker->udpclients[ix]->set_wind(_wind_kph);
	}
	return;

}

/**************************************************************

**************************************************************/

void Ctsrv::set_draftwind(int _ix, float _draft_wind_kph)  {
	int ix = _ix - UDP_SERVER_SERIAL_PORT_BASE + 1;
	if (ix < 0)  {
		ix = _ix;
	}

	if (m_worker->udpclients[ix])  {
		  m_worker->udpclients[ix]->set_draft_wind(_draft_wind_kph);
	}
	return;

}

/**************************************************************

**************************************************************/

void Ctsrv::setlbs(int _ix, float _person_lbs, float _bike_lbs)  {
	int ix = _ix - UDP_SERVER_SERIAL_PORT_BASE + 1;
	if (ix < 0)  {
		ix = _ix;
	}

	if (m_worker->udpclients[ix]) {
		m_worker->udpclients[ix]->set_lbs(_person_lbs, _bike_lbs);
	}
	return;
}

/**************************************************************

**************************************************************/

void Ctsrv::setkgs(int _ix, float _person_kgs, float _bike_kgs)  {
	int ix = _ix - UDP_SERVER_SERIAL_PORT_BASE + 1;
	if (ix < 0)  {
		ix = _ix;
	}

	if (m_worker->udpclients[ix]) {
		m_worker->udpclients[ix]->set_kgs(_person_kgs, _bike_kgs);
	}
	return;
}

/**************************************************************
	returns -1.0f or 0.0f if we don't yet have it
**************************************************************/

int Ctsrv::get_cal(int _ix)  {
	int ix = _ix - UDP_SERVER_SERIAL_PORT_BASE + 1;
	if (ix < 0)  {
		ix = _ix;
	}

	int cal = -1;

	if (m_worker->udpclients[ix]) {
		cal = qRound(100.0*m_worker->udpclients[ix]->get_cal());
#ifdef _DEBUG
		if (cal > 0)  {
			bp = 6;
		}
#endif

	}
	return cal;
}

/**************************************************************

**************************************************************/

unsigned short Ctsrv::get_fw(int _ix)  {
	int ix = _ix - UDP_SERVER_SERIAL_PORT_BASE + 1;
	if (ix < 0)  {
		ix = _ix;
	}

	int fw = -1;

	if (m_worker->udpclients[ix]) {
		fw = m_worker->udpclients[ix]->get_fw();
	}
	return fw;
}


/**********************************************************************

**********************************************************************/

void Ctsrv::handleResults(const QString& result)  {
		QMutexLocker locker(&m_accessMutex);
		qDebug() << "Controller received result from worker:" << result;
	}

/**********************************************************************

**********************************************************************/

Ctsrv* Ctsrv::instance()  {
	return m_instance;
}

/****************************************************************************

****************************************************************************/

//void Ctsrv::stop()  {
//	return;
//}


}				// namespace RACERMATE

