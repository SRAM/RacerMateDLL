#ifndef CTSRV_H
#define CTSRV_H

#include <rmdefs.h>

#include <QHostAddress>
#include <QUdpSocket>


#include <tmr.h>
#include <testdata.h>
#include <trainerdata.h>
#include <ssdata.h>

#include <qt_data.h>
#include <qt_ss.h>

#include "worker.h"

/***************************************************************************************

***************************************************************************************/


namespace RACERMATE  {

/**************************************************************************************


************************************************************************************/

class Q_DECL_EXPORT Ctsrv : public QObject {

//#ifdef QT_CORE_LIB
	Q_OBJECT
//#endif

	private:
		static Ctsrv* m_instance;
		//static QCoreApplication* m_application;
		QCoreApplication* m_application;

		Worker* m_worker;
		QThread* m_workerThread;
		QMutex m_accessMutex;

		QObject *parent;
		int debug_level;

		bool log_to_console;
		int bp;
		int init(void);
		void logg(bool _print, const char *format, ...);
		FILE *logstream;
		TrainerData td;

	public:
		//explicit Ctsrv(int _listen_port, int _broadcast_port=-1, QObject *_parent = 0);
		explicit Ctsrv(int _listen_port, int _broadcast_port=9071, int _debug_level=1, QObject *_parent = 0);
		~Ctsrv(void);

		static Ctsrv* instance();
		void doSomeOtherStuff(int value);

		//void stop(void);

		qt_SS::BARINFO *get_barinfo(int i);
		void setStarted(int _ix, bool _value);
		void setFinished(int _ix, bool _value);
		void setPaused(int _ix, bool _paused);
		int getPortNumber(void) {
				return 201;
			}
		// added for non-qt testing jan 4, 2016
		void txx(unsigned char *b, int n);
		int rx(int _ix, unsigned char *buf, int buflen);
		bool is_client_connected(int _ix);
		int send(int _ix, const unsigned char *_str, int _len, bool _flush=false);			// puts stuff in the txq
		int expect(int _ix, const char *str, DWORD timeout);
		int reset_client(int _ix);
		bool client_is_running(int _ix);
		void set_export(int _ix, const char *_dbgfname);
		void set_file_mode(int _ix, bool _mode);
		int set_hr_bounds(int _ix, int _LowBound, int _HighBound, bool _BeepEnabled);
		int set_ftp(int _ix, float _ftp);
		float get_ftp(int _ix);
		int reset_averages(int _ix);
		float *get_average_bars(int _ix);
		float get_watts_factor(int _ix);
		int set_slope(int _ix, float bike_kgs, float person_kgs, int drag_factor, float grade);			// float, int, float
		bool is_paused(int _ix);
		int set_paused(int _ix, bool _paused);
		int get_handlebar_buttons(int _ix);
		int set_ergo_mode(int _ix, int _fw, int _rrc, float _manwatts);
		int start_cal(int _ix);
		int end_cal(int _ix);
		float *get_bars(int _ix);
		struct TrainerData GetTrainerData(int _ix, int _fw);
		//qt_SS::SSD get_ss_data(int _ix, int _fw);
		SSDATA get_ss_data(int _ix, int _fw);
		SSDATA ssd;
		//void setgrade(int _ix, int _igradex10);

		int set_grade(int _ix, float _bike_kgs, float _person_kgs, float _drag_factor, int _igradex10);				// sets windload mode

		void setwind(int _ix, float _wind_kph);
		void set_draftwind(int _ix, float _draftwind_kph);
		void setkgs(int _ix, float _person_kgs, float _bike_kgs);
		void setlbs(int _ix, float _person_lbs, float _bike_lbs);
		int get_cal(int _ix);
		unsigned short get_fw(int _ix);

	signals:

		void ss_signal(int, RACERMATE::qt_SS::SSD *);
		void data_signal(int, RACERMATE::QT_DATA *);
		void rescale_signal(int, int);
		void connected_to_trainer_signal(int _ix, bool _b);
		//void gradechanged_signal(int _igradex10);

	private slots:
		void handleResults(const QString &s);

		// signals from UDPClient

		void data_slot(int _ix, QT_DATA *_data);
		void ss_slot(int _ix, qt_SS::SSD *_ssd);
		void rescale_slot(int _ix, int _maxforce);
		void connected_to_trainer_slot(int _ix, bool _b);
		//void gradechanged_slot(int _ix, int _igradex10);
		//void windchanged_slot(int _ix, float _wind);

};

}				// namespace RACERMATE


#endif // CTSRV_H

