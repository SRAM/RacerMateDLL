
#ifndef _WORKER_H_
#define _WORKER_H_

#include <QtCore>

#include <rmdefs.h>

#include <QUdpSocket>
#include "udp_client.h"

namespace RACERMATE  {

#define DO_CLIENT_LIST

/*
class clientItem  {

	public:
		clientItem()  {};

	public:
		QString ipaddr;
		unsigned short devnum;
		quint16 peerport;
		QString portnum;
};
*/

class Ctsrv;

class Worker : public QObject  {
	Q_OBJECT

	friend class Ctsrv;

	public:
		Worker(qint16 _listen_port, qint16 _bcport, int _debug_level, QObject* parent = 0);
		// don't use a destructor!!! use the stop() slot instead

	private:
		qint16 listen_port;
		qint16 bcport;
		int debug_level;
		QTimer *m_timer;
		QTimer *bctimer;                                  // broadcast timer

		QString program_dir;
		QString personal_dir;
		QString settings_dir;
		QString debug_dir;
		QFile file;

		//bool dbg;
//#ifndef MAXCLIENTS
		//static const int MAXCLIENTS=1;
		//#define MAXCLIENTS 1
		//#define MAXCLIENTS 16
//#endif

		const static int RXQLEN = 2048;
		unsigned char rxq[RXQLEN];
		//QList<clientItem> clients;
		int rxinptr;
		int rxoutptr;

		qint64 bytes_in;
		//QHostAddress saved_peeraddr;
		QHostAddress peeraddr;
		//quint16 saved_peerport;
		quint16 peerport;
		//void readDatagram(void);
		int get_ubermsg(void);
		unsigned char datagram[MSGLEN];    // extracted complete udp packet
		int mstate;                   // pkt finder state machine
		int minptr;                   //
		int bad_msg;                  // bad pkt counter
		int csum;
		int msglen;
		int datalen;
		unsigned short devnum;
		int get_devnum(int _len);

		//QT_DATA data[MAXCLIENTS];
		//qt_SS::SSD ssd[MAXCLIENTS];
		qt_SS::BARINFO *get_barinfo(int i);


		Ctsrv *ctsrv;
		int bp;
		QUdpSocket *bcsocket;
		QUdpSocket *udp_server_socket;
		unsigned bcast_count;
		QByteArray bc_datagram;
		FILE *logstream;

		QList<UDPClient *> udpclients;

		unsigned long last_ip_broadcast_time;                    // ethernet
		QHostAddress myip;
		QHostAddress bcaddr;
		QHostAddress netmask;
		Tmr *at;
		char logname[32];
		//FILE *logstream;

		// fuctions

		int create_udp_server_socket(void);

	public slots:
		void start();
		void stop();

	private slots:
		void timeout();

		//void prepareResult();
		void disconnected();
		void hostFound();
		void processPendingDatagrams();
		//void gradechanged_slot(int _igradex10);
		//void windchanged_slot(float);
		void bc_timeout();

	signals:
		void finished();
		void resultReady(const QString &result);

		void ss_signal(int, RACERMATE::qt_SS::SSD *);
		void data_signal(int, RACERMATE::QT_DATA *);
		void rescale_signal(int, int);
		//void gradechanged_signal(int _igradex10);
		//void windchanged_signal(float);

};
}				// namespace RACERMATE

#endif

