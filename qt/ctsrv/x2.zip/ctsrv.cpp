
#include <QNetworkInterface>
#include <QNetworkAddressEntry>
#include <QHostInfo>

#ifdef WIN32
#include <assert.h>
#endif

#include "worker.h"
#include "ctsrv.h"


namespace MYQT  {

Ctsrv* Ctsrv::m_instance = 0;
QCoreApplication* Ctsrv::m_application = NULL;


/**********************************************************************

**********************************************************************/

Ctsrv::Ctsrv(int _listen_port, int _broadcast_port, QObject *_parent) : QObject(_parent) {
		Q_ASSERT(!m_instance);
		m_instance = this;

		parent = _parent;
		qDebug() << "Ctsrv: " << "thread id = " << QThread::currentThreadId();

		at = 0;
		logstream = 0;

		at = new Tmr();

		int argc = 1;
		m_application = qApp ? 0 : new QCoreApplication(argc, 0);

		/*
		if (qApp)  {
			m_application = 0;
		}
		else  {
			m_application = new QCoreApplication(argc, 0);
		}
		*/

		/*
		if (QCoreApplication::instance() == NULL)  {
			int argc = 1;
			m_application = new QCoreApplication(argc, 0);
		}
		else  {
			//m_application = QCoreApplication::?
			int argc = 1;													// ??
			m_application = new QCoreApplication(argc, 0);		// ?? more that 1 application allowed?
		}
		*/


		//int argc = 1;
		//m_application = new QCoreApplication(argc, 0);

		m_workerThread = new QThread(this);

		qDebug() << "Ctsrv creating worker";
		//m_worker = new Worker(this, _listen_port, _broadcast_port);
		m_worker = new Worker(_listen_port, _broadcast_port);
		qDebug() << "Ctsrv moving worker to workerThread";
		m_worker->moveToThread(m_workerThread);

		connect(m_workerThread, SIGNAL(started()), m_worker, SLOT(start()));
		//connect(m_worker, SIGNAL(finished()), m_workerThread, SLOT(quit()));
		connect(m_worker, SIGNAL(resultReady(QString)), SLOT(handleResults(QString)), Qt::DirectConnection);
		connect(m_worker, SIGNAL(finished()), m_workerThread, SLOT(quit()));

		qDebug() << "Ctsrv constructor starting worker thread";
		m_workerThread->start();


		qDebug() << "Ctsrv returning from constructor";

	}


/**********************************************************************
	destructor
**********************************************************************/

Ctsrv::~Ctsrv() {

		//////////////////
		qDebug() << "Ctsrv destructor";
		if (at)  {
			delete at;
			at = 0;
		}

		m_worker->stop();

		// Wait worker and it's thread to finish gracefully

		QEventLoop eventLoop;
		connect(m_workerThread, SIGNAL(finished()), &eventLoop, SLOT(quit()));
		eventLoop.exec();

		// Cleanup resources

		delete m_worker;

		if (m_application)  {
			delete m_application;
			m_application = 0;
		}

		m_instance = 0;

		if (logstream)  {
			fclose(logstream);
			logstream = 0;
		}
		bp = 0;
		qDebug() << "Ctsrv destructor finished";

	}


/**********************************************************************

**********************************************************************/

void Ctsrv::data_slot(int _ix, MYQT::QT_DATA *_data)  {
	emit(data_signal(_ix, _data));
	return;
}

/**********************************************************************

**********************************************************************/

void Ctsrv::ss_slot(int _ix, MYQT::qt_SS::SSD *_ssd)  {
		emit(ss_signal(_ix, _ssd));
		return;
	}


/**********************************************************************

**********************************************************************/

void Ctsrv::rescale_slot(int _ix, int _maxforce)  {
	emit(rescale_signal(_ix, _maxforce));
	return;
}

/**********************************************************************
	client slot
**********************************************************************/

void Ctsrv::connected_to_trainer_slot(int _id, bool _b) {
	emit connected_to_trainer_signal(_id, _b);                     // pass upstream
	return;
}


/**********************************************************************

***********************************************************************/

void Ctsrv::logg(bool _print, const char *format, ...) {
		int len;

		len = (int)strlen(format);
		if (len > 1023) {
				if (_print) {
						qDebug() << "string too long in logg()";
					}
				if (logstream) {
						fprintf(logstream, "\r\n(string too long in logg())\r\n");
						//fflush(logstream);
					}
				return;
			}


		return;
	}                                      // logg()

/**********************************************************************

**********************************************************************/

qint32 ArrayToInt(QByteArray source) {
		qint32 temp;
		QDataStream data(&source, QIODevice::ReadWrite);

		data >> temp;
		return temp;
	}                       // ArrayToInt()



//xxx

/****************************************************************************

****************************************************************************/

void Ctsrv::stop()  {
		return;
	}

/**********************************************************************

**********************************************************************/

qt_SS::BARINFO *Ctsrv:: get_barinfo(int i) {
		//Q_UNUSED(i);
		//return udpclients[0]->ss->get_barinfo(i);
		return m_worker->get_barinfo(i);
//		return 0;
	}                          // get_barinfo(int i)

/**********************************************************************

**********************************************************************/

void Ctsrv::setStarted(bool value) {
		Q_UNUSED(value);
	}

/**********************************************************************

**********************************************************************/

void Ctsrv::setFinished(bool value) {
		Q_UNUSED(value);
	}
/**********************************************************************

**********************************************************************/

void Ctsrv::setPaused(bool value) {
		Q_UNUSED(value);
	}

/**********************************************************************

**********************************************************************/

void Ctsrv::doSomeOtherStuff(int value)  {
		QMutexLocker locker(&m_accessMutex); // Prevent calling following code from different threads simultaneously
		qDebug() << "Doing some other stuff..." << value;
	}

/**********************************************************************

**********************************************************************/

void Ctsrv::handleResults(const QString& result)  {
		QMutexLocker locker(&m_accessMutex);
		qDebug() << "Controller received result from worker:" << result;
	}

/**********************************************************************

**********************************************************************/

Ctsrv* Ctsrv::instance()  {
		return m_instance;
	}


}						// namespace
