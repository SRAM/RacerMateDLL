#ifndef CTSRV_H
#define CTSRV_H

#include <QHostAddress>
#include <QUdpSocket>

#include <tmr.h>

#include <rmdefs.h>

#include <testdata.h>
#include <trainerdata.h>
#include <ssdata.h>

//#define TEST_WITH_NO_APP
#define NEWAGE


#include <qt_data.h>
#include <qt_ss.h>
#include "worker.h"


/***************************************************************************************

***************************************************************************************/


namespace MYQT  {

/**************************************************************************************


************************************************************************************/

class Q_DECL_EXPORT Ctsrv : public QObject {

#ifdef QT_CORE_LIB
		Q_OBJECT
#endif

	private:
		static Ctsrv* m_instance;
		static QCoreApplication* m_application;

		Worker* m_worker;
		QThread* m_workerThread;
		QMutex m_accessMutex;

		QObject *parent;
		Tmr *at;
		bool log_to_console;
		int bp;
		int init(void);
		void logg(bool _print, const char *format, ...);
		FILE *logstream;

	public:
		explicit Ctsrv(int _listen_port, int _broadcast_port=-1, QObject *_parent = 0);
		~Ctsrv(void);

		static Ctsrv* instance();
		void doSomeOtherStuff(int value);

		void stop(void);
		qt_SS::BARINFO *get_barinfo(int i);
		void setStarted(bool value);
		void setFinished(bool value);
		void setPaused(bool value);
		int getPortNumber(void) {
				return 201;
			}

	signals:
		void ss_signal(int, MYQT::qt_SS::SSD *);
		void data_signal(int, MYQT::QT_DATA *);
		void rescale_signal(int, int);
		void connected_to_trainer_signal(int _ix, bool _b);


	private slots:
		void handleResults(const QString &s);

		// signals from UDPClient

		void data_slot(int _ix, QT_DATA *_data);
		void ss_slot(int _ix, qt_SS::SSD *_ssd);
		void rescale_slot(int _ix, int _maxforce);
		void connected_to_trainer_slot(int _ix, bool _b);

};

}


#endif // CTSRV_H

