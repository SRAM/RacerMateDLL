
#include <QNetworkInterface>
#include <QNetworkAddressEntry>
#include <QHostInfo>

#ifdef WIN32
	#include <shlobj.h>
#endif

#include "worker.h"
#include "ctsrv.h"

namespace RACERMATE  {

/**************************************************************************

**************************************************************************/

Worker::Worker(qint16 _listen_port, qint16 _bcport, int _debug_level, QObject* _parent ) : QObject(_parent)  {
		listen_port = _listen_port;
		bcport = _bcport;
		debug_level = _debug_level;

#ifdef _DEBUG
	qDebug() << "      Worker(): tid = " << QThread::currentThreadId();
#endif

#if MAXCLIENTS!=1
		memset(rxq, 0, sizeof(rxq));
		rxinptr = 0;
		rxoutptr = 0;
		bytes_in = 0;
		peeraddr.clear();
		peerport = 0;
		memset(datagram, 0, sizeof(datagram));
		mstate = 0;
		minptr = 0;
		bad_msg = 0;
		csum = 0;
		msglen = 0;
		datalen = 0;
		devnum = 0;
#endif

		bp = 0;
		int status;

		udp_server_socket = 0;
		bc_datagram.clear();
		bcast_count = 0L;

		last_ip_broadcast_time = 0L;
		bcsocket = NULL;

		//dbg = false;

		/*
		foreach (const QHostAddress &address, QNetworkInterface::allAddresses()) {
			if (address.protocol() == QAbstractSocket::IPv4Protocol && address != QHostAddress(QHostAddress::LocalHost))  {
				qDebug() << address.toString();
			}
		}
		qDebug() << endl << endl;
		*/

		/*
		QList<QNetworkInterface> interfaces =  QNetworkInterface::allInterfaces();
		foreach(QNetworkInterface iface, QNetworkInterface::allInterfaces())  {
			bp = 1;
		}
		foreach(QNetworkInterface interface, QNetworkInterface::allInterfaces())  {
			bp++;
		}
		*/

		if (myip.isNull())  {
			bp = 2;
		}

		QList<QNetworkAddressEntry> ipv4entries;

		foreach(const QNetworkInterface iface, QNetworkInterface::allInterfaces()) {
			if(iface.flags().testFlag(QNetworkInterface::IsUp) && (!iface.flags().testFlag(QNetworkInterface::IsLoopBack)))  {
#ifdef _DEBUG
				qDebug() << iface.name();
#endif
				//UnicastIPAddressInformationCollection UnicastIPInfoCol = iface.GetIPProperties().UnicastAddresses;
				//bp = iface.InterfaceFlag;
				//bp = iface.InterfaceFlags;
				bp = iface.CanBroadcast;		// 4
				bp = iface.CanMulticast;		// 32

				bp = 7;
				foreach(QNetworkAddressEntry entry, iface.addressEntries())  {
					if(entry.ip().protocol() == QAbstractSocket::IPv4Protocol)  {
#ifdef _DEBUG
						qDebug() << "   " << entry.ip().toString();
#endif
						ipv4entries.append(entry);
						myip = entry.ip();
						netmask = entry.netmask();
						bcaddr = entry.broadcast();
					}
				}
			}
		}

		qDebug("count = %d", ipv4entries.count());

		bp = 1;


		if (!myip.isNull())  {

			//qDebug() << "myip = " << myip.toString();
			//qDebug() << "netmask = " << netmask.toString();
			//qDebug() << "bcaddr = " << bcaddr.toString();

			bp = 1;

			/*
			foreach(NetworkInterface Interface in Interfaces) {
				if(Interface.NetworkInterfaceType == NetworkInterfaceType.Loopback)
					continue;
				if (Interface.OperationalStatus != OperationalStatus.Up)
					continue;

				Console.WriteLine(Interface.Description);
				UnicastIPAddressInformationCollection UnicastIPInfoCol = Interface.GetIPProperties().UnicastAddresses;
				foreach(UnicastIPAddressInformation UnicatIPInfo in UnicastIPInfoCol)  {
					Console.WriteLine("\tIP Address is {0}", UnicatIPInfo.Address);
					Console.WriteLine("\tSubnet Mask is {0}", UnicatIPInfo.IPv4Mask);
				}
			}
			*/

		}



		//bcaddr = "miney2.mselectron.net";

		bc_datagram.append("Racermate ");
		bc_datagram.append(QString::number(listen_port));
		bc_datagram.append(" ");
		bc_datagram.append(myip.toString());
		bc_datagram.append("\n");

#ifdef _DEBUG
		//const char *ccptr = bc_datagram.toStdString().c_str();
		//qDebug() << "datagram = " << ccptr;
#endif

		if (bcport != -1) {
				bcsocket = new QUdpSocket(this);
				//bcsocket->s

				//#ifdef _DEBUG
#if 0
				QHostInfo info = QHostInfo::fromName("miney2.mselectron.net");    // QHostInfo::localHostName()  );
				QList<QHostAddress> ip = info.addresses();
				bcaddr = ip[0];
				bcaddr = "192.168.1.255";
	#ifdef _DEBUG
				//qDebug() << "bcaddr = " << bcaddr;
	#endif
#endif
		}

#ifdef WIN32
	wchar_t gstr[512] = {0};

	SHGetFolderPath(NULL, CSIDL_PROGRAM_FILES, NULL, 0, gstr);	// "C:\Program Files"
	program_dir = QString::fromWCharArray(gstr);
	SHGetFolderPath(NULL, CSIDL_PERSONAL, NULL, 0, gstr);			// "C:\\Users\\larry\\Documents"
	personal_dir = QString::fromWCharArray(gstr);
	personal_dir += "\\RacerMate";										// "C:\\Users\\larry\\Documents\\RacerMate"
	settings_dir = personal_dir + "\\Settings";						// "C:\\Users\\larry\\Documents\\RacerMate\\Settings"
	debug_dir = personal_dir + "\\Debug";						// "C:\\Users\\larry\\Documents\\RacerMate\\Debug"

#ifdef _DEBUG
	qDebug()	<< "program_dir = " << program_dir;
#endif

#else
	program_dir = ".";
	personal_dir = ".";
	settings_dir = ".";
	debug_dir = ".";
#endif

	if (!QDir(personal_dir).exists())  {
		QDir().mkdir(personal_dir);
	}
	if (!QDir(settings_dir).exists())  {
		QDir().mkdir(personal_dir);
	}
	if (!QDir(debug_dir).exists())  {
		QDir().mkdir(debug_dir);
	}

	bp = 1;
	int id = 0;

	if (debug_level > 0)  {
		QString s = debug_dir + "/udp" + QString::number(id) + ".log";
		file.setFileName(s);

		if ( file.open(QIODevice::ReadWrite | QIODevice::Text | QIODevice::Truncate) ) {
			if (file.isOpen())  {
				bp = 2;
			}
			if (debug_level > 1 && file.isOpen())  {
				qint64 size = file.size();
				file.seek(size);
				QTextStream stream(&file);

				QDateTime dt = QDateTime::currentDateTime();
				QString s2 = dt.toString("yyyy-MM-dd-hh-mm-ss");
				stream << endl << endl << "starting at " << s2 << ", debug_level = " << debug_level << endl << endl;
				file.flush();
			}
		}
		else  {
			if (file.isOpen())  {
				bp = 2;
			}
		}
	}				// if (debug_level > 0)

		strcpy(logname, "worker.log");

		if (debug_level > 0)  {
			logstream = fopen(logname, "wt");
		}
		else  {
			logstream = 0;
		}

		status = create_udp_server_socket();                                     // creates the Worker socket and starts listening.
		if (status != 0) {
				//return 1;
			}

		at = new Tmr("W");

		bctimer = 0;
		m_timer = 0;

		if (bcport != -1) {
				// create a timer for broadcasting
				bctimer = new QTimer(this);
				bctimer->setInterval(2000);
				connect( bctimer, SIGNAL(timeout()), this, SLOT(bc_timeout())  );
				//bctimer->start(2000);
			}

#ifndef DO_CLIENT_LIST
		int i;


		for (i = 0; i < MAXCLIENTS; i++) {
			#ifdef _DEBUG
			qDebug() << "      Worker(): creating client";
			#endif
			udpclients[i] = new UDPClient(i, debug_level, this);
			//connect(udpclients[i], SIGNAL(data_signal(int, QT_DATA*)), this, SLOT(data_slot(int, QT_DATA*)));
			connect(udpclients[i], SIGNAL(data_signal(int, QT_DATA*)), Ctsrv::instance(), SLOT(data_slot(int, QT_DATA*)));
			connect(udpclients[i], SIGNAL(ss_signal(int, qt_SS::SSD*)), Ctsrv::instance(), SLOT(ss_slot(int, qt_SS::SSD*)));
			connect(udpclients[i], SIGNAL(rescale_signal(int, int)), Ctsrv::instance(), SLOT(rescale_slot(int, int)));
			connect(udpclients[i], SIGNAL(connected_to_trainer_signal(int,bool)), Ctsrv::instance(), SLOT(connected_to_trainer_slot(int,bool)));
			//connect(this, SIGNAL(gradechanged_signal(int)), udpclients[i], SLOT(gradechanged_slot(int)));
			//connect(this, SIGNAL(windchanged_signal(float)), udpclients[i], SLOT(windchanged_slot(float)));
		}

		#ifdef _DEBUG
		//qDebug() << "   worker onStarted()";
		#endif
#endif


#ifdef _DEBUG
	qDebug() << "      Worker(): creating m_timer, tid = " << QThread::currentThreadId();
#endif

		m_timer = new QTimer(this);
		m_timer->setInterval(10);
		connect(m_timer, SIGNAL(timeout()), this, SLOT(timeout()));				// , Qt::DirectConnection, prepareResult()

		//m_timer->start();
#ifdef _DEBUG
		qDebug() << "      Worker(): finished";
#endif
		return;
	}										// constructor

/**********************************************************************

**********************************************************************/

int Worker::create_udp_server_socket(void)  {
		bool b;

#ifdef _DEBUG
		qDebug() << "      Worker::create_udp_server_socket(): tid = " << QThread::currentThreadId();
#endif

		udp_server_socket = new QUdpSocket(this);

		/*
			QAbstractSocket::ShareAddress	0x1

			Allow other services to bind to the same
			address and port. This is useful when multiple processes share the load of a
			single service by listening to the same address and port (e.g., a web server
			with several pre-forked listeners can greatly improve response time).
			However, because any service is allowed to rebind, this option is subject to
			certain security considerations. Note that by combining this option with
			ReuseAddressHint, you will also allow your service to rebind an existing shared
			address. On Unix, this is equivalent to the SO_REUSEADDR socket option. On
			Windows, this option is ignored.

			QAbstractSocket::DontShareAddress	0x2

			Bind the address and port
			exclusively, so that no other services are allowed to rebind. By passing this
			option to QAbstractSocket::bind(), you are guaranteed that on successs, your
			service is the only one that listens to the address and port. No services are
			allowed to rebind, even if they pass ReuseAddressHint. This option provides
			more security than ShareAddress, but on certain operating systems, it requires
			you to run the server with administrator privileges. On Unix and Mac OS X, not
			sharing is the default behavior for binding an address and port, so this option
			is ignored. On Windows, this option uses the SO_EXCLUSIVEADDRUSE socket option.

			QAbstractSocket::ReuseAddressHint	0x4

			Provides a hint to QAbstractSocket
			that it should try to rebind the service even if the address and port are
			already bound by another socket. On Windows, this is equivalent to the
			SO_REUSEADDR socket option. On Unix, this option is ignored.

			QAbstractSocket::DefaultForPlatform	0x0

			The default option for the current
			platform. On Unix and Mac OS X, this is equivalent to (DontShareAddress +
					ReuseAddressHint), and on Windows, its equivalent to ShareAddress.

			This enum was introduced or modified in Qt 5.0.

			The BindMode type is a typedef for QFlags<BindFlag>. It stores an OR combination of BindFlag values.
		*/

#ifdef _DEBUG
		//qDebug() << "   udp_server_socket bind to " << listen_port;						// 9072
#endif

		/*
		QAbstractSocket::DefaultForPlatform	0x0
		QAbstractSocket::ShareAddress			0x1
		QAbstractSocket::DontShareAddress	0x2
		QAbstractSocket::ReuseAddressHint	0x4
		*/

		b = udp_server_socket->bind(QHostAddress::AnyIPv4, listen_port, QUdpSocket::ReuseAddressHint | QUdpSocket::ShareAddress);
		if (!b) {
				qFatal("error creating Worker socket 1");
			}


#ifdef _DEBUG
		QAbstractSocket::SocketState s = udp_server_socket->state();

		switch(s)  {
			case QAbstractSocket::UnconnectedState:		// 0	The socket is not connected.
				qDebug() << "      socket state = UnconnectedState";
				break;
			case QAbstractSocket::HostLookupState:			//	1	The socket is performing a host name lookup.
				qDebug() << "      socket state = HostLookupState";
				break;
			case QAbstractSocket::ConnectingState:			//	2	The socket has started establishing a connection.
				qDebug() << "socket state = ConnectingState";
				break;
			case QAbstractSocket::ConnectedState:			//	3	A connection is established.
				qDebug() << "socket state = ConnectedState";
				break;
			case QAbstractSocket::BoundState:				//	4	The socket is bound to an address and port.
				//qDebug() << "      socket state = BoundState";
				break;
			case QAbstractSocket::ClosingState:				//	6	The socket is about to close (data may still be waiting to be written).
				qDebug() << "socket state = ClosingState";
				break;
			case QAbstractSocket::ListeningState:			//	5	For internal use only.
				qDebug() << "socket state = ListeningState";
				break;
			default:
				qDebug() << "socket state = default";
				break;
			}
#endif

		Q_ASSERT(udp_server_socket->state() == QAbstractSocket::BoundState);

		connect(udp_server_socket, SIGNAL(disconnected()), this, SLOT(disconnected()));
		connect(udp_server_socket, SIGNAL(hostFound()), this, SLOT(hostFound()));
		connect(udp_server_socket, SIGNAL(readyRead()), this, SLOT(processPendingDatagrams()));

		// these have errors:
		//connect(udp_server_socket, SIGNAL(stateChanged(QAbstractSocket::SocketState socketState)), this, SLOT(stateChanged(QAbstractSocket::SocketState socketState)));
		//connect(udp_server_socket, SIGNAL(error(QAbstractSocket::SocketError socketError)), this, SLOT(error(QAbstractSocket::SocketError socketError)));

		return 0;
	}										// int Worker::create_udp_server_socket(void)  {


/**********************************************************************

**********************************************************************/

qt_SS::BARINFO *Worker:: get_barinfo(int i) {
	return udpclients[0]->ss->get_barinfo(i);
}                          // get_barinfo(int i)

// slots+++

/**********************************************************************

**********************************************************************/

void Worker::disconnected() {
#ifdef _DEBUG
	qDebug() << "      Worker::disconnected slot() executed";
#endif
	return;
}

/**********************************************************************

**********************************************************************/

void Worker::hostFound() {
	bp = 4;
	return;
}

/**********************************************************************
	udp_server_socket slot
**********************************************************************/

void Worker::processPendingDatagrams(void) {

#if MAXCLIENTS==1
	udpclients[0]->readDatagram(udp_server_socket);
#else
		qint64 n;
		int i;
		int loops = 0;
		int status;

		while (udp_server_socket->hasPendingDatagrams()) {
			QByteArray a;
			loops++;
			a.resize(udp_server_socket->pendingDatagramSize());
			n = udp_server_socket->readDatagram(a.data(), a.size(), &peeraddr, &peerport);		// peeraddr = 192.168.1.40, peerport = 41631, eg

			if (n<0)  {
				qFatal("readDatagram error");
			}

			bytes_in += n;

			// figure out which queue to put it in based on the peerport / peeraddr
			int m = clients.count();

			bp = 2;

			for (i = 0; i < n; i++) {
				rxq[rxinptr] = a[i];
				rxinptr = (rxinptr + 1) % sizeof(rxq);
			}
		}

#if 1
		status = get_ubermsg();


		if (status==0)  {
			bp = 1;
		}
		else if (status < 0)  {
			bp = 2;
		}
		else  {
			devnum = get_devnum(n);   // test the sect chain and get devnum
			qDebug("%s   %5d   %d", peeraddr.toString().toStdString().c_str(), peerport, devnum);

			bp = 3;			// good packet
		}
#endif

#endif
	return;

}                          // processPendingDatagrams()




/**********************************************************************
	app slot
**********************************************************************/

#if 0
void Worker::gradechanged_slot(int _igradex10) {

#ifdef _DEBUG
	int igradex10;
	float grade;                          // sent float grade, controlled by course or manually
#endif

#ifdef _DEBUG
	igradex10 = _igradex10;
	grade = (float)igradex10 / 10.0f;
	qDebug() << "   Worker::gradechanged() grade = " << grade;
#endif

	emit(gradechanged_signal(_igradex10));
	return;
}

/**********************************************************************
	app slot
**********************************************************************/

void Worker::windchanged_slot(float _f) {

#ifdef _DEBUG
	float wind;
	wind = _f;
	qDebug() << qSetRealNumberPrecision(1) << "wind = " << wind;
#endif
	emit(windchanged_signal(_f));

	return;
}
#endif


/*********************************************************************************************************************************
	bc_timer slot
*********************************************************************************************************************************/

void Worker::bc_timeout() {
	//at->update();							// 3001 ms

	qint64 n;

	n = bcsocket->writeDatagram(bc_datagram, bcaddr, bcport);            // miney2.mselectron.net, 9071

	if (n <= 0) {
		//qDebug() << "n = " << n;
		//qDebug() << "bc_datagram = " << bc_datagram;
		//qDebug() << "bcaddr = " << bcaddr;
		//qDebug() << "bcport = " << bcport;
		qFatal("broadcast write error");
	}
	else  {
		//qDebug() << "n = " << n;
		//qDebug() << "bc_datagram = " << bc_datagram;
		//qDebug() << "bcaddr = " << bcaddr;
		//qDebug() << "bcport = " << bcport;
	}

	return;
}                          // bc_timeout()


// slots---


/**************************************************************************

**************************************************************************/

void Worker::timeout()  {						// see prepareResult(), trackshun

	/*
		emit resultReady("tick");
		Ctsrv* controller = Ctsrv::instance();
		controller->doSomeOtherStuff(QTime::currentTime().msecsSinceStartOfDay());
	*/


	//at->update();								// 10.00 ms

	/*
	Ctsrv* ctsrv = Ctsrv::instance();
	ctsrv->doSomeOtherStuff(QTime::currentTime().msecsSinceStartOfDay());
	*/

	int i;

	for(i=0; i<MAXCLIENTS; i++)  {
		udpclients[i]->process();
	}

	return;
}							// timeout()

/**************************************************************************

**************************************************************************/

void Worker::start()  {
	if (QThread::currentThread() != thread())  {
		QMetaObject::invokeMethod(this, "start");
		return;
	}

#ifdef _DEBUG
	qDebug() << "      Worker::start(): calling m_timer->start()";
#endif

	if (m_timer)  {
		m_timer->start();
	}

	if (bctimer)  {
		bctimer->start();
	}

}								// start() slot

/**************************************************************************
	don't do this in a destructor!!!!!
**************************************************************************/

void Worker::stop()  {
	if (QThread::currentThread() != thread())  {
		QMetaObject::invokeMethod(this, "stop");
		return;
	}

	if (m_timer)  {
		m_timer->stop();
	}

	if (bctimer)  {
		bctimer->stop();
	}

#if 1
	int i;
	delete at;

	if (udpclients[0])  {
		udpclients[0]->close_log_file();							// save the log file here
	}

#ifndef DO_CLIENT_LIST
	for (i = 0; i < MAXCLIENTS; i++) {
		delete udpclients[i];
		udpclients[i] = 0;
	}
#else
#endif

	if (udp_server_socket) {
		udp_server_socket->close();
		delete udp_server_socket;
		udp_server_socket = 0;
	}

	if (bcsocket != NULL) {
		bcsocket->close();
		delete bcsocket;
		bcsocket = 0;
	}

	if (logstream) fclose(logstream);

#endif

	emit finished();
}				// stop() slot

#if MAXCLIENTS != 1
//#if 0
/*************************************************************************************************

*************************************************************************************************/

int Worker::get_ubermsg(void) {
	const unsigned char *header = (const unsigned char*)"RMCT";
	unsigned char c;

	while (rxoutptr != rxinptr) {

		c = rxq[rxoutptr];
		rxoutptr = (rxoutptr + 1) % RXQLEN;

		csum += c;							// add every byte to checksum

		switch(mstate) {

			case	0:									// looking for "RMCT"
				csum = c;							// init checksum to first char
			case	1:
			case	2:
			case	3:
				if(c != header[mstate++]) {
					mstate = 0;					// no match, start again
				}
				break;

			case	4:
				msglen = c;				// byte 4 is uberlength from here upto checksum
				mstate++;

				if(msglen < 2 || msglen >= (int)((sizeof(datagram) - 1))) {
					mstate = 0;					// go back to looking for RMCT
					return E_LEN;				// -2
				}
				break;

			case	5:				// byte 4 is ~uberlength, must match len
				if((c ^ msglen) != 0xff) {
					mstate = 0;					// go back to looking for RMCT
					return E_CLEN;				// -3
				}

				minptr = 0;			// start buffer on first section size byte
				datalen = msglen - 2;  // starting after msglen, ~msglen
				mstate++;
				break;

			case	6:									// reading msglen chars into buf
				datagram[minptr++] = c;
				if(minptr >= datalen) {
					mstate++;				// adv state after last data, next char will be csm
				}
				break;

			case	7:				// csm byte came in
				mstate = 0;
				if(csum & 0xff) {
					return E_CSM;				// return -1 on bad csm
				}
				return minptr;			// return size of dgm, may be 1

			default:
				mstate = 0;
				break;

		}	//switch

	}		// while

	return 0;
}															// get_ubermsg()

/*********************************************************************************************************************************
	walk datagram checking for the sections, stop at len
	return device# if walk is ok, and first sect is
	SECT_DEVNUM else -1
*********************************************************************************************************************************/

int Worker::get_devnum(int _len) {
	int i;
	int devnum = -1;

	i = datagram[0];

	for( i = datagram[0]; i <= _len; i += datagram[i]) {
		if( datagram[i] == 0)	{
			break;
		}
	}
	if(datagram[1] == SECT_DEVNUM)	{
		devnum = datagram[2] << 8 | datagram[3];
	}
	return devnum;
}						// get_devnum()

//#endif			// #if 0
#endif			// #if MAXCLIENTS != 1


}				// namespace RACERMATE
