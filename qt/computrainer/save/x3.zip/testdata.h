#ifndef _TESTDATA_H_
#define _TESTDATA_H_

class TESTDATA  {
	public:
		TESTDATA(void);
		void reset(void);
		//int dummy;

		int dgs;											// count of datagrams received
		int len;											// length of last full datagram (all pending)
		int bad_msg;									// bad_msg counter
		int rmcts;										// total number of rmct pkts
		int seqnum;										// last sequence number received ????????????????
		int devnum;										// last devnum received

		int xseqnum;
		int histatus;

		/*

		5)
		The last received sequence #, nhbd.seqnum.

		6)
		The last received device #, nhbd.devnum.

		I forgot to load these into nhbd, add this to my handle_pkts():

					// first section MUST be devnum
					if(dgm[1] != SECT_DEVNUM) {

						 printf(" Not devnum sect: %d\n", dgm[1]);
						 continue;
					}
					devnum = dgm[2]<<8 | dgm[3];
					seqnum = dgm[4]<<8 | dgm[5];
		+
		+        nhbd.devnum = devnum;
		+        nhbd.seqnum = seqnum;
		+
					printf("devnum= %d  seqnum= %d\n", devnum, seqnum);

					ix = dgm[0];                // skip over devnum section

					while( ix < dgmlen && dgm[ix] != 0) {

		8)
		The hi word of (int)nhbd.status as a decimal #
					printf("%5d", nhbd.status >> 16;

		This now has 57005 (0xdead) in it, I will echo the last control msg
		sequence # RealSoonNow.
		*/


	private:
		void init(void);

};

#endif


