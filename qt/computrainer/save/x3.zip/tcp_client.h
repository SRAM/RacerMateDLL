
#ifndef _X_CLIENT2_H_X_
#define _X_CLIENT2_H_X_

#include <stdio.h>
#include <QtCore>
#include <QTcpSocket>

#include "defines.h"

#include "rider.h"
#include "ss.h"
#include "coursefile.h"
#include "data.h"

#define TXQLEN 1024
#define RXQLEN 2048
#define RXBUFLEN 1024
#define TXBUFLEN 1024

class TCPClient : public QObject  {
	Q_OBJECT

public:

	static const int NBARS = 24;

	enum LoggingType {
		NO_LOGGING,
		RAW_PERF_LOGGING,
		THREE_D_PERF_LOGGING,
		RM1_PERF_LOGGING
	};

	typedef struct {
		unsigned long time;
		unsigned char buf[6];
	} RAW_COMPUTRAINER_LOGPACKET;

	#define MODE_WIND               0x2c
	#define MODE_WIND_PAUSE         0x28
	#define MODE_RFTEST             0x1c
	#define MODE_ERGO               0x14
	#define MODE_ERGO_PAUSE         0x10


public:
	//explicit TCPClient(int _id, QTcpSocket *_socket, QObject *parent = 0);
	explicit TCPClient(int _id, QObject *parent = 0);
	~TCPClient();

	int flush(void);
	int mysend(const unsigned char *_str, int _len, bool _flush);
	int idle(void);
	int receive(void);

	FILE *rx;
	FILE *tx;
	unsigned long outpackets;
	unsigned long bytes_out;
	unsigned long ipaddr;
	int id;                          // 0 - 15
	int comport;                     // 201-216
	char ipstr[128];
	QTcpSocket *socket;              // todo: make private
	void set_socket(QTcpSocket *_socket);
	SS *ss;                          // todo: make private

private:
	#define XORVAL 0xff
	#define RPM_VALID 0x08

	bool connected_to_trainer;
	bool finished;
	bool finishEdge;
	bool hrbeep_enabled;
	bool hrvalid;
	bool paused;
	bool registered;
	bool slipflag;
	bool started;
	DATA data;
	double aerodrag;
	double mps;
	DWORD lastidletime;
	DWORD packets;
	FILE *outstream;
	float accum_hr;
	float accum_kph;
	float accum_rpm;
	float accum_watts;
	float bars[NBARS];
	float draft_wind;
	float grade;                             // sent float grade, controlled by course or manually
	float igradex10;
	float last_export_grade;
	float manwts;
	float pedalrpm;
	float raw_rpm;
	float rawspeed;
	float tiredrag;
	float wind;
	int accum_hr_count;              // used for ergvid
	int accum_kph_count;             // used for ergvid
	int accum_rpm_count;             // used for ergvid
	int accum_tdc;
	int accum_watts_count;           // used for ergvid
	int bp;
	int ilbs;                        // rd.kgs converted to in lbs for transmitter
	int packetIndex;
	int parity_errors;               // keys byte parity bit
	int rxinptr;
	int rxoutptr;
	int serialport;                                          // associated serial port for this client
	int sscount;
	int tick;
	int txinptr;
	int txoutptr;
	LoggingType logging_type;
	PerfPoint pp;
	QAbstractSocket::SocketState socket_state;
	QHash<QTcpSocket*, QByteArray*> buffers;              // we need a buffer to store data until block has completely received
	QHash<QTcpSocket*, qint32*> sizes;                    // we need to store the size to verify if a block has received completely
	qint64 lastbeeptime;
	qint64 lastCommTime;
	qint64 lastdisplaytime;
	qint64 lastlinkuptime;
	qint64 lastWriteTime;
	QTimer *timer;
	RAW_COMPUTRAINER_LOGPACKET lp;
	Rider rider;
	std::vector<float> calories;
	std::vector<float> winds;
	unsigned char accum_keys;
	unsigned char control_byte;
	unsigned char HB_ERGO_PAUSE;
	unsigned char HB_ERGO_RUN;
	unsigned char idle_packet[7];
	unsigned char is_signed;
	unsigned char keydown;
	unsigned char keys;                             // the 6 hb keys + the polar heartrate bit
	unsigned char keyup;
	unsigned char lastkeys;
	unsigned char newmask[6];
	unsigned char packet[16 + 1];
	unsigned char pkt_mask[6];
	unsigned char rawpacket[6];
	unsigned char rpmValid;
	unsigned char rxbuf[RXBUFLEN];
	unsigned char rxq[RXQLEN];
	unsigned char ssraw[NBARS];
	unsigned char txbuf[6];
	unsigned char txq[TXQLEN];
	unsigned char tx_select;
	unsigned long bytes_in;
	unsigned long incomplete;
	unsigned long inpackets;
	unsigned long ptime;
	unsigned long recordsOut;
	unsigned short hbstatus;
	unsigned short maxhr;
	unsigned short minhr;
	unsigned short rfdrag;
	unsigned short rfmeas;
	unsigned short rpmflags;
	unsigned short slip;
	unsigned short version;


	void beep(void);
	int decode(void);
	int read_data(void);
	int init(void);
	int updateHardware(bool _force = false);
	float unpack(unsigned short p);
	void setup_connections(void);

public slots:
	//bool writeData(QByteArray data);
	void connected_slot();
	void disconnected_slot();
	void bytesWritten_slot(qint64 bytes);
	void readyRead_slot();
	void state_changed_slot(QAbstractSocket::SocketState _socket_state );
	void timer_slot();

signals:
	void connected_to_trainer_signal(int, bool);             // works

	void data_signal(int, DATA *);
	void ss_signal(int, SS::SSD *);
	int rescale_signal(int, int);

};                            // class CLIENT

#endif                        // #ifndef _X_CLIENT_H_X_


