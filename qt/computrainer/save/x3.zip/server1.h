
#ifndef _XSERVER_H_
#define _XSERVER_H_

#include <QHostAddress>
#include <QUdpSocket>
#include <QTcpServer>


#define METH 2          // 1 = QTcpSocket, 2 = QTcpServer

#include "tmr.h"
#include "tdefs.h"
#include "tcp_client.h"
#include "udp_client.h"

/**************************************************************************************
	 http://stackoverflow.com/questions/20546750/qtcpsocket-reading-and-writing
	 http://www.bogotobogo.com/Qt/Qt5_QTcpSocket_Signals_Slots.php
 ************************************************************************************/

class Server : public QObject {
	Q_OBJECT

public:
	explicit Server(QObject *_parent = 0);
	explicit Server(int _broadcast_port, int _listen_port, bool _ip_discover = false, bool _udp = false, QObject *_parent = 0);
	~Server(void);
	// setters:
	void setStarted(bool value);
	void setFinished(bool value);
	void setPaused(bool value);
	SS::BARINFO *get_barinfo(int i);
	void start(void);
	void stop(void);

signals:
	void connected_to_trainer_signal(int _id, bool _b);
	void data_signal(int, DATA *);
	void ss_signal(int, SS::SSD *);
	void rescale_signal(int, int);
	//void datasig(int, NHBDATA *);				// sends data to the final app
	void gradechanged_signal(int _igradex10);
	void windchanged_signal(float);
#ifdef TESTING
	void testing_signal(int, TESTDATA *);
#endif

private slots:
#ifdef TESTING
	void testing_slot(int, TESTDATA *);
#endif
	void processPendingDatagrams();
	// from the broadcast socket
	void bc_readyRead_slot();
	void bc_timer_slot();
	// from the app:
	void gradechanged_slot(int _igradex10);
	void windchanged_slot(float);
	// from the clients:
	void connected_to_trainer_slot(int _id, bool _b);
	void data_slot(int, DATA *);
	void ss_slot(int, SS::SSD *);
	void rescale_slot(int _id, int _maxforce);
	void newConnection();
	void disconnected();
	void error(QAbstractSocket::SocketError socketError);
	void hostFound();
	void stateChanged(QAbstractSocket::SocketState socketState);


private:
	int msgcnt;
	QTimer *bctimer;                                  // broadcast timer
	bool started;
	bool finished;
	bool paused;
	int curid;


	#define MAXCLIENTS 16
	//std::vector<Client *> clients;
	UDPClient *udpclients[MAXCLIENTS];

	TCPClient *tcpclients[MAXCLIENTS];
	#define BACKLOG 10

	static int instances;

	Tmr *at;
	bool log_to_console;

	unsigned long last_ip_broadcast_time;                    // ethernet

	int bp;
	int init(void);
	int myclose(void);
	static void mythread(void *);
	bool thread_running;
	bool contin;
	void destroy(void);
	qint16 listen_port;
	fd_set readfds;                           // read set
	fd_set writefds;                          // write set
	fd_set exceptfds;                         // exception set
	void logg(bool _print, const char *format, ...);
	FILE *logstream;
	int errors;
	bool ip_discover;
	bool udp;
	unsigned bcast_count;
	QByteArray bc_datagram;

	QHostAddress myip;
	QHostAddress bcaddr;

	QUdpSocket *bcsocket;
	QTcpServer *tcp_server;
	QUdpSocket *udp_server_socket;

	int create_udp_server_socket(void);
	int create_tcp_server(void);
	unsigned short bcport;

	typedef struct  {
		char name[32];
		char addr[32];
	} IFACE;

	std::vector<IFACE> ifaces;



public:

	int getPortNumber(void) {
		return 201;
	}
	void flush(void);
	int get_client_socket(int _ix);

};

#endif      // #ifndef _SERVER_H_
