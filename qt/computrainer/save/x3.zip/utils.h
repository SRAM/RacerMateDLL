
#ifndef _UTILS_H_
#define _UTILS_H_

#ifndef WIN32
	 char * strupr(char *str);
	 char * strlwr(char *str);
#endif

    short map(float x1,float x2,float y1,float y2,float *m,float *b);

#endif		// #ifndef _UTILS_H_

