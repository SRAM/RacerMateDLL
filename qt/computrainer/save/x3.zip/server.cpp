

#include <QNetworkInterface>
#include <QNetworkAddressEntry>
#include <QHostInfo>

#include "defines.h"
#include "utils.h"

#include "server.h"

 #include <QTcpSocket>
static inline qint32 ArrayToInt(QByteArray source);


int Server::instances = 0;

/**********************************************************************
	use ./client/Client.java on localhost to test
**********************************************************************/

Server::Server(QObject *_parent) : QObject(_parent) {

	int status;

	throw("bad server constructor");

	listen_port = 9072;

	status = init();
	if (status != 0) {
		throw 100;
	}

}                       // constructor

/**********************************************************************

**********************************************************************/

Server::Server(int _broadcast_port, int _listen_port, bool _ip_discover, bool _udp, QObject *_parent) : QObject(_parent) {

	int status;

	bcport = _broadcast_port;
	listen_port = _listen_port;
	ip_discover = _ip_discover;
	udp = _udp;


	status = init();
	if (status != 0) {
		throw 100;
	}
}


/**********************************************************************
	destructor
**********************************************************************/

Server::~Server() {
	destroy();
	bp = 0;
	instances--;

}

/**********************************************************************

**********************************************************************/

int Server::init(void) {
	int status;
	int i;
	//char str[256];

	msgcnt = 0;
	curid = 0;
	udp_server_socket = 0;
	tcp_server = 0;

	for (i = 0; i < MAXCLIENTS; i++) {
		tcpclients[i] = new TCPClient(i, this);
		udpclients[i] = new UDPClient(i, this);

		connect(udpclients[i], SIGNAL(data_signal(int, DATA*)), this, SLOT(data_slot(int, DATA*)));
		connect(udpclients[i], SIGNAL(ss_signal(int, SS::SSD*)), this, SLOT(ss_slot(int, SS::SSD*)));
		connect(udpclients[i], SIGNAL(rescale_signal(int, int)), this, SLOT(rescale_slot(int, int)));
#ifdef TESTING
		connect(udpclients[i], SIGNAL(testing_signal(int, TESTDATA*)), this, SLOT(testing_slot(int, TESTDATA*)));
#endif
		connect(this, SIGNAL(gradechanged_signal(int)), udpclients[i], SLOT(gradechanged_slot(int)));
		connect(this, SIGNAL(windchanged_signal(float)), udpclients[i], SLOT(windchanged_slot(float)));

	}

	started = false;
	finished = false;
	paused = false;

	log_to_console = true;

	bc_datagram.clear();

	bcast_count = 0L;
	errors = 0;

	contin = false;
	logstream = fopen("server.log", "wt");

	last_ip_broadcast_time = 0L;
	bcsocket = NULL;

	bp = 0;
	thread_running = false;


	QStringList items;
	 //int done = 0;
	 bcaddr = "miney2.mselectron.net";

	 /*
	 bool done = false;
	 foreach(QNetworkInterface interface, QNetworkInterface::allInterfaces()) {
		if (interface.flags().testFlag(QNetworkInterface::IsUp) && !interface.flags().testFlag(QNetworkInterface::IsLoopBack)) {

			foreach(QNetworkAddressEntry entry, interface.addressEntries()) {
				if ( interface.hardwareAddress() != "00:00:00:00:00:00" && entry.ip().toString().contains(".")) {
					items << interface.name() + " " + entry.ip().toString() + " " + interface.hardwareAddress();
					myip = entry.ip();

#ifdef _DEBUG
					bcaddr = "miney2.mselectron.net";
					//bcaddr = entry.broadcast();
#else
					bcaddr = entry.broadcast();
#endif
						  done = true;
						  //done = 1;
					break;
					// "eth0	192.168.1.20	F0:BF:97:57:D5:9B"
					// "wlan0	192.168.1.21	40:25:C2:26:FE:78"
				}
			}
			if (done) {
				break;
			}
		}
	}
	 */



	bp = 0;

	logg(log_to_console, "myip = %s\r\n", myip.toString().toStdString().c_str() );

	bc_datagram.append("Racermate ");
	bc_datagram.append(QString::number(listen_port));
	bc_datagram.append(" ");
	bc_datagram.append(myip.toString());
	bc_datagram.append("\r\n");

	//bool b;
	if (ip_discover) {
		bcsocket = new QUdpSocket(this);
		//#ifdef _DEBUG
		#if 1
		QHostInfo info = QHostInfo::fromName("miney2.mselectron.net");    // QHostInfo::localHostName()  );
		QList<QHostAddress> ip = info.addresses();
		bcaddr = ip[0];
		qDebug() << "bcaddr = " << bcaddr;
		#endif
	}                                // if (ip_discover)  {



	if (udp) {
		tcp_server = 0;
		status = create_udp_server_socket();                                     // creates the server socket and starts listening.
	}
	else  {
		udp_server_socket = 0;
		status = create_tcp_server();                                        // creates the server socket and starts listening.
	}


	if (status != 0) {
		return 1;
	}



	at = new Tmr("server");

	contin = true;

	qDebug() << "started thread";

	if (ip_discover) {
		// create a timer for broadcasting
		bctimer = new QTimer(this);
		connect( bctimer, SIGNAL(timeout()), this, SLOT(bc_timer_slot())  );
		bctimer->start(2000);
	}

	instances++;
	qDebug() << "Server::init x";

	return 0;
}                                            // init()


/**********************************************************************

**********************************************************************/

void Server::destroy(void) {
	myclose();
	return;
}                                            // destroy()

/**********************************************************************

**********************************************************************/

int Server::myclose(void) {
	unsigned long start;
	int rc = 0;

	contin = FALSE;

	start = QDateTime::currentMSecsSinceEpoch();

	while (thread_running) {
		if ((QDateTime::currentMSecsSinceEpoch() - start) >= 2000) {
			rc = 1;
			break;
		}
		bp++;
	}
	bp = 1;


	if (bcsocket != NULL) {
		bcsocket->close();
		DEL(bcsocket);
	}

	if (udp_server_socket) {
		//udp_server_socket->disconnect();
		udp_server_socket->close();
	}

	int i;

	for (i = 0; i < MAXCLIENTS; i++) {
		DEL(tcpclients[i]);
	}

	DEL(at);

	FCLOSE(logstream);
	return rc;

}                          // myclose()

/**********************************************************************

 ***********************************************************************/

void Server::logg(bool _print, const char *format, ...) {
	va_list ap;                                     // Argument pointer
	char s[1024];                                   // Output string
	int len;

	len = (int)strlen(format);
	if (len > 1023) {
		if (_print) {
			qDebug() << "string too long in logg()";
		}
		if (logstream) {
			fprintf(logstream, "\r\n(string too long in logg())\r\n");
			//fflush(logstream);
		}
		return;
	}

	va_start(ap, format);
	vsprintf(s, format, ap);
	va_end(ap);

	if (_print) {
		qDebug() << s;
	}

	return;
}                                      // logg()

/**********************************************************************

**********************************************************************/

qint32 ArrayToInt(QByteArray source) {
	qint32 temp;
	QDataStream data(&source, QIODevice::ReadWrite);

	data >> temp;
	return temp;
}                       // ArrayToInt()

/***********************************************************************************

***********************************************************************************/

int Server::create_tcp_server(void) {

	tcp_server = new QTcpServer(this);
	connect(tcp_server, SIGNAL(newConnection()), SLOT(newConnection()));
	tcp_server->listen(QHostAddress::AnyIPv4, listen_port);
	qDebug() << "listening on port " << listen_port;

	return 0;
}                                         // int create_tcp_server()

/**********************************************************************

**********************************************************************/

void Server::setPaused(bool value) {
	paused = value;
}

/**********************************************************************

**********************************************************************/

void Server::setFinished(bool value) {
	finished = value;
}

/**********************************************************************

**********************************************************************/

void Server::setStarted(bool value) {
	started = value;
}

/**********************************************************************

**********************************************************************/

int Server::create_udp_server_socket(void) {
	bool b;

	udp_server_socket = new QUdpSocket(this);
	b = udp_server_socket->bind(QHostAddress::AnyIPv4, listen_port);
	if (!b) {
		qFatal("error creating server socket 1");
	}

	connect(udp_server_socket, SIGNAL(connected()), this, SLOT(newConnection()));                   // never gets there
	connect(udp_server_socket, SIGNAL(disconnected()), this, SLOT(disconnected()));
	connect(udp_server_socket, SIGNAL(hostFound()), this, SLOT(hostFound()));
	connect(udp_server_socket, SIGNAL(readyRead()), this, SLOT(processPendingDatagrams()));

	// these have errors:

	connect(udp_server_socket, SIGNAL(stateChanged(QAbstractSocket::SocketState socketState)), this, SLOT(stateChanged(QAbstractSocket::SocketState socketState)));
	connect(udp_server_socket, SIGNAL(error(QAbstractSocket::SocketError socketError)), this, SLOT(error(QAbstractSocket::SocketError socketError)));

	return 0;
}


/**********************************************************************

**********************************************************************/

SS::BARINFO *Server:: get_barinfo(int i) {
	return tcpclients[0]->ss->get_barinfo(i);
}                          // get_barinfo(int i)


// slots+++

/*********************************************************************************************************************************
	bc_timer slot
*********************************************************************************************************************************/

void Server::bc_timer_slot() {
	//at->update();							// 3001 ms

	qint64 n;

	n = bcsocket->writeDatagram(bc_datagram, bcaddr, bcport);            // miney2.mselectron.net, 9071

	if (n <= 0) {
		qDebug() << "n = " << n;
		qDebug() << "bc_datagram = " << bc_datagram;
		qDebug() << "bcaddr = " << bcaddr;
		qDebug() << "bcport = " << bcport;
		qFatal("broadcast write error");
	}
	else  {
		qDebug() << "n = " << n;
		qDebug() << "bc_datagram = " << bc_datagram;
		qDebug() << "bcaddr = " << bcaddr;
		qDebug() << "bcport = " << bcport;
	}

	return;
}                          // timerslot()

/**********************************************************************
	broadcast socket (bcsocket) read slot:
**********************************************************************/

void Server::bc_readyRead_slot() {
	QByteArray buf;
	QHostAddress sender;
	quint16 senderPort;
	//qint64 n;


	buf.resize(bcsocket->pendingDatagramSize());

	//n =
	bcsocket->readDatagram(buf.data(), buf.size(), &sender, &senderPort );

	return;
}                       // bc_readyRead()

/**********************************************************************
	server slot
**********************************************************************/

void Server::newConnection() {

	int cnt = 0;

	if (udp) {
		qFatal("never gets here");
		return;
	}

	while (tcp_server->hasPendingConnections()) {
		cnt++;
		if (cnt > 1) {
			qDebug() << "new connection, cnt = " << cnt;
		}

		tcpclients[curid]->set_socket(tcp_server->nextPendingConnection());
		connect(tcpclients[curid], SIGNAL(connected_to_trainer_signal(int, bool)), this, SLOT(connected_to_trainer_slot(int, bool)));
		connect(tcpclients[curid], SIGNAL(data_signal(int, DATA*)), this, SLOT(data_slot(int, DATA*)));
		connect(tcpclients[curid], SIGNAL(ss_signal(int, SS::SSD*)), this, SLOT(ss_slot(int, SS::SSD*)));
		connect(tcpclients[curid], SIGNAL(rescale_signal(int, int)), this, SLOT(rescale_slot(int, int)));

		curid++;
	}

	return;
}                          // newConnection()


/**********************************************************************
	server slot, udp server only
**********************************************************************/

void Server::disconnected() {
	qDebug() << "udp server disconnecting";
	return;
}

/**********************************************************************
	server slot, udp server only
**********************************************************************/

void Server::error(QAbstractSocket::SocketError socketError) {
	Q_UNUSED(socketError);
	bp = 4;
	return;
}

/**********************************************************************
	server slot, udp server only
**********************************************************************/

void Server::hostFound() {
	bp = 4;
	return;
}

/**********************************************************************
	server slot, udp server only
**********************************************************************/

void Server::stateChanged(QAbstractSocket::SocketState socketState) {
	Q_UNUSED(socketState);

	bp = 4;
	return;
}

/**********************************************************************
	client slot
**********************************************************************/

void Server::connected_to_trainer_slot(int _id, bool _b) {
	emit connected_to_trainer_signal(_id, _b);                     // pass upstream

	return;
}

/**********************************************************************
	client slot
**********************************************************************/

void Server::data_slot(int _id, DATA *_data) {
	emit data_signal(_id, _data);

	return;
}

#ifdef TESTING
/**********************************************************************
	client slot
**********************************************************************/

void Server::testing_slot(int _id, TESTDATA *_data) {
	emit testing_signal(_id, _data);
	return;
}
#endif

/**********************************************************************
	client slot
**********************************************************************/

void Server::rescale_slot(int _id, int _maxforce) {
	emit rescale_signal(_id, _maxforce);

	return;
}

/**********************************************************************
	client slot
**********************************************************************/

void Server::ss_slot(int _id, SS::SSD *_ssd) {
	emit ss_signal(_id, _ssd);

	return;
}


/**********************************************************************
	app slot
**********************************************************************/

void Server::gradechanged_slot(int _igradex10) {
//Q_UNUSED(_igradex10);

#ifdef _DEBUG
	int igradex10;
	float grade;                          // sent float grade, controlled by course or manually
#endif

#ifdef _DEBUG
	igradex10 = _igradex10;
	grade = (float)igradex10 / 10.0f;
	qDebug() << "grade = " << grade;
#endif

	emit(gradechanged_signal(_igradex10));


	return;
}

/**********************************************************************
	app slot
**********************************************************************/

void Server::windchanged_slot(float _f) {
	Q_UNUSED(_f);

#ifdef _DEBUG
	float wind;
	wind = _f;
	qDebug() << qSetRealNumberPrecision(1) << "wind = " << wind;
#endif
	emit(windchanged_signal(_f));

	return;
}

/*********************************************************************************************************************************
	when the server is udp
*********************************************************************************************************************************/

void Server::processPendingDatagrams(void) {
	udpclients[0]->readDatagram(udp_server_socket);
}                          // processPendingDatagrams()

// slots---

/*********************************************************************************************************************************

*********************************************************************************************************************************/

void Server::start(void)  {
	return;
}

/*********************************************************************************************************************************

*********************************************************************************************************************************/

void Server::stop(void)  {
	return;
}

