
//#include <memory.h>
//#include <minmax.h>

#include <QDebug>

#define INVALID_SOCKET -1
#define SOCKET_ERROR -1
#include <utils.h>


#include "client.h"

/**********************************************************************
	this is the client that connects to the handlebar server
	use client2 for the case where the handlebar is the client

	 http://stackoverflow.com/questions/20546750/qtcpsocket-reading-and-writing
	 http://www.bogotobogo.com/Qt/Qt5_QTcpSocket_Signals_Slots.php
	 sudo tcpdump -ln -i eth0 port 9072
**********************************************************************/

Client::Client(int _id, const char *_ipstr, int _tcp_port, QObject *parent) : QObject(parent) {
	init();

	id = _id;
	strncpy(ipstr, _ipstr, sizeof(ipstr) - 1);
	tcp_port = _tcp_port;
	socket = new QTcpSocket(this);

	//socket = _socket;
	//socket->setSocketOption(QAbstractSocket::LowDelayOption, 1);

	connect(socket, SIGNAL(connected()), this, SLOT(connected()));
	connect(socket, SIGNAL(disconnected()), this, SLOT(disconnected()));
	connect(socket, SIGNAL(bytesWritten(qint64)), this, SLOT(bytesWritten(qint64)));
	connect(socket, SIGNAL(readyRead()), this, SLOT(myreadyRead()));
	connect(socket, SIGNAL(stateChanged(QAbstractSocket::SocketState)), this, SLOT(state_change(QAbstractSocket::SocketState)));
	socket->connectToHost(ipstr, tcp_port);         // this is not blocking call

	//program_start_time = QDateTime::currentMSecsSinceEpoch();

//    timer = new QTimer(this);
//    connect(    timer,					SIGNAL(timeout()),			this, SLOT(timeout()));
//    timer->start(10);





#if 0
	qint64 start = timeGetTime();
	if (!socket->waitForConnected(5000)) {
		qDebug() << "Error: " << socket->errorString();
		return;
	}

	// connected

	qint64 end = timeGetTime();
	qDebug() << "connected in " << (end - start) << " ms";           // average 260 ms

	if (socket->state() != QAbstractSocket::ConnectedState) {
		qDebug() << "wrong socket state";
		return;
	}

	gstart = timeGetTime();
	qDebug() << 0 << "   sending RacerMate";
	qint64 n = socket->write("RacerMate", 9);
	Q_ASSERT(n == 9);
	socket->flush();

	start = timeGetTime();
	qDebug() << timeGetTime() - gstart << "   calling expect()";
	int status = expect("LinkUp", 5000);
	end = timeGetTime();
	qDebug() << timeGetTime() - gstart << "   back from expect(), dt = " << end - start << " MS";

	if (status == 0) {
		connected_to_trainer = true;
	}
#endif


	return;
}


/**********************************************************************

**********************************************************************/

Client::~Client(void) {

	qDebug() << "client destructor";

	if (socket_state == QAbstractSocket::ConnectedState) {
		socket->close();
	}
	bp = 0;

	return;
}

/**********************************************************************

**********************************************************************/

int Client::init(void) {
	socket_state = QAbstractSocket::UnconnectedState;

	connected_to_trainer = false;
	//connected = false;
	bp = 0;
	lastidletime = 0L;
	//memset(idle_packet, 0, sizeof(idle_packet));
	idle_packet[0] = 0;
	idle_packet[1] = 0;
	idle_packet[2] = 0;
	idle_packet[3] = 0;
	idle_packet[4] = 0;
	idle_packet[5] = 0;
	idle_packet[6] = 0x80;

	socket = NULL;
	outpackets = 0L;
	bytes_out = 0L;
	//txinptr = 0;
	//txoutptr = 0;
	memset(rxq, 0, sizeof(rxq));
	//memset(txq, 0, sizeof(txq));
	memset(rxbuf, 0, sizeof(rxbuf));
	//memset(txbuf, 0, sizeof(txbuf));
	id = 0;                    // 0 - 15broadcast_message
	//comport = 0;					// 201-216
	rxinptr = 0;
	rxoutptr = 0;
	inpackets = 0L;
	incomplete = 0L;
	bytes_in = 0L;
	ipaddr = 0L;
	//serialport = 0;													// associated serial port for this client

#ifndef WIN32
	//    rx = NULL;
	//    tx = NULL;
#endif

	memset(ipstr, 0, sizeof(ipstr));
	tcp_port = 0;

	return 0;
}                          // CLIENT::init()

/**********************************************************************
	 puts stuff in the transmit queue
**********************************************************************/

int Client::flush(void) {

	if (socket) {
		socket->flush();
	}

	return 0;
}

#if 0
/**********************************************************************

**********************************************************************/

int CLIENT::receive(void) {
	int tot = 0;;

#ifndef WIN32
	//todo
#else
	int i, n;
	while (1) {
		n = recv(socket, (char*)rxbuf, sizeof(rxbuf) - 1, 0);    // get the message
		if (n == 0) {
			break;
		}else if (n < 0) {
			break;
		}

		tot += n;
		bytes_in += tot;

		// put it in the rxq

		for (i = 0; i < n; i++) {
			rxq[rxinptr] = rxbuf[i];
			rxinptr = (rxinptr + 1) % RXQLEN;
			i++;
			if (i == RXBUFLEN) {
				return -1;                          // error;
			}
		}
	}
#endif

	return tot;
}                                   // receive()

#endif


/**********************************************************************

**********************************************************************/

/*
	void CLIENT::tx(const unsigned char _c)  {
	 //int n;
	 //n = recv(socket, (char *)rxbuf, sizeof(rxbuf)-1, 0);   // get the message
	 //return n;
	 bp = 0;

	 bp = 1;
	 return;
	}
 */

/**********************************************************************

**********************************************************************/

int Client::idle(void) {
	DWORD now;

	now = QDateTime::currentMSecsSinceEpoch();

	if ((now - lastidletime) >= 500) {
		lastidletime = now;
		mysend(idle_packet, 7, true);
		return 1;
	}


	return 0;

}

/**********************************************************************
	 just puts stuff in the queue
**********************************************************************/

int Client::mysend(const unsigned char *_buf, int _len, bool _flush) {

	/*
		int i;

		for(i=0; i<_len; i++)  {
		 txq[txinptr] = _str[i];
		 txinptr = (txinptr+1) % TXQLEN;
		}
	 */

	//int status;
	//int flags = 0;

	/*
		status = send(socket, (char *)_buf, _len, flags);
		if (status==-1)  {
		 const char *cptr = strerror(errno);
		 bp = 4;
		 return 1;
		}
	 */

	return 0;
}

/**********************************************************************

**********************************************************************/

#if 0
QByteArray IntToArray(qint32 source) {                //Use qint32 to ensure that the number have 4 bytes
	//Avoid use of cast, this is the Qt way to serialize objects
	QByteArray temp;
	QDataStream data(&temp, QIODevice::ReadWrite);

	data << source;
	return temp;
}
#endif

// slots:

/**********************************************************************

**********************************************************************/

/*
	bool CLIENT::writeData(QByteArray data)  {
	 if(socket->state() == QAbstractSocket::ConnectedState) {
		  socket->write(IntToArray(data.size())); //write size of data
		  socket->write(data); //write the data itself
		  return socket->waitForBytesWritten();
	 }
	 else  {
		  return false;
	 }

	}
 */

/**********************************************************************

**********************************************************************/

void Client::connected() {
	bp = 3;
	qDebug() << "connected";

	return;
}

/**********************************************************************

**********************************************************************/

void Client::disconnected() {
	bool b = socket->isOpen();

	qDebug() << "disconnected";
	bp = 2;
	return;
}

/**********************************************************************

**********************************************************************/

void Client::bytesWritten(qint64 bytes) {
	bp = 3;
	qDebug() << QDateTime::currentMSecsSinceEpoch() - gstart << "   bytesWritten = " << bytes;
	return;
}

/**********************************************************************

**********************************************************************/

void Client::myreadyRead() {
	QByteArray a;
	int i, n;

	qDebug() << QDateTime::currentMSecsSinceEpoch() - gstart << "   readyRead() start";

	while (socket->bytesAvailable()) {
		a = socket->readAll();
		n = a.length();

		qDebug() << "    " << QDateTime::currentMSecsSinceEpoch() - gstart << "   n = " << n;

		for (i = 0; i < n; i++) {
			rxq[rxinptr] = a[i];
			rxinptr = (rxinptr + 1) % sizeof(rxq);
		}
	}

	qDebug() << QDateTime::currentMSecsSinceEpoch() - gstart << "   readyRead() end";

}


/**********************************************************************

**********************************************************************/

void Client::state_change(QAbstractSocket::SocketState _socket_state ) {
	socket_state = _socket_state;
	qDebug() << "state_changed " << socket_state;
	bp = 5;
	return;
}


/**********************************************************************

**********************************************************************/
#define EXPECT_BUF_LEN 256

int Client::expect(const char *_str, qint64 timeout) {
	qint64 start;
	qint64 start2;
	char buf[EXPECT_BUF_LEN];
	int i;

	if (strlen(_str) > sizeof(buf) - 1) {
		return 1;
	}

	// debugging:
	if (rxinptr > 0 ) {
		bp = 1;
	}

	i = 0;
	memset(buf, 0, sizeof(buf));

	//start = QDateTime::currentMSecsSinceEpoch();
	start = QDateTime::currentMSecsSinceEpoch();
	start2 = QDateTime::currentMSecsSinceEpoch();

	//qDebug() << start;

	unsigned long cnt = 0L;

	while (1) {
		cnt++;
		//if ((QDateTime::currentMSecsSinceEpoch() - start) >= timeout)  {
		if ((QDateTime::currentMSecsSinceEpoch() - start) >= timeout) {
			break;
		}

		while (rxoutptr != rxinptr) {
			buf[i] = rxq[rxoutptr];
			i++;
			if (i == EXPECT_BUF_LEN) {
			}
			rxoutptr = (rxoutptr + 1) % RXQLEN;
		}

		if (!strcmp(_str, (const char*)buf)) {
			bp = 1;
			return 0;
		}
		QThread::msleep(10);
	}

	bp = 2;
	return 1;
}                                // expect()

