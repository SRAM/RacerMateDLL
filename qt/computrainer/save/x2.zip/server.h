
#ifndef _XSERVER_H_
#define _XSERVER_H_


//#include <QtCore>
#include <QHostAddress>
#include <QUdpSocket>

#ifdef METH
XXXXXXXXXXXXX
#endif

#define METH 2				// 1 = QTcpSocket, 2 = QTcpServer

#if METH==1
	 #include <QTcpSocket>
#else
	 #include <QTcpServer>
#endif

//#include <tinythread.h>

#include "tmr.h"
#include "tdefs.h"
#include "client2.h"


/**************************************************************************************
	 http://stackoverflow.com/questions/20546750/qtcpsocket-reading-and-writing
	 http://www.bogotobogo.com/Qt/Qt5_QTcpSocket_Signals_Slots.php
************************************************************************************/

class Server : public QObject {
	 Q_OBJECT

	 public:
		  explicit Server(QObject *_parent = 0);
		  explicit Server(int _broadcast_port, int _listen_port, bool _ip_discover=false, bool _udp=false, QObject *_parent = 0);
		  //virtual ~Server(void);
		  ~Server(void);

	 signals:
#if METH==2
		  void dataReceived(QByteArray);
#endif

	 public slots:
		  // broadcast socket slots
		  void bc_readyRead();
		  void timerslot();

#if METH==1
		  // server socket slots

		  void connected();
		  void disconnected();
		  void bytesWritten(qint64 bytes);
		  void readyRead();
#elif METH==2
	 private slots:
		  void newConnection();
		  //void client_disconnected();
		  //void client_readyRead();
#endif

	 private:
		  //void broadcast(void);
		  QTimer *bctimer;										// broadcast timer

	 private:

#if METH==2
		  //QHash<QTcpSocket*, QByteArray*> buffers;				// we need a buffer to store data until block has completely received
		  //QHash<QTcpSocket*, qint32*> sizes;						// we need to store the size to verify if a block has received completely
#endif

		  #define MAXCLIENTS 8

		  #define BACKLOG 10
		  void pack(void);
		  static int instances;

		  Tmr *at;
		  bool log_to_console;
		  std::vector<Client2> clients;

		  unsigned long last_ip_broadcast_time;					// ethernet

		  int bp;
		  int init(void);
		  int myclose(void);
		  static void mythread(void *);
		  bool thread_running;
		  bool contin;
		  void destroy(void);
		  //int maxsocket;
		  qint16 listen_port;
		  fd_set readfds;								// read set
		  fd_set writefds;								// write set
		  fd_set exceptfds;								// exception set
		  void logg(bool _print, const char *format, ...);
		  FILE *logstream;
		  int errors;
		  bool ip_discover;
		  bool udp;
		  unsigned bcast_count;
		  QByteArray bc_datagram;

		  QHostAddress myip;
		  QHostAddress bcaddr;

		  QUdpSocket *bcsocket;
#if METH==1
		  QTcpSocket *lsocket;
#elif METH==2
		  QTcpServer *server;
		  //void dataReceived(QByteArray _data);
#endif

		  int create_listen_socket(void);
		  unsigned short bcport;

		  typedef struct  {
				char name[32];
				char addr[32];
		  } IFACE;

		 std::vector<IFACE> ifaces;



	 public:

#if METH==1
		  void doConnect(void);
#endif

		  bool is_client_connected(int _ix);
		  int getPortNumber(void)  { return 201; }
		  void flush(void);
		  int get_client_socket(int _ix);

		  int send(int _ix, const unsigned char *_str, int _len, bool _flush=false);			// puts stuff in the txq

		  int expect(int _ix, const char *str, DWORD timeout);
		  int rx(int _ix, char *buf, int buflen);

		  void flush_rawstream(int _ix);
		  void txx(unsigned char *b, int n);
};

#endif		// #ifndef _SERVER_H_
