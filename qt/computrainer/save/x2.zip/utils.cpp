
#include <string.h>

#include "utils.h"


/**********************************************************************
  strupr is a microsoft invention
 **********************************************************************/

char *strupr(char *str)  {
	 for(int i=0; i<(int)strlen(str); i++)  {
		  if (str[i]>='a' && str[i]<='z')  {
				str[i] = str[i] - 0x20;
		  }
	 }

	 return str;
}

/**********************************************************************
  strlwr is a microsoft invention
**********************************************************************/

char *strlwr(char *str)  {
	 for(int i=0; i<(int)strlen(str); i++)  {
		  if (str[i]>='A' && str[i]<='Z')  {
				str[i] = str[i] + 0x20;
		  }
	 }

	 return str;
}

/********************************************************************
  m a p
  returns m,b that maps x1,x2 to y1,y2
  general mapping:
  m = (y2 - y1) / (x2-x1)
  y = mx + (y1 - m*x1)
exit:
returns -1 when mapping is impossible (divide by 0)
 ********************************************************************/

short map(float x1,float x2,float y1,float y2,float *m,float *b)  {
	float d;

	d = x2 - x1;

	if (d == 0.0f) {		// prevent divide by 0
		*m = 0.0f;
		*b = y1;
		return -1;
	}
	*m = (y2-y1) / (x2-x1);
	*b = (y1 - *m*x1);

	return 0;
}

