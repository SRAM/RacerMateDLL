//#include <QtCore>
#include <QNetworkInterface>
#include <QNetworkAddressEntry>

#include "defines.h"
#include "utils.h"
//#include "tmr.h"

#include "server.h"

#if METH == 2
	 #include <QTcpSocket>
static inline qint32 ArrayToInt(QByteArray source);
#endif


int Server::instances = 0;

/**********************************************************************
	use ./client/Client.java on localhost to test
**********************************************************************/

Server::Server(QObject *_parent) : QObject(_parent){

	int status;

	throw("bad server constructor");

	listen_port = 9072;

	status = init();
	if (status != 0) {
		throw 100;
	}

	//initialized = true;

}                       // constructor

/**********************************************************************

**********************************************************************/

Server::Server(int _broadcast_port, int _listen_port, bool _ip_discover, bool _udp, QObject *_parent) : QObject(_parent){

	int status;

	bcport = _broadcast_port;
	listen_port = _listen_port;
	ip_discover = _ip_discover;
	udp = _udp;

	status = init();
	if (status != 0) {
		throw 100;
	}
}


/**********************************************************************
	destructor
**********************************************************************/

Server::~Server(){
	destroy();
	bp = 0;
	instances--;

}

/**********************************************************************

**********************************************************************/

int Server::init(void){
	int status;
	int i;
	char str[256];

	log_to_console = true;

	bc_datagram.clear();

	bcast_count = 0L;
	errors = 0;

	for (i = 0; i < (int)clients.size(); i++) {
		memset(&clients[i], 0, sizeof(Client2));
		//clients[i].socket = -1;
		clients[i].socket = 0;
	}

	contin = false;
	logstream = fopen("server.log", "wt");

	last_ip_broadcast_time = 0L;
	//maxsocket = -1;
	//listen_socket = NULL;										// server socket
	bcsocket = NULL;

	bp = 0;
	thread_running = false;


	QStringList items;
	bool done = false;

	foreach(QNetworkInterface interface, QNetworkInterface::allInterfaces()) {
		if (interface.flags().testFlag(QNetworkInterface::IsUp) && !interface.flags().testFlag(QNetworkInterface::IsLoopBack)) {

			foreach(QNetworkAddressEntry entry, interface.addressEntries()) {
				if ( interface.hardwareAddress() != "00:00:00:00:00:00" && entry.ip().toString().contains(".")) {
					items << interface.name() + " " + entry.ip().toString() + " " + interface.hardwareAddress();
					myip = entry.ip();
					bcaddr = entry.broadcast();
					done = true;
					break;
					// "eth0	192.168.1.20	F0:BF:97:57:D5:9B"
					// "wlan0	192.168.1.21	40:25:C2:26:FE:78"
				}
			}
			if (done) {
				break;
			}
		}
	}

	bp = 0;

	logg(log_to_console, "myip = %s\r\n", myip.toString().toStdString().c_str() );

	bc_datagram.append("Racermate ");
	bc_datagram.append(QString::number(listen_port));
	bc_datagram.append(" ");
	bc_datagram.append(myip.toString());

	if (ip_discover) {
		bcsocket = new QUdpSocket(this);
		bcsocket->bind(bcaddr, bcport);
		connect(
			bcsocket, SIGNAL(readyRead()),
			this, SLOT(bc_readyRead())
			);

		//broadcast();
	}                                // if (ip_discover)  {



	status = create_listen_socket();                                     // creates the server socket and starts listening.
	if (status != 0) {
		return 1;
	}

	at = new Tmr("server");

	contin = true;

	qDebug() << "started thread";

	// wait 300 ms for a potential client to connect. The client should be trying to connect every 100 ms.

	//Sleep(1000);			// was 300


	if (ip_discover) {
		// create a timer for broadcasting
		bctimer = new QTimer(this);
		connect(
			bctimer,
			SIGNAL(timeout()),
			this,
			SLOT(timerslot())
			);
		bctimer->start(3000);
	}

	instances++;
	qDebug() << "Server::init x";

	return 0;
}                                            // init()


/**********************************************************************

**********************************************************************/

void Server::destroy(void){
	//int status;

	myclose();

	return;
}                                            // destroy()

/**********************************************************************
	server rx
**********************************************************************/

int Server::rx(int _ix, char *buf, int buflen){

	if (_ix >= (int)clients.size()) {
		return 0;
	}

	return 0;
}

/**********************************************************************

**********************************************************************/

int Server::expect(int _ix, const char *_str, DWORD _timeout){
	int len, i = 0;
	unsigned char c[8];
	qint64 start, end;
	int n;

	len = strlen(_str);

	start = QDateTime::currentMSecsSinceEpoch();

	while (1) {
		n = rx(_ix, (char*)c, 1);

		if (n == 1) {
			if (c[0] == _str[i]) {
				i++;
				if (i == len) {
					return 0;
				}
			}else {
				i = 0;
			}
		}else {
			end = QDateTime::currentMSecsSinceEpoch();
			if ((end - start) > _timeout) {
				return 1;
			}
		}
	}

	return 1;
}

/**********************************************************************

**********************************************************************/

void Server::flush(void){

	return;
}


#ifdef _DEBUG
/**********************************************************************

**********************************************************************/

void Server::flush_rawstream(int _ix){
	return;
}


#endif

/**********************************************************************

**********************************************************************/


void Server::txx(unsigned char *b, int n){
	return;
}


/**********************************************************************

**********************************************************************/


int Server::myclose(void){
	unsigned long start;
	int rc = 0;

	contin = FALSE;

	start = QDateTime::currentMSecsSinceEpoch();


	while (thread_running) {
		if ((QDateTime::currentMSecsSinceEpoch() - start) >= 2000) {
			rc = 1;
			break;
		}
		bp++;
	}
	bp = 1;


	if (bcsocket != NULL) {
		bcsocket->close();
		DEL(bcsocket);
	}

#if METH == 1
	lsocket->close();
	DEL(lsocket);
#endif

	DEL(at);

	FCLOSE(logstream);
	return rc;

}                          // close()

/***********************************************************************************

***********************************************************************************/

int Server::create_listen_socket(void){
	server = new QTcpServer(this);
	connect(server, SIGNAL(newConnection()), SLOT(newConnection()));
	server->listen(QHostAddress::AnyIPv4, listen_port);
	qDebug() << "listening on port " << listen_port;

	return 0;
}                                         // int create_listen_socket()


/**********************************************************************

 ***********************************************************************/

void Server::logg(bool _print, const char *format, ...){
	va_list ap;                                     // Argument pointer
	char s[1024];                                   // Output string
	int len;

	len = (int)strlen(format);
	if (len > 1023) {
		if (_print) {
			qDebug() << "string too long in logg()";
		}
		if (logstream) {
			fprintf(logstream, "\r\n(string too long in logg())\r\n");
			//fflush(logstream);
		}
		return;
	}

	va_start(ap, format);
	vsprintf(s, format, ap);
	va_end(ap);

	if (_print) {
		qDebug() << s;
	}

	return;
}                                      // logg()


/**********************************************************************

**********************************************************************/

bool Server::is_client_connected(int _comport){
	int n;


	int ix = _comport - SERVER_SERIAL_PORT_BASE;

	if (clients.size() > 0) {
		n = clients.size();
		if (ix == n - 1) {
			if (clients[ix].socket != 0) {
				return true;
			}
		}
	}

	return false;
}


/*************************************************************************
	called only frrom thread
*************************************************************************/

void Server::pack(void){

#if 0

	NO COPY CONSTRUCTORS IN QT !!!!

	int i, n;
	std::vector<CLIENT> tc;

	n = clients.size();

	for (i = 0; i < n; i++) {
		if (clients[i].socket != 0) {
			tc.push_back(clients[i]);           // no copy constructors in Qt!
		}
	}

	clients.clear();
	n = tc.size();
	//maxsocket = listen_socket;

	for (i = 0; i < n; i++) {
		clients.push_back(tc[i]);
	}


	if (clients.size() == 0) {
		//logg(log_to_console, "all clients closed, maxsocket is now %d\r\n", maxsocket);
	}
#endif

	return;
}                                   // pack()

/**********************************************************************
	the server socket is already created and we are waiting for a client
	to connect.
**********************************************************************/


/**********************************************************************
	broadcast socket read slot:
**********************************************************************/

void Server::bc_readyRead(){
	QByteArray buf;
	QHostAddress sender;
	quint16 senderPort;
	qint64 n;


	buf.resize(bcsocket->pendingDatagramSize());

	n = bcsocket->readDatagram(
		buf.data(),
		buf.size(),
		&sender,
		&senderPort
		);

	bp = 1;
	return;
}


/**********************************************************************

**********************************************************************/
/*
	void Server::broadcast(void)  {
	 bcsocket->writeDatagram(datagram, bcaddr, bcport);
	 return;
	}
 */

/**********************************************************************

**********************************************************************/

int Server::send(int _ix, const unsigned char *_str, int _len, bool _flush){
	int ix;
	int n;

	ix = _ix + 1 - SERVER_SERIAL_PORT_BASE;
	n = (int)clients.size();

	if (ix >= n) {
		return 0;
	}

	clients[ix].mysend(_str, _len, _flush);


	return 0;
}                                // enqueue()

#if METH == 1

/**********************************************************************

**********************************************************************/

void Server::doConnect(void){
	lsocket = new QTcpSocket(this);

	connect(lsocket, SIGNAL(connected()), this, SLOT(connected()));
	connect(lsocket, SIGNAL(disconnected()), this, SLOT(disconnected()));
	connect(lsocket, SIGNAL(bytesWritten(qint64)), this, SLOT(bytesWritten(qint64)));
	connect(lsocket, SIGNAL(readyRead()), this, SLOT(readyRead()));

	qDebug() << "connecting...";

	// this is not blocking call
	lsocket->connectToHost("google.com", 80);

	// we need to wait...
	if (!lsocket->waitForConnected(5000)) {
		qDebug() << "Error: " << lsocket->errorString();
	}
}                             // doConnect()

/**********************************************************************

**********************************************************************/

void Server::connected(){
	qDebug() << "connected...";

	// Hey server, tell me about you.
	lsocket->write("HEAD / HTTP/1.0\r\n\r\n\r\n\r\n");
}

/**********************************************************************

**********************************************************************/

void Server::disconnected(){
	qDebug() << "disconnected...";
}

/**********************************************************************

**********************************************************************/

void Server::bytesWritten(qint64 bytes){
	qDebug() << bytes << " bytes written...";
}

/**********************************************************************

**********************************************************************/

void Server::readyRead(){
	qDebug() << "reading...";

	// read the data from the socket
	qDebug() << lsocket->readAll();
}

#else

/**********************************************************************
	slot
	the handlebar is the client
**********************************************************************/

#if 0
void Server::client_readyRead(){
	QTcpSocket *socket = static_cast<QTcpSocket*>(sender());

	QByteArray *buffer = buffers.value(socket);
	qint32 *s = sizes.value(socket);
	qint32 size = *s;

	bp = 0;

	while (socket->bytesAvailable() > 0) {
		buffer->append(socket->readAll());

		while ((size == 0 && buffer->size() >= 4) || (size > 0 && buffer->size() >= size)) {   // while can process data, process it
			if (size == 0 && buffer->size() >= 4) {                                             // if size of data has received completely, then store it on our global variable
				size = ArrayToInt(buffer->mid(0, 4));
				*s = size;
				buffer->remove(0, 4);
			}

			if (size > 0 && buffer->size() >= size) {                                           // if data has received completely, then emit our SIGNAL with the data
				QByteArray data = buffer->mid(0, size);
				buffer->remove(0, size);
				size = 0;
				*s = size;
				emit dataReceived(data);
			}
		}
	}
}                          // client_readyRead()

/**********************************************************************
	slot
	the handlebar is the client
**********************************************************************/

void Server::client_disconnected(){
	QTcpSocket *socket = static_cast<QTcpSocket*>(sender());
	QByteArray *buffer = buffers.value(socket);
	qint32 *s = sizes.value(socket);

	socket->deleteLater();

	delete buffer;
	delete s;
}
#endif				// #if 0



/**********************************************************************
	slot
**********************************************************************/

void Server::newConnection(){

	int cnt = 0;
	Client2 *client;

	while (server->hasPendingConnections()) {
		cnt++;
		if (cnt > 1) {
			qDebug() << "new connection, cnt = " << cnt;
		}

		QTcpSocket *socket = server->nextPendingConnection();

		QHostAddress addr = socket->localAddress();                                // 192.168.1.20
		qint16 port = socket->localPort();                                         // 9072
		addr = socket->peerAddress();																// 50.194.61.75, Norm's address
		QString str = socket->peerName();														// ""
		port = socket->peerPort();																	// 8319

/*
		connect(socket, SIGNAL(readyRead()), SLOT(client_readyRead()));
		connect(socket, SIGNAL(client_disconnected()), SLOT(client_disconnected()));
		QByteArray *buffer = new QByteArray();
		qint32 *s = new qint32(0);
		buffers.insert(socket, buffer);
		sizes.insert(socket, s);
*/

		int id = clients.size() + 1;

		client = new Client2(id, socket, this);

		//client = new Client(id, "xxx", 22, this);
		//client = new Client(id, socket, this);

	}

	bp = 3;

	return;
}


/**********************************************************************

**********************************************************************/

//qint32 Server::ArrayToInt(QByteArray source)  {
qint32 ArrayToInt(QByteArray source){
	qint32 temp;
	QDataStream data(&source, QIODevice::ReadWrite);

	data >> temp;
	return temp;
}                       // ArrayToInt()

/**********************************************************************

**********************************************************************/
/*
	void Server::dataReceived(QByteArray _data)  {
	 bp = 2;
	 return;
	}
 */


#endif

/*********************************************************************************************************************************

*********************************************************************************************************************************/

void Server::timerslot(){
	/*
		qint64 ms;
		ms = QDateTime::currentMSecsSinceEpoch();
		//qDebug() << "tick" << count++;
		qDebug() << "tick" << ms;
	 */
	//at->update();							// 3001 ms
	bcsocket->writeDatagram(bc_datagram, bcaddr, bcport);

}
