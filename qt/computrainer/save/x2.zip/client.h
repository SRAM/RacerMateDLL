#ifndef _X_CLIENT_H_X_
#define _X_CLIENT_H_X_

/*******************************************************************************
	this is the client that connects to the handlebar server
	use client2 for the case where the handlebar is the client
*******************************************************************************/


#include <QtCore>
//#include <QtNetwork>
//#include <QAbstractSocket>
#include <QTcpSocket>

#include "defines.h"

#define TXQLEN 1024
#define RXQLEN 1024
#define RXBUFLEN 1024
#define TXBUFLEN 1024

class Client : public QObject  {
	Q_OBJECT

public:
	//CLIENT(const CLIENT &_copy);											// qt doesn't allow copy constructors;
	//explicit CLIENT(const CLIENT &_copy, QObject *parent = 0);
	//explicit CLIENT(QObject *parent = 0);
	//explicit Client(QObject *parent = 0);
	explicit Client(int _id, const char *_ipstr, int _tcp_port, QObject *parent = 0);
	//explicit Client(int _id, QTcpSocket *_socket, QObject *parent = 0);
	~Client(void);

public slots:
	//bool writeData(QByteArray data);
	void connected();
	void disconnected();
	void bytesWritten(qint64 bytes);
	void myreadyRead();
	void state_change(QAbstractSocket::SocketState _socket_state );

	//friend class Server;
	//private:
	//	const int TXQLEN = 1024;

public:
	qint64 gstart;                              // class-wide start time for timeGetTime() debugging
	QTcpSocket *socket;
	//int socket;							// socket number
	unsigned long outpackets;
	unsigned long bytes_out;
	unsigned long ipaddr;
	int id;                                // 0 - 15
	//int comport;					// 201-216
	char ipstr[128];
	QAbstractSocket::SocketState get_state(void) {
		return socket_state;
	}
	bool is_connected_to_trainer(void) {
		return connected_to_trainer;
	}
	int expect(const char *_str, qint64 _timeout);

private:
	bool connected_to_trainer;
	QAbstractSocket::SocketState socket_state;
	//bool connected;
	DWORD lastidletime;
	unsigned char idle_packet[7];
	unsigned long bytes_in;
	int bp;
	int rxinptr;
	int rxoutptr;
	//int txinptr;
	//int txoutptr;
	//unsigned char txq[TXQLEN];
	unsigned char rxq[RXQLEN];
	unsigned char rxbuf[RXBUFLEN];
	//unsigned char txbuf[TXBUFLEN];

	unsigned long inpackets;
	unsigned long incomplete;
	//int serialport;													// associated serial port for this client
	int tcp_port;

	int init(void);

public:
	int flush(void);
	int mysend(const unsigned char *_str, int _len, bool _flush);
	int idle(void);

	//#ifndef WIN32
	//    FILE *rx;
	//    FILE *tx;
	//#endif


	//int receive(void);
	//void tx(const unsigned char _c);

};                            // class CLIENT

#endif                        // #ifndef _X_CLIENT_H_X_


