#ifndef _X_CLIENT2_H_X_
#define _X_CLIENT2_H_X_

#include <stdio.h>
#include <QtCore>
#include <QTcpSocket>

#include "defines.h"

#include "rider.h"
#include "ss.h"
#include "coursefile.h"

#define TXQLEN 1024
#define RXQLEN 1024
#define RXBUFLEN 1024
#define TXBUFLEN 1024

class Client2 : public QObject  {
	Q_OBJECT

	public:
		class DATA  {
			public:
				DATA(void);
				float mph;
				float watts;
				float rpm;
				float lata;
				float rata;
				float miles;
				float ss;
				float lss;
				float rss;
				float lwatts;
				float rwatts;
				float avgss;
				float avglss;
				float avgrss;
				float hr;
				float cals;

				unsigned short hrflags;

				void reset(void);

			private:
				void init(void);

		};

		static const int NBARS = 24;

		enum LoggingType {
			NO_LOGGING,
			RAW_PERF_LOGGING,
			THREE_D_PERF_LOGGING,
			RM1_PERF_LOGGING
		};

		typedef struct {
			unsigned long time;
			unsigned char buf[6];
		} RAW_COMPUTRAINER_LOGPACKET;

	#define MODE_WIND               0x2c
	#define MODE_WIND_PAUSE         0x28
	#define MODE_RFTEST             0x1c
	#define MODE_ERGO               0x14
	#define MODE_ERGO_PAUSE         0x10


	public:
		explicit Client2(int _id, QTcpSocket *_socket, QObject *parent = 0);
		~Client2();

		int flush(void);
		int mysend(const unsigned char *_str, int _len, bool _flush);
		int idle(void);
		FILE *rx;
		FILE *tx;
		int receive(void);
		//int socket;							// socket number
		unsigned long outpackets;
		unsigned long bytes_out;
		unsigned long ipaddr;
		int id;								// 0 - 15
		int comport;						// 201-216
		char ipstr[128];
		QTcpSocket *socket;				// todo: make private

	private:
		int tick;
		SS *ss;
		DATA data;
		qint64 lastdisplaytime;
		unsigned char rawpacket[6];
		std::vector<float> winds;
		std::vector<float> calories;
		Rider rider;
		unsigned char packet[16+1];
		int packetIndex;
		bool finishEdge;
		bool started;
		bool finished;
		bool paused;
		int parity_errors;                      		// keys byte parity bit
		int decode(void);
		LoggingType logging_type;
		FILE *outstream;
		RAW_COMPUTRAINER_LOGPACKET lp;
		unsigned long recordsOut;
		PerfPoint pp;
		bool hrbeep_enabled;
		float igradex10;
		float grade;                          // sent float grade, controlled by course or manually
		unsigned long ptime;
		qint64 lastbeeptime;
		float bars[NBARS];
		unsigned char ssraw[NBARS];
		float wind;
		void beep(void);
		unsigned char tx_select;
		bool registered;
		float last_export_grade;
		unsigned char is_signed;
		float draft_wind;
		int ilbs;                   // rd.kgs converted to in lbs for transmitter
		unsigned char lastkeys;
		unsigned char keydown;
		unsigned char keyup;
		int sscount;
		double mps;
		float rawspeed;
		unsigned short rpmflags;
		bool hrvalid;
		float pedalrpm;
		unsigned char rpmValid;
		unsigned short minhr;
		unsigned short maxhr;
		unsigned short rfdrag;
		unsigned short rfmeas;
		unsigned short hbstatus;
		unsigned short version;
		unsigned short slip;
		bool slipflag;
		float raw_rpm;
		DWORD packets;
		double aerodrag;
		float tiredrag;
		float manwts;
		unsigned char txbuf[6];
		unsigned char control_byte;
		unsigned char pkt_mask[6];
		//unsigned long bytes_out;
		float unpack(unsigned short p);
		int accum_watts_count;							// used for ergvid
		int accum_rpm_count;							// used for ergvid
		int accum_hr_count;								// used for ergvid
		int accum_kph_count;							// used for ergvid


		int read_data(void);
		qint64 lastWriteTime;
		int updateHardware(bool _force=false);

		QHash<QTcpSocket*, QByteArray*> buffers;				// we need a buffer to store data until block has completely received
		QHash<QTcpSocket*, qint32*> sizes;						// we need to store the size to verify if a block has received completely

		DWORD lastidletime;
		unsigned char idle_packet[7];
		unsigned long bytes_in;
		int bp;
		int rxinptr;
		int rxoutptr;
		int txinptr;
		int txoutptr;
		unsigned char txq[TXQLEN];
		unsigned char rxq[RXQLEN];
		unsigned char rxbuf[RXBUFLEN];
		//unsigned char txbuf[TXBUFLEN];
		unsigned long inpackets;
		unsigned long incomplete;
		int serialport;													// associated serial port for this client
		int init(void);
		QAbstractSocket::SocketState socket_state;
		QTimer *timer;
		void setup_connections(void);
		bool connected_to_trainer;
		qint64 lastlinkuptime;
		qint64 lastCommTime;
		unsigned char accum_keys;
		float accum_watts;
		float accum_rpm;
		float accum_hr;
		float accum_kph;
		int accum_tdc;
		unsigned char keys;                     		// the 6 hb keys + the polar heartrate bit
#define XORVAL 0xff
#define RPM_VALID	0x08


	unsigned char HB_ERGO_RUN;
	unsigned char HB_ERGO_PAUSE;

	unsigned char newmask[6];

	public slots:
		//bool writeData(QByteArray data);
		void connected();
		void disconnected();
		void bytesWritten(qint64 bytes);
		void readyRead();
		void state_change(QAbstractSocket::SocketState _socket_state );
		void timerslot();
	signals:
		void signal_connected_to_server(bool);
		void signal_connected_to_trainer(bool);
		void signal_spinscan_data(SS::SSD *);
		void signal_data(Client2::DATA *);
		int signal_rescale(int);

};										// class CLIENT2

#endif								// #ifndef _X_CLIENT_H_X_


