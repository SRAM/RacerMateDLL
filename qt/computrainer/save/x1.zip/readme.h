this is the next version (after udp) where I started modifying computrainer.* to be a server. Way unfinished, but
I needed to go back to work on the former version so they could test udp, longer timeouts, and Norm's new packet
format in Seattle. Getting back to working on this one today.

